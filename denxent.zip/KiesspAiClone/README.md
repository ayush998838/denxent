# Denxent Voice Transformation System

[![Replit Ready to Run](https://img.shields.io/badge/Replit-Ready_to_Run-blue)](https://replit.com)
[![Python Version](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

Denxent is a powerful voice transformation web application that allows you to modify your voice in real-time with various effects including noise cancellation, accent conversion, gender transformation, and voice cloning.

## 🎯 Features

- 🔊 **Real-time Voice Transformation**: Transform your voice as you speak
- 🔇 **Noise Cancellation**: Remove background noise from your audio
- 👥 **Voice Isolation**: Focus on the main speaker's voice
- 🔄 **Echo Cancellation**: Eliminate audio feedback
- 🌍 **Accent Conversion**: Change your accent (American, British, Indian, Neutral)
- ⚥ **Gender Transformation**: Make your voice sound more masculine, feminine, or neutral
- 🎭 **Voice Cloning**: Upload a voice sample and speak with someone else's voice
- 👤 **User Accounts**: Save your voice samples and settings for future use
- 🌐 **Full Web Interface**: No need to download any client applications

## 🚀 Quick Start

1. Visit the application at https://denxent.replit.app (or your own deployment URL)
2. Navigate to the "Web Client" page
3. Click "Start Audio" and grant microphone permissions
4. Speak and hear your transformed voice in real-time!

## 📋 Requirements

- Modern web browser (Chrome, Firefox, Safari, or Edge)
- Microphone
- Internet connection

## 🔧 Installation & Local Development

1. Clone the repository:
```bash
git clone https://github.com/yourusername/denxent.git
cd denxent
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the server:
```bash
python run.py
```

4. Visit `http://localhost:5000` in your browser

## 📚 Documentation

- [Setup and Usage Guide](SETUP_AND_USAGE_GUIDE.md) - Detailed setup and usage instructions
- [VSCode Terminal Commands](VSCODE_TERMINAL_COMMANDS.txt) - Useful terminal commands for development

## 🌟 Key Components

- **Web Client Interface**: Browser-based interface for all voice transformation features
- **Real-time Processing**: WebSocket-based audio streaming with instant feedback
- **Voice Models**: Advanced ML models for different voice transformations
- **User Management**: Account creation, authentication, and profile management
- **Sample Management**: Upload, record, and manage voice samples for cloning

## 🖼️ Screenshots

![Denxent Web Interface](static/images/screenshot_web_client.png)
*Web Client Interface with Real-time Voice Transformation Controls*

## 📊 Architecture

```
┌─────────────┐     WebSocket    ┌─────────────┐
│ Web Browser │◄───Connection────┤    Server   │
└─────┬───────┘                  └──────┬──────┘
      │                                 │
┌─────▼───────┐                 ┌──────▼──────┐
│  Web Audio  │                 │   Audio     │
│    API      │                 │ Processor   │
└─────────────┘                 └──────┬──────┘
                                       │
                               ┌──────▼──────┐
                               │    Voice    │
                               │Transformer  │
                               └──────┬──────┘
                                      │
                               ┌──────▼──────┐
                               │ ML Models   │
                               │ (Accent,    │
                               │ Gender, etc)│
                               └─────────────┘
```

## 🔄 Development Workflow

For development, we recommend using VSCode with the following tools:
- Python extension
- Live Server extension
- Git integration

Follow these steps for effective development:
1. Make code changes
2. Run the server with `python run.py`
3. Test in browser
4. Commit and push changes

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Flask and SQLAlchemy for the web framework and database
- Flask-SocketIO for real-time communication
- Numpy and SciPy for audio processing
- Bootstrap for the UI framework