"""
Denxent - Voice Transformation System - Main Flask Application
"""
import os
import logging
import uuid
import json
from flask import Flask, render_template, request, jsonify, send_from_directory, Response, flash, redirect, url_for
from flask_socketio import SocketIO, emit
from flask_login import LoginManager, login_user, logout_user, login_required, current_user

from audio_processing import AudioProcessor
from voice_transformation import VoiceTransformer

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", str(uuid.uuid4()))

# Database configuration
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///denxent.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize Socket.IO
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Initialize database
from app import db
db.init_app(app)

# Import models after initializing db to avoid circular imports
from models.user import User
from models.voice_sample import VoiceSample

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    """Load user by ID for Flask-Login"""
    return User.query.get(int(user_id))

# Initialize audio processor and voice transformer
audio_processor = AudioProcessor()
voice_transformer = VoiceTransformer()

# Create database tables
with app.app_context():
    db.create_all()

# Active client sessions
active_sessions = {}

@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')

@app.route('/download')
def download_page():
    """Render the download page"""
    return render_template('download.html')

@app.route('/user_guide')
def user_guide():
    """Render the user guide page"""
    return render_template('user_guide.html')

@app.route('/web_client')
def web_client():
    """Render the web client page"""
    return render_template('web_client.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login page"""
    if current_user.is_authenticated:
        return redirect(url_for('web_client'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        remember = 'remember' in request.form
        
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user, remember=remember)
            next_page = request.args.get('next')
            if next_page:
                return redirect(next_page)
            return redirect(url_for('web_client'))
        else:
            flash('Invalid email or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration page"""
    if current_user.is_authenticated:
        return redirect(url_for('web_client'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('register.html')
        
        existing_user = User.query.filter((User.email == email) | (User.username == username)).first()
        if existing_user:
            flash('Username or email already exists', 'danger')
            return render_template('register.html')
        
        new_user = User(username=username, email=email)
        new_user.set_password(password)
        
        db.session.add(new_user)
        db.session.commit()
        
        flash('Account created successfully! You can now log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    """Log out the current user"""
    logout_user()
    flash('You have been logged out successfully', 'info')
    return redirect(url_for('index'))

@app.route('/profile')
@login_required
def profile():
    """User profile page"""
    voice_samples = VoiceSample.query.filter_by(user_id=current_user.id).all()
    return render_template('profile.html', voice_samples=voice_samples)

@app.route('/api/available_transformations', methods=['GET'])
def available_transformations():
    """Return list of available voice transformations"""
    return jsonify({
        'accents': voice_transformer.get_available_accents(),
        'genders': voice_transformer.get_available_genders(),
        'personas': voice_transformer.get_available_personas()
    })

@app.route('/api/client_download', methods=['GET'])
def client_download():
    """Endpoint to download the Windows client application"""
    # In a real application, this would return the actual client installer
    # For this example, we return a placeholder
    return jsonify({
        'download_url': '/download/voicetransform_client_setup.exe',
        'version': '1.0.0'
    })

@app.route('/download/<path:filename>', methods=['GET'])
def download_file(filename):
    """Download handler for client files"""
    # Placeholder for actual file downloads
    return Response(
        "This would be the client executable in a real deployment",
        mimetype="application/octet-stream",
        headers={"Content-disposition": f"attachment; filename={filename}"})

@app.route('/api/upload_voice_sample', methods=['POST'])
def upload_voice_sample():
    """Handle uploaded voice samples for cloning"""
    if 'sample' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['sample']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    # Generate unique ID for this voice sample
    sample_id = str(uuid.uuid4())
    
    # Save file temporarily (in memory for this example)
    audio_data = file.read()
    
    # Get sample name from form
    sample_name = request.form.get('name', 'Voice Sample')
    
    # Process the voice sample with the voice transformer
    try:
        voice_transformer.process_voice_sample(sample_id, audio_data)
        
        # Store sample in database if user is logged in
        user_id = None
        if current_user.is_authenticated:
            user_id = current_user.id
            
        # Create sample record in database
        voice_sample = VoiceSample(
            id=sample_id,
            name=sample_name,
            user_id=user_id,
            is_public=False
        )
        
        db.session.add(voice_sample)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'sample_id': sample_id,
            'message': 'Voice sample processed successfully'
        })
    except Exception as e:
        logger.error(f"Error processing voice sample: {str(e)}")
        return jsonify({'error': str(e)}), 500

@socketio.on('connect')
def handle_connect():
    """Handle new WebSocket connection"""
    logger.info(f"Client connected: {request.sid}")
    active_sessions[request.sid] = {
        'noise_cancellation': True,
        'voice_isolation': True,
        'echo_cancellation': True,
        'accent': None,
        'gender': None,
        'voice_clone_id': None
    }
    emit('connection_established', {'session_id': request.sid})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle WebSocket disconnection"""
    logger.info(f"Client disconnected: {request.sid}")
    if request.sid in active_sessions:
        del active_sessions[request.sid]

@socketio.on('audio_stream')
def handle_audio_stream(data):
    """Process incoming audio stream from client"""
    if request.sid not in active_sessions:
        emit('error', {'message': 'Session not found'})
        return
    
    session = active_sessions[request.sid]
    
    try:
        # Convert binary audio data to format needed for processing
        audio_data = data.get('audio')
        if not audio_data:
            return
        
        # Process the audio based on active settings
        processed_audio = audio_processor.process_audio(
            audio_data,
            noise_cancellation=session['noise_cancellation'],
            voice_isolation=session['voice_isolation'],
            echo_cancellation=session['echo_cancellation']
        )
        
        # Apply voice transformations if enabled
        if session['accent'] or session['gender'] or session['voice_clone_id']:
            transformed_audio = voice_transformer.transform_voice(
                processed_audio,
                accent=session['accent'],
                gender=session['gender'],
                voice_clone_id=session['voice_clone_id']
            )
        else:
            transformed_audio = processed_audio
        
        # Send processed audio back to the client
        emit('processed_audio', {'audio': transformed_audio})
    
    except Exception as e:
        logger.error(f"Error processing audio stream: {str(e)}")
        emit('error', {'message': str(e)})

@socketio.on('update_settings')
def handle_update_settings(data):
    """Update session settings for voice transformation"""
    if request.sid not in active_sessions:
        emit('error', {'message': 'Session not found'})
        return
    
    session = active_sessions[request.sid]
    
    # Update settings based on client request
    if 'noise_cancellation' in data:
        session['noise_cancellation'] = data['noise_cancellation']
    
    if 'voice_isolation' in data:
        session['voice_isolation'] = data['voice_isolation']
    
    if 'echo_cancellation' in data:
        session['echo_cancellation'] = data['echo_cancellation']
    
    if 'accent' in data:
        session['accent'] = data['accent']
    
    if 'gender' in data:
        session['gender'] = data['gender']
    
    if 'voice_clone_id' in data:
        session['voice_clone_id'] = data['voice_clone_id']
    
    emit('settings_updated', session)

@app.route('/api/update_user_settings', methods=['POST'])
def update_user_settings():
    """Update user's default voice transformation settings"""
    if not current_user.is_authenticated:
        return jsonify({'error': 'Authentication required'}), 401
    
    data = request.json
    
    try:
        if 'default_noise_cancellation' in data:
            current_user.default_noise_cancellation = data['default_noise_cancellation']
        
        if 'default_voice_isolation' in data:
            current_user.default_voice_isolation = data['default_voice_isolation']
        
        if 'default_echo_cancellation' in data:
            current_user.default_echo_cancellation = data['default_echo_cancellation']
        
        if 'default_accent' in data:
            current_user.default_accent = data['default_accent'] or None
        
        if 'default_gender' in data:
            current_user.default_gender = data['default_gender'] or None
        
        if 'default_voice_clone_id' in data:
            current_user.default_voice_clone_id = data['default_voice_clone_id'] or None
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'User settings updated successfully'
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating user settings: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/delete_voice_sample/<sample_id>', methods=['DELETE'])
@login_required
def delete_voice_sample(sample_id):
    """Delete a voice sample"""
    voice_sample = VoiceSample.query.get(sample_id)
    
    if not voice_sample:
        return jsonify({'error': 'Voice sample not found'}), 404
    
    if voice_sample.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    try:
        # Delete the sample from storage
        voice_transformer.delete_voice_sample(sample_id)
        
        # Delete from database
        db.session.delete(voice_sample)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Voice sample deleted successfully'
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting voice sample: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/update_profile', methods=['POST'])
@login_required
def update_profile():
    """Update user profile information"""
    data = request.json
    current_password = data.get('current_password')
    
    if not current_user.check_password(current_password):
        return jsonify({'error': 'Current password is incorrect'}), 400
    
    try:
        # Check if email is already used by another user
        if data.get('email') != current_user.email:
            existing_user = User.query.filter_by(email=data.get('email')).first()
            if existing_user and existing_user.id != current_user.id:
                return jsonify({'error': 'Email already in use'}), 400
        
        # Check if username is already used by another user
        if data.get('username') != current_user.username:
            existing_user = User.query.filter_by(username=data.get('username')).first()
            if existing_user and existing_user.id != current_user.id:
                return jsonify({'error': 'Username already in use'}), 400
        
        current_user.username = data.get('username', current_user.username)
        current_user.email = data.get('email', current_user.email)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Profile updated successfully'
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating profile: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/change_password', methods=['POST'])
@login_required
def change_password():
    """Change user password"""
    data = request.json
    old_password = data.get('old_password')
    new_password = data.get('new_password')
    
    if not current_user.check_password(old_password):
        return jsonify({'error': 'Current password is incorrect'}), 400
    
    try:
        current_user.set_password(new_password)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Password changed successfully'
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error changing password: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True, use_reloader=True, log_output=True)
