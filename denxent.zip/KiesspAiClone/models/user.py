"""
User model for Denxent Voice Transformation application
"""
import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db


class User(UserMixin, db.Model):
    """User model for authentication and profile management"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    
    # Voice customization preferences
    default_noise_cancellation = db.Column(db.Boolean, default=True)
    default_voice_isolation = db.Column(db.Boolean, default=True)
    default_echo_cancellation = db.Column(db.Boolean, default=True)
    default_accent = db.Column(db.String(50), nullable=True)
    default_gender = db.Column(db.String(50), nullable=True)
    default_voice_clone_id = db.Column(db.String(36), nullable=True)
    
    # Relationships
    voice_samples = db.relationship('VoiceSample', back_populates='user')
    
    def set_password(self, password):
        """Hash and set the user password"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Verify password against stored hash"""
        return check_password_hash(self.password_hash, password)
    
    def get_default_settings(self):
        """Get user's default voice transformation settings"""
        return {
            'noise_cancellation': self.default_noise_cancellation,
            'voice_isolation': self.default_voice_isolation,
            'echo_cancellation': self.default_echo_cancellation,
            'accent': self.default_accent,
            'gender': self.default_gender,
            'voice_clone_id': self.default_voice_clone_id
        }
    
    def __repr__(self):
        return f'<User {self.username}>'