"""
Noise suppression model implementation
"""
import logging
import numpy as np
from scipy import signal

logger = logging.getLogger(__name__)

class NoiseSuppressionModel:
    """Implements noise cancellation for audio signals"""
    
    def __init__(self):
        """Initialize the noise suppression model"""
        logger.info("Initializing noise suppression model")
        # In a real implementation, this would load pre-trained models
        # For this demonstration, we'll use a simplified spectral subtraction approach
        
        self.sample_rate = 16000
        self.frame_length = 480  # 30ms at 16kHz
        self.hop_length = 160    # 10ms at 16kHz
        self.n_fft = 512         # FFT size
        
        # Parameters for spectral subtraction
        self.alpha = 2.0         # Over-subtraction factor
        self.beta = 0.02         # Spectral floor
        
        # Noise profile buffer (will be updated during silence)
        self.noise_profile = None
        self.noise_update_counter = 0
        
        logger.info("Noise suppression model initialized")
    
    def suppress_noise(self, audio_frame):
        """
        Apply noise suppression to an audio frame
        
        Args:
            audio_frame: Numpy array containing audio samples
            
        Returns:
            Processed audio frame with reduced noise
        """
        try:
            # Initialize noise profile if not already done
            if self.noise_profile is None:
                # Initialize with a conservative estimate
                # In a real implementation, we would estimate this from actual silence
                self.noise_profile = np.mean(np.abs(np.fft.rfft(audio_frame, self.n_fft))**2)
            
            # Simplified spectral subtraction
            # 1. Apply short-time Fourier transform (STFT)
            X = np.fft.rfft(audio_frame, self.n_fft)
            X_mag = np.abs(X)
            X_phase = np.angle(X)
            
            # 2. Estimate signal-to-noise ratio
            snr = X_mag**2 / (self.noise_profile + 1e-10)
            
            # 3. Apply spectral subtraction with flooring
            gain = np.maximum(1 - self.alpha / (snr + 1e-10), self.beta)
            
            # 4. Apply gain to magnitude spectrum
            X_mag_clean = X_mag * gain
            
            # 5. Reconstruct signal with original phase
            X_clean = X_mag_clean * np.exp(1j * X_phase)
            
            # 6. Inverse FFT to get time-domain signal
            audio_clean = np.fft.irfft(X_clean, self.n_fft)
            
            # Ensure output has the same length as input
            audio_clean = audio_clean[:len(audio_frame)]
            
            # Update noise profile during probable silence
            # This is a simplistic approach - a real implementation would use VAD
            if np.mean(X_mag**2) < 0.01:
                self.noise_profile = 0.95 * self.noise_profile + 0.05 * np.mean(X_mag**2)
            
            return audio_clean
            
        except Exception as e:
            logger.error(f"Error in noise suppression: {str(e)}")
            return audio_frame  # Return original if processing fails
