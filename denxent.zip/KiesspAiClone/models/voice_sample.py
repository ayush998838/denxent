"""
Database model for voice samples
"""
import datetime
from app import db


class VoiceSample(db.Model):
    """Model for storing voice samples for cloning"""
    id = db.Column(db.String(36), primary_key=True)  # UUID
    name = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    is_public = db.Column(db.Boolean, default=False)
    sample_path = db.Column(db.String(255), nullable=True)  # Path to the sample file if stored on disk
    
    # Relationship with User model (if authenticated)
    user = db.relationship('User', back_populates='voice_samples')
    
    def __repr__(self):
        return f'<VoiceSample {self.id}: {self.name}>'
    
    def to_dict(self):
        """Convert model to dictionary for API responses"""
        return {
            'id': self.id,
            'name': self.name,
            'created_at': self.created_at.isoformat(),
            'is_public': self.is_public,
            'user_id': self.user_id
        }