"""
Gender transformation model implementation
"""
import logging
import numpy as np
from scipy import signal

logger = logging.getLogger(__name__)

class GenderTransformationModel:
    """Implements gender/voice transformation for changing voice characteristics"""
    
    def __init__(self):
        """Initialize the gender transformation model"""
        logger.info("Initializing gender transformation model")
        
        self.sample_rate = 16000
        self.frame_length = 480  # 30ms at 16kHz
        self.hop_length = 160    # 10ms at 16kHz
        self.n_fft = 512         # FFT size
        
        # Gender transformation parameters
        self.gender_params = {
            "Male": {
                "pitch_shift": -3.0,        # Lower pitch (semitones)
                "formant_shift": 0.85,      # Lower formants
                "spectral_tilt": -0.2       # More bass emphasis
            },
            "Female": {
                "pitch_shift": 3.0,         # Higher pitch (semitones)
                "formant_shift": 1.15,      # Higher formants
                "spectral_tilt": 0.2        # More treble emphasis
            },
            "Neutral": {
                "pitch_shift": 0.0,         # No shift
                "formant_shift": 1.0,       # No shift
                "spectral_tilt": 0.0        # No tilt
            }
        }
        
        logger.info("Gender transformation model initialized")
    
    def transform_gender(self, audio_frame, target_gender):
        """
        Apply gender transformation to an audio frame
        
        Args:
            audio_frame: Numpy array containing audio samples
            target_gender: Target gender to transform to
            
        Returns:
            Gender-transformed audio frame
        """
        try:
            # Check if target gender is supported
            if target_gender not in self.gender_params:
                logger.warning(f"Gender {target_gender} not supported, using Neutral")
                target_gender = "Neutral"
            
            # Get gender parameters
            params = self.gender_params[target_gender]
            
            # 1. Apply pitch shifting
            if params["pitch_shift"] != 0.0:
                # Pitch shifting with WSOLA (Waveform Similarity Overlap-Add) algorithm
                # For demonstration, we'll use a simplified approach based on resampling
                
                # Convert semitones to resampling factor
                resample_factor = 2 ** (params["pitch_shift"] / 12)
                
                # Resample to change pitch (longer signal = lower pitch)
                audio_resampled = signal.resample(audio_frame, int(len(audio_frame) / resample_factor))
                
                # Time-stretch back to original length
                audio_pitch_shifted = signal.resample(audio_resampled, len(audio_frame))
            else:
                audio_pitch_shifted = audio_frame
            
            # 2. Apply formant shifting
            if params["formant_shift"] != 1.0:
                # Compute STFT
                X = np.fft.rfft(audio_pitch_shifted, self.n_fft)
                X_mag = np.abs(X)
                X_phase = np.angle(X)
                
                # Create frequency axis for warping
                freqs = np.linspace(0, 1, len(X_mag))
                
                # Warp frequency axis for formant shifting
                alpha = params["formant_shift"]
                warped_freqs = freqs / alpha
                
                # Interpolate magnitudes based on warped frequencies
                warped_X_mag = np.interp(freqs, warped_freqs, X_mag, left=0, right=0)
                
                # Reconstruct with original phase
                X_warped = warped_X_mag * np.exp(1j * X_phase)
                
                # Inverse FFT
                audio_formant_shifted = np.fft.irfft(X_warped, self.n_fft)
                
                # Ensure output has the same length as input
                audio_formant_shifted = audio_formant_shifted[:len(audio_frame)]
            else:
                audio_formant_shifted = audio_pitch_shifted
            
            # 3. Apply spectral tilt (bass/treble emphasis)
            if params["spectral_tilt"] != 0.0:
                # Compute STFT
                X = np.fft.rfft(audio_formant_shifted, self.n_fft)
                X_mag = np.abs(X)
                X_phase = np.angle(X)
                
                # Create spectral tilt factor
                # Linear increase/decrease based on frequency
                freqs = np.linspace(0, 1, len(X_mag))
                tilt_factor = 1.0 + params["spectral_tilt"] * (freqs - 0.5)
                
                # Apply tilt
                X_mag_tilted = X_mag * tilt_factor
                
                # Reconstruct with original phase
                X_tilted = X_mag_tilted * np.exp(1j * X_phase)
                
                # Inverse FFT
                audio_tilted = np.fft.irfft(X_tilted, self.n_fft)
                
                # Ensure output has the same length as input
                audio_tilted = audio_tilted[:len(audio_frame)]
            else:
                audio_tilted = audio_formant_shifted
            
            return audio_tilted
            
        except Exception as e:
            logger.error(f"Error in gender transformation: {str(e)}")
            return audio_frame  # Return original if processing fails
