"""
WebSocket worker for Gunicorn to handle Flask-SocketIO
"""
from flask_socketio import SocketIO

# monkey patching is required for eventlet/gevent workers
try:
    import eventlet
    eventlet.monkey_patch()
except ImportError:
    try:
        import gevent
        import gevent.monkey
        gevent.monkey.patch_all()
    except ImportError:
        pass

# WebSocket worker class for Gunicorn
# This needs to be referenced in Gunicorn command with --worker-class
class GunicornWebSocketWorker:
    """Worker for Gunicorn to properly handle WebSockets with Flask-SocketIO"""
    
    def __init__(self, wsgi_app, **kwargs):
        self.wsgi_app = wsgi_app
        self.socketio = SocketIO()
        
    def __call__(self, environ, start_response):
        return self.wsgi_app(environ, start_response)