# Denxent Voice Transformation System

## Setup and Usage Guide

Welcome to the Denxent Voice Transformation System! This guide will help you set up and use this powerful voice transformation platform.

## Table of Contents
1. [Overview](#overview)
2. [System Requirements](#system-requirements)
3. [Installation](#installation)
4. [Running the Server](#running-the-server)
5. [Web Client Usage](#web-client-usage)
6. [Voice Transformation Features](#voice-transformation-features)
7. [User Accounts](#user-accounts)
8. [Troubleshooting](#troubleshooting)
9. [Development Information](#development-information)

## Overview

Denxent is a powerful voice transformation system that allows you to modify your voice in real-time with various effects:

- **Noise Cancellation**: Remove background noise from your audio
- **Voice Isolation**: Isolate the main speaker's voice from other sounds
- **Echo Cancellation**: Eliminate echo and audio feedback
- **Accent Conversion**: Change your accent (American, British, Indian, etc.)
- **Gender Transformation**: Make your voice sound more masculine, feminine, or neutral
- **Voice Cloning**: Upload a voice sample and speak with someone else's voice

## System Requirements

- **Operating System**: Linux, macOS, or Windows
- **Python**: Version 3.10 or higher
- **Database**: PostgreSQL (automatically configured on setup)
- **Web Browser**: Chrome, Firefox, Safari, or Edge (latest versions)
- **Hardware**:
  - CPU: 2.0 GHz dual-core processor or better
  - RAM: 4GB minimum (8GB recommended)
  - Storage: 500MB free space
  - Microphone: Any standard microphone
  - Internet connection for web interface access

## Installation

### Install Dependencies

```bash
# Clone the repository
git clone https://github.com/yourusername/denxent.git
cd denxent

# Create a virtual environment (optional but recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install Python dependencies
pip install -r requirements.txt
```

### Database Setup

The system uses PostgreSQL for storing user accounts, settings, and voice samples:

```bash
# Setup PostgreSQL database (optional if using SQLite for development)
export DATABASE_URL="postgresql://username:password@localhost:5432/denxent"
```

If you're using the replit.com environment, the PostgreSQL database is automatically set up for you.

## Running the Server

Start the Denxent server with:

```bash
# Development mode
python run.py

# Production mode with Gunicorn
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
```

Once running, access the web interface by navigating to `http://localhost:5000` in your browser.

## Web Client Usage

The web client provides an intuitive interface for controlling all voice transformation features:

1. Visit `http://localhost:5000` in your web browser
2. Navigate to the "Web Client" page
3. Click "Start Audio" to begin microphone capture
4. Use the controls to adjust voice transformation settings
5. Speak into your microphone to hear the transformed voice in real-time

### Audio Controls

- **Input/Output Levels**: Visualize audio input and output in real-time
- **Start/Stop Audio**: Control when voice transformation is active
- **Live Playback**: Toggle real-time audio feedback

### Transformation Controls

- **Basic Processing**:
  - Noise Cancellation: Remove background noise
  - Voice Isolation: Focus on the main speaker's voice
  - Echo Cancellation: Eliminate audio feedback

- **Voice Transformations**:
  - Accent Conversion: Change your accent (American, British, Indian, Neutral)
  - Gender Transformation: Alter gender characteristics of your voice

- **Voice Cloning**:
  - Upload or record voice samples
  - Use other voices for your speech

## Voice Transformation Features

### Noise Cancellation
Denxent's noise cancellation feature uses advanced machine learning models to identify and remove background noise from your audio stream while preserving speech quality.

### Accent Conversion
The accent conversion feature allows you to speak in different accents regardless of your native accent. You can select from American, British, Indian, and Neutral accent options.

### Gender Transformation
This feature allows you to adjust the gender characteristics of your voice. You can make your voice sound more masculine, feminine, or neutral, while still maintaining natural speech quality.

### Voice Cloning
Voice cloning lets you speak with someone else's voice. You can record or upload a voice sample, and Denxent will transform your voice to match the characteristics of the sample.

## User Accounts

Creating a user account allows you to save your voice samples and default settings for future use.

### Registration
1. Visit the "Register" page
2. Enter your desired username, email, and password
3. Click "Register" to create your account

### Login
1. Visit the "Login" page
2. Enter your email and password
3. Click "Login" to access your account

### Profile Management
In your profile, you can:
- Manage your voice samples
- Set default voice transformation settings
- Update your account information
- Change your password

## Troubleshooting

### Audio Issues
- **No audio output**: Ensure your browser has permission to access your microphone
- **Audio delay**: Reduce buffer size in settings for lower latency
- **Poor quality**: Try enabling/disabling different processing features

### Connection Issues
- **Cannot connect to server**: Verify the server is running and accessible
- **WebSocket errors**: Check firewall settings and network connectivity

### Browser Compatibility
- For best results, use the latest version of Chrome, Firefox, Safari, or Edge
- WebRTC and Web Audio APIs must be supported by your browser

## Development Information

### Project Structure
- `app.py`: Database configuration
- `main.py`: Entry point for Gunicorn
- `server.py`: Main Flask application
- `audio_processing.py`: Audio processing logic
- `voice_transformation.py`: Voice transformation features
- `models/`: ML models for various transformations
- `templates/`: HTML templates for the web interface
- `static/`: CSS, JavaScript, and other static assets

### API Endpoints
Denxent provides several API endpoints for integration:
- `/api/available_transformations`: Get available transformation options
- `/api/upload_voice_sample`: Upload a voice sample for cloning
- `/api/update_user_settings`: Update user default settings
- `/api/delete_voice_sample/<sample_id>`: Delete a voice sample
- `/api/update_profile`: Update user profile information
- `/api/change_password`: Change user password

### WebSocket Events
Real-time audio processing uses Socket.IO with these events:
- `connect`: Establish connection to server
- `audio_stream`: Send audio data for processing
- `processed_audio`: Receive processed audio data
- `update_settings`: Update processing settings
- `settings_updated`: Confirm settings update

For development reference, check the `VSCODE_TERMINAL_COMMANDS.txt` file for useful commands.

---

Thank you for using Denxent Voice Transformation System! If you encounter any issues or have suggestions for improvement, please open an issue on our GitHub repository.