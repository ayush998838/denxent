"""
Audio processing module for voice transformation
"""
import logging
import numpy as np
from models.noise_cancellation import NoiseSuppressionModel
from models.echo_cancellation import EchoCancellationModel

logger = logging.getLogger(__name__)

class AudioProcessor:
    """Handles audio processing capabilities like noise cancellation and echo suppression"""
    
    def __init__(self):
        """Initialize audio processor with necessary models"""
        logger.info("Initializing AudioProcessor")
        self.noise_model = NoiseSuppressionModel()
        self.echo_model = EchoCancellationModel()
        
        # Audio processing parameters
        self.sample_rate = 16000
        self.frame_size = 480  # 30ms at 16kHz
        self.buffer = np.array([], dtype=np.float32)
        
        logger.info("AudioProcessor initialized successfully")
    
    def process_audio(self, audio_data, noise_cancellation=True, voice_isolation=True, echo_cancellation=True):
        """
        Process the incoming audio data with selected transformations
        
        Args:
            audio_data: The raw audio data (bytes or base64 encoded string)
            noise_cancellation: Whether to apply noise cancellation
            voice_isolation: Whether to isolate the main speaker's voice
            echo_cancellation: Whether to apply echo cancellation
            
        Returns:
            Processed audio data
        """
        try:
            # Convert audio data to numpy array if it's not already
            if isinstance(audio_data, bytes):
                # Assuming the audio is 16-bit PCM
                audio_array = np.frombuffer(audio_data, dtype=np.int16).astype(np.float32) / 32768.0
            elif isinstance(audio_data, str):
                # Assuming it's base64 encoded
                import base64
                decoded = base64.b64decode(audio_data)
                audio_array = np.frombuffer(decoded, dtype=np.int16).astype(np.float32) / 32768.0
            else:
                # Assume it's already a numpy array
                audio_array = audio_data
            
            # Add to buffer
            self.buffer = np.append(self.buffer, audio_array)
            
            # Process audio in frames
            processed_frames = []
            while len(self.buffer) >= self.frame_size:
                frame = self.buffer[:self.frame_size]
                self.buffer = self.buffer[self.frame_size:]
                
                # Apply transformations
                if noise_cancellation:
                    frame = self.noise_model.suppress_noise(frame)
                
                if voice_isolation:
                    # Voice isolation is often part of noise cancellation, but could be enhanced
                    frame = self.isolate_voice(frame)
                
                if echo_cancellation:
                    frame = self.echo_model.cancel_echo(frame)
                
                processed_frames.append(frame)
            
            # Combine processed frames
            if processed_frames:
                processed_audio = np.concatenate(processed_frames)
                
                # Convert back to the same format as input
                if isinstance(audio_data, bytes):
                    processed_audio = (processed_audio * 32768.0).astype(np.int16).tobytes()
                elif isinstance(audio_data, str):
                    import base64
                    processed_bytes = (processed_audio * 32768.0).astype(np.int16).tobytes()
                    processed_audio = base64.b64encode(processed_bytes).decode('utf-8')
                
                return processed_audio
            else:
                # Not enough data for processing yet
                return audio_data
                
        except Exception as e:
            logger.error(f"Error in audio processing: {str(e)}")
            # Return original audio in case of error
            return audio_data
    
    def isolate_voice(self, audio_frame):
        """
        Isolate the main speaker's voice from other sounds
        This is a simplified implementation that would be enhanced with real voice isolation models
        """
        # In a real implementation, this would use a voice activity detection
        # and isolation model to filter out non-voice sounds
        # For now, we'll just apply a simple bandpass filter around speech frequencies
        
        # Simple bandpass filter parameters (speech is typically 300-3000 Hz)
        fs = self.sample_rate
        lowcut = 300.0
        highcut = 3000.0
        
        # Create a simple bandpass filter
        nyq = 0.5 * fs
        low = lowcut / nyq
        high = highcut / nyq
        
        # Apply a simple bandpass filter
        # This is a very simplified approach - a real solution would use more sophisticated algorithms
        from scipy import signal
        
        b, a = signal.butter(4, [low, high], btype='band')
        filtered_audio = signal.lfilter(b, a, audio_frame)
        
        return filtered_audio
