#!/usr/bin/env python3
"""
Voice Transformer Client Application

Main entry point for the Windows client application.
"""
import sys
import os
import logging
import json
import threading
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import socketio
import base64
import webbrowser
import configparser

from ui import VoiceTransformerUI
from audio_manager import AudioManager

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(os.path.expanduser("~"), "voice_transformer_client.log")),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class VoiceTransformerClient:
    """Main client application class for Voice Transformer"""
    
    def __init__(self):
        """Initialize the client application"""
        logger.info("Initializing Voice Transformer Client")
        
        # Initialize Socket.IO client
        self.sio = socketio.Client()
        self.setup_socket_events()
        
        # Server connection status
        self.connected = False
        self.server_url = "ws://localhost:5000"
        
        # Audio processing
        self.audio_manager = AudioManager(self)
        
        # Settings
        self.settings = {
            'noise_cancellation': True,
            'voice_isolation': True,
            'echo_cancellation': True,
            'accent': None,
            'gender': None,
            'voice_clone_id': None
        }
        
        # Available transformation options
        self.available_accents = []
        self.available_genders = []
        self.available_personas = []
        
        # Voice samples for cloning
        self.voice_samples = {}
        
        # Load configuration
        self.config = configparser.ConfigParser()
        self.config_path = os.path.join(os.path.expanduser("~"), ".voice_transformer_config.ini")
        self.load_config()
        
        # Setup UI
        self.root = tk.Tk()
        self.ui = VoiceTransformerUI(self.root, self)
        
        # First run detection for tutorial
        self.show_tutorial = self.config.getboolean('General', 'first_run', fallback=True)
        
        logger.info("Voice Transformer Client initialized")
    
    def load_config(self):
        """Load configuration from file or create default config"""
        try:
            self.config.read(self.config_path)
            
            # Create sections if they don't exist
            if not self.config.has_section('General'):
                self.config.add_section('General')
            
            if not self.config.has_section('Server'):
                self.config.add_section('Server')
            
            if not self.config.has_section('Audio'):
                self.config.add_section('Audio')
            
            # Load server URL from config
            if self.config.has_option('Server', 'url'):
                self.server_url = self.config.get('Server', 'url')
            else:
                self.config.set('Server', 'url', self.server_url)
            
            # Check if first run
            if not self.config.has_option('General', 'first_run'):
                self.config.set('General', 'first_run', 'true')
            
            self.save_config()
            
        except Exception as e:
            logger.error(f"Error loading configuration: {str(e)}")
            # Create default configuration
            self.create_default_config()
    
    def create_default_config(self):
        """Create default configuration file"""
        try:
            # General settings
            if not self.config.has_section('General'):
                self.config.add_section('General')
            self.config.set('General', 'first_run', 'true')
            
            # Server settings
            if not self.config.has_section('Server'):
                self.config.add_section('Server')
            self.config.set('Server', 'url', 'ws://localhost:5000')
            
            # Audio settings
            if not self.config.has_section('Audio'):
                self.config.add_section('Audio')
            self.config.set('Audio', 'buffer_size', '1024')
            
            self.save_config()
            
        except Exception as e:
            logger.error(f"Error creating default configuration: {str(e)}")
    
    def save_config(self):
        """Save configuration to file"""
        try:
            with open(self.config_path, 'w') as f:
                self.config.write(f)
        except Exception as e:
            logger.error(f"Error saving configuration: {str(e)}")
    
    def update_config_after_setup(self):
        """Update configuration after initial setup"""
        self.config.set('General', 'first_run', 'false')
        self.save_config()
    
    def setup_socket_events(self):
        """Setup Socket.IO event handlers"""
        
        @self.sio.event
        def connect():
            logger.info("Connected to server")
            self.connected = True
            if hasattr(self, 'ui'):
                self.ui.update_connection_status(True)
            
            # Fetch available transformation options
            self.fetch_transformation_options()
        
        @self.sio.event
        def disconnect():
            logger.info("Disconnected from server")
            self.connected = False
            if hasattr(self, 'ui'):
                self.ui.update_connection_status(False)
        
        @self.sio.event
        def connect_error(data):
            logger.error(f"Connection error: {data}")
            self.connected = False
            if hasattr(self, 'ui'):
                self.ui.update_connection_status(False)
                self.ui.show_error("Connection failed", f"Could not connect to server: {data}")
        
        @self.sio.event
        def connection_established(data):
            logger.info(f"Session established: {data['session_id']}")
            
            # Initialize with current settings
            self.update_server_settings()
        
        @self.sio.event
        def processed_audio(data):
            # Pass processed audio to the audio manager
            audio_data = data.get('audio')
            if audio_data:
                self.audio_manager.on_processed_audio(audio_data)
        
        @self.sio.event
        def settings_updated(data):
            logger.info(f"Settings updated: {data}")
        
        @self.sio.event
        def error(data):
            logger.error(f"Server error: {data['message']}")
            if hasattr(self, 'ui'):
                self.ui.show_error("Server Error", data['message'])
    
    def connect_to_server(self, server_url=None):
        """Connect to the server"""
        if server_url:
            self.server_url = server_url
            self.config.set('Server', 'url', server_url)
            self.save_config()
        
        try:
            if self.sio.connected:
                self.sio.disconnect()
            
            logger.info(f"Connecting to server: {self.server_url}")
            self.sio.connect(self.server_url)
            return True
        except Exception as e:
            logger.error(f"Error connecting to server: {str(e)}")
            if hasattr(self, 'ui'):
                self.ui.show_error("Connection Error", f"Failed to connect to {self.server_url}: {str(e)}")
            return False
    
    def disconnect_from_server(self):
        """Disconnect from the server"""
        if self.sio.connected:
            self.sio.disconnect()
            logger.info("Disconnected from server")
    
    def start_audio_stream(self):
        """Start the audio streaming process"""
        self.audio_manager.start()
    
    def stop_audio_stream(self):
        """Stop the audio streaming process"""
        self.audio_manager.stop()
    
    def send_audio_to_server(self, audio_data):
        """Send audio data to the server for processing"""
        if self.connected:
            try:
                # Convert numpy array to bytes if needed
                if hasattr(audio_data, 'tobytes'):
                    audio_bytes = audio_data.tobytes()
                else:
                    audio_bytes = audio_data
                
                # Encode as base64
                audio_b64 = base64.b64encode(audio_bytes).decode('utf-8')
                
                # Send to server
                self.sio.emit('audio_stream', {'audio': audio_b64})
            except Exception as e:
                logger.error(f"Error sending audio to server: {str(e)}")
    
    def update_server_settings(self):
        """Update voice transformation settings on the server"""
        if self.connected:
            logger.info(f"Updating server settings: {self.settings}")
            self.sio.emit('update_settings', self.settings)
    
    def update_settings(self, **kwargs):
        """Update client settings and sync with server"""
        # Update local settings
        for key, value in kwargs.items():
            if key in self.settings:
                self.settings[key] = value
        
        # Update server
        self.update_server_settings()
        
        # Update UI if needed
        if hasattr(self, 'ui'):
            self.ui.update_settings_display()
    
    def fetch_transformation_options(self):
        """Fetch available voice transformation options from server"""
        try:
            import requests
            
            # Extract base URL from WebSocket URL
            base_url = self.server_url.replace('ws://', 'http://').replace('wss://', 'https://')
            
            response = requests.get(f"{base_url}/api/available_transformations")
            if response.status_code == 200:
                data = response.json()
                
                self.available_accents = data.get('accents', [])
                self.available_genders = data.get('genders', [])
                self.available_personas = data.get('personas', [])
                
                # Update UI with options
                if hasattr(self, 'ui'):
                    self.ui.update_transformation_options()
                
                logger.info("Fetched transformation options from server")
            else:
                logger.error(f"Failed to fetch transformation options: {response.status_code}")
                
        except Exception as e:
            logger.error(f"Error fetching transformation options: {str(e)}")
    
    def upload_voice_sample(self, file_path):
        """Upload a voice sample to the server for cloning"""
        try:
            import requests
            
            # Extract base URL from WebSocket URL
            base_url = self.server_url.replace('ws://', 'http://').replace('wss://', 'https://')
            
            # Read audio file
            with open(file_path, 'rb') as f:
                files = {'sample': f}
                
                # Upload to server
                response = requests.post(f"{base_url}/api/upload_voice_sample", files=files)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data.get('success'):
                        sample_id = data.get('sample_id')
                        
                        # Store sample info
                        self.voice_samples[sample_id] = {
                            'name': os.path.basename(file_path),
                            'path': file_path,
                            'id': sample_id
                        }
                        
                        # Update UI
                        if hasattr(self, 'ui'):
                            self.ui.update_voice_samples()
                        
                        logger.info(f"Voice sample {sample_id} uploaded successfully")
                        
                        return sample_id
                    else:
                        error_msg = data.get('error', 'Unknown error')
                        logger.error(f"Error uploading voice sample: {error_msg}")
                        if hasattr(self, 'ui'):
                            self.ui.show_error("Upload Error", f"Failed to upload voice sample: {error_msg}")
                        return None
                else:
                    logger.error(f"Failed to upload voice sample: {response.status_code}")
                    if hasattr(self, 'ui'):
                        self.ui.show_error("Upload Error", f"Server returned error {response.status_code}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error uploading voice sample: {str(e)}")
            if hasattr(self, 'ui'):
                self.ui.show_error("Upload Error", f"Failed to upload voice sample: {str(e)}")
            return None
    
    def open_user_guide(self):
        """Open the user guide in a web browser"""
        guide_url = self.server_url.replace('ws://', 'http://').replace('wss://', 'https://') + "/user_guide"
        try:
            webbrowser.open(guide_url)
        except Exception as e:
            logger.error(f"Error opening user guide: {str(e)}")
            if hasattr(self, 'ui'):
                self.ui.show_error("Error", f"Failed to open user guide: {str(e)}")
    
    def exit_application(self):
        """Clean up and exit the application"""
        logger.info("Exiting application")
        
        # Stop audio processing
        self.stop_audio_stream()
        
        # Disconnect from server
        self.disconnect_from_server()
        
        # Save configuration
        self.save_config()
        
        # Exit
        if hasattr(self, 'root'):
            self.root.destroy()
        
        sys.exit(0)
    
    def run(self):
        """Run the client application"""
        # Show tutorial if first run
        if self.show_tutorial:
            self.ui.show_tutorial()
        
        # Start UI main loop
        self.root.mainloop()

if __name__ == "__main__":
    client = VoiceTransformerClient()
    client.run()
