/**
 * Voice Transformer - Main JavaScript
 * 
 * Handles client-side functionality for the web interface
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Check if on download page to handle download functionality
    if (window.location.pathname.includes('/download')) {
        setupDownloadHandlers();
    }

    // Check if on index page to potentially setup demo
    if (window.location.pathname === '/' || window.location.pathname === '/index.html') {
        setupHomePageInteractivity();
    }
});

/**
 * Setup handlers for the download page
 */
function setupDownloadHandlers() {
    // Fetch client download information
    fetch('/api/client_download')
        .then(response => response.json())
        .then(data => {
            const downloadButtons = document.querySelectorAll('a[href="/download/voicetransform_client_setup.exe"]');
            downloadButtons.forEach(button => {
                button.href = data.download_url;
            });

            // Update version information if available
            const versionElements = document.querySelectorAll('.version-info');
            versionElements.forEach(element => {
                element.textContent = `Version ${data.version}`;
            });
        })
        .catch(error => {
            console.error('Error fetching download information:', error);
        });
}

/**
 * Setup interactivity for the home page
 */
function setupHomePageInteractivity() {
    // Create animated sound bars for visual effect
    createSoundBars();
    
    // Check if WebSocket is available for demonstrations
    if (typeof WebSocket !== 'undefined') {
        // We only setup demo functionality if we're on the home page
        setupFeatureDemo();
    }
}

/**
 * Create animated sound bars for visual elements
 */
function createSoundBars() {
    const visualizers = document.querySelectorAll('.audio-visualizer');
    
    visualizers.forEach(visualizer => {
        // Create individual bars
        for (let i = 0; i < 30; i++) {
            const bar = document.createElement('div');
            bar.className = 'audio-visualizer-bar';
            
            // Random initial height
            const height = Math.floor(Math.random() * 100);
            bar.style.height = `${height}%`;
            
            visualizer.appendChild(bar);
        }
        
        // Start animation
        animateVisualizer(visualizer);
    });
}

/**
 * Animate sound bars in visualizers
 */
function animateVisualizer(visualizer) {
    const bars = visualizer.querySelectorAll('.audio-visualizer-bar');
    
    setInterval(() => {
        bars.forEach(bar => {
            // Random height for animation effect
            const height = Math.floor(Math.random() * 100);
            bar.style.height = `${height}%`;
        });
    }, 100);
}

/**
 * Setup demonstration functionality for the feature showcase
 */
function setupFeatureDemo() {
    // Check for available transformations to display in demo
    fetch('/api/available_transformations')
        .then(response => response.json())
        .then(data => {
            // We could use this data to populate demo dropdowns
            // or showcase available features
            console.log('Available transformations:', data);
        })
        .catch(error => {
            console.error('Error fetching transformation options:', error);
        });
    
    // Setup demo buttons if they exist
    const demoButtons = document.querySelectorAll('.demo-feature');
    
    demoButtons.forEach(button => {
        button.addEventListener('click', function() {
            const featureType = this.dataset.feature;
            
            // Visual feedback for button click
            this.classList.add('pulse-animation');
            setTimeout(() => {
                this.classList.remove('pulse-animation');
            }, 2000);
            
            // Show feature demo modal if implemented
            showFeatureDemo(featureType);
        });
    });
}

/**
 * Display a modal demonstrating a specific feature
 */
function showFeatureDemo(featureType) {
    // This would show a modal with a visual/audio demonstration
    // of the selected feature - in a real implementation
    console.log(`Showing demo for: ${featureType}`);
    
    // We would create and display a modal here in a full implementation
}
