# Dexent.ai Controller - Windows Desktop Application

This Windows desktop application provides a user-friendly interface to control and monitor your Dexent.ai accent conversion system.

## Features

- **Real-time System Monitoring**: Monitor the status of all AI models and server components
- **Audio Conversion**: Convert audio files to different accents with customizable settings
- **AI Assistant Management**: Access the AI Assistant for diagnostics and system optimization
- **System Management**: Create backups, restore from backups, and restart the server
- **Settings Management**: Configure server connection and application preferences

## Installation

### Prerequisites

- Windows 10 or later
- Python 3.8 or later
- PyQt5 library

### Installation Steps

1. **Install Python** (if not already installed):
   - Download and install Python from [python.org](https://python.org)
   - During installation, make sure to check "Add Python to PATH"

2. **Install Required Dependencies**:
   - Open Command Prompt as Administrator
   - Run the following command:
     ```
     pip install PyQt5 requests
     ```

3. **Download the Dexent.ai Controller Application**:
   - Download the application files from this directory
   - Save them to a location on your computer (e.g., `C:\Dexent`)

## Usage

### Starting the Application

1. Navigate to the directory where you saved the application files
2. Run the application by double-clicking on `dexent_controller.py` or using the command:
   ```
   python dexent_controller.py
   ```

### Creating a Desktop Shortcut (Optional)

1. Right-click on the desktop and select "New > Shortcut"
2. In the location field, enter:
   ```
   pythonw "C:\path\to\dexent_controller.py"
   ```
   (Replace `C:\path\to\` with the actual path where you saved the file)
3. Click "Next" and give the shortcut a name (e.g., "Dexent.ai Controller")
4. Click "Finish"

### Using the Application

#### Dashboard Tab

The Dashboard tab provides an overview of the server status:

1. **Server Connection**: Shows the current connection status to the Dexent.ai server
   - Click "Connect to Server" to establish a connection
   
2. **Model Status**: Displays the status of each AI model component
   - Voice Activity Detection (VAD)
   - Speaker Embedding
   - Accent Converter
   
3. **System Metrics**: Shows real-time performance metrics
   - CPU Usage
   - Memory Usage
   - API Latency
   - Active Connections
   
4. **Server Control**: Provides buttons to manage the server
   - Restart Server
   - Create Backup
   - Restore Backup

#### Audio Conversion Tab

The Audio Conversion tab allows you to convert audio files:

1. **Audio File Selection**:
   - Click "Browse..." to select an audio file (WAV, MP3, AAC, OGG, or FLAC)
   
2. **Target Accent**: Select the desired target accent from the dropdown menu

3. **Conversion Options**:
   - Preserve Speaker Identity: Enable/disable preserving the speaker's voice characteristics
   - Conversion Quality: Select Low, Medium, or High quality (higher quality may take longer)
   
4. **Conversion Control**:
   - Click "Convert Audio" to start the conversion process
   - The progress bar shows the conversion progress
   
5. **Conversion History**: Displays a history of your conversions

#### AI Assistant Tab

The AI Assistant tab provides access to the AI system's self-monitoring capabilities:

1. **AI Assistant Status**: Shows the current status of the AI Assistant

2. **System Diagnostics**:
   - Select a component to diagnose
   - Click "Run Diagnostics" to analyze the selected component
   - Click "Fix Issues" to attempt automatic repair of identified issues
   
3. **Improvement Suggestions**: Shows recommendations for system improvements
   - Click "Refresh Suggestions" to get the latest recommendations
   
4. **Performance Metrics**: Displays detailed performance metrics
   - Click "Refresh Metrics" to get the latest metrics

#### Settings Tab

The Settings tab allows you to configure the application:

1. **Server Connection Settings**:
   - Host: The hostname or IP address of the Dexent.ai server (default: localhost)
   - Port: The port number (default: 5000)
   - Protocol: HTTP or HTTPS
   
2. **Application Settings**:
   - Auto-connect on startup: Automatically connect to the server when the application starts
   - Check for updates: Enable/disable automatic update checks
   - Log level: Set the logging detail level

## Packaging for Distribution (For Developers)

To create a standalone executable for Windows:

1. Install PyInstaller:
   ```
   pip install pyinstaller
   ```

2. Navigate to the directory containing `dexent_controller.py`

3. Run PyInstaller:
   ```
   pyinstaller --onefile --windowed --icon=icon.ico dexent_controller.py
   ```
   (Replace `icon.ico` with an appropriate icon file if available)

4. The executable will be created in the `dist` directory

## Troubleshooting

### Common Issues

1. **Cannot connect to server**:
   - Verify the server is running
   - Check the server address and port in the Settings tab
   - Ensure no firewall is blocking the connection

2. **"Module not found" error when starting the application**:
   - Open Command Prompt and run:
     ```
     pip install PyQt5 requests
     ```

3. **Conversion fails**:
   - Check that the audio file format is supported
   - Verify the server has all models loaded
   - Check the AI Assistant diagnostics for any system issues

### Getting Help

If you encounter any issues:

1. Check the application logs located in the same directory as the application (dexent_controller.log)
2. Run diagnostics through the AI Assistant tab
3. Contact support with details of the issue and any error messages

## License

This application is proprietary software of Dexent.ai.