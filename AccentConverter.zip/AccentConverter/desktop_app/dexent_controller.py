"""
Dexent.ai Controller Desktop Application

This application provides a graphical interface to control and monitor 
the Dexent.ai accent conversion system.
"""
import os
import sys
import json
import time
import logging
import threading
import requests
from datetime import datetime
from pathlib import Path

try:
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QHBoxLayout,
        QPushButton, QLabel, QComboBox, QTextEdit, QLineEdit, QFileDialog,
        QProgressBar, QMessageBox, QGroupBox, QFormLayout, QCheckBox, QSpinBox,
        QSplitter, QTableWidget, QTableWidgetItem, QHeaderView
    )
    from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer, QSettings
    from PyQt5.QtGui import QIcon, QFont, QPixmap
except ImportError:
    print("PyQt5 is required. Please install it with: pip install PyQt5")
    sys.exit(1)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("dexent_controller.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("DexentController")

# Default server settings
DEFAULT_HOST = "localhost"
DEFAULT_PORT = 5000
DEFAULT_PROTOCOL = "http"

class ServerMonitorThread(QThread):
    """Thread to monitor server status."""
    status_update = pyqtSignal(dict)
    
    def __init__(self, host, port, protocol):
        super().__init__()
        self.host = host
        self.port = port
        self.protocol = protocol
        self.running = True
        self.interval = 2  # seconds
    
    def run(self):
        while self.running:
            try:
                url = f"{self.protocol}://{self.host}:{self.port}/check_system"
                response = requests.get(url, timeout=5)
                
                if response.status_code == 200:
                    self.status_update.emit(response.json())
                else:
                    self.status_update.emit({"status": "error", "message": f"Server returned {response.status_code}"})
            except requests.exceptions.RequestException as e:
                self.status_update.emit({"status": "error", "message": str(e)})
            
            # Sleep for the interval
            time.sleep(self.interval)
    
    def stop(self):
        self.running = False


class AIAssistantMonitorThread(QThread):
    """Thread to monitor AI Assistant status."""
    assistant_update = pyqtSignal(dict)
    
    def __init__(self, host, port, protocol):
        super().__init__()
        self.host = host
        self.port = port
        self.protocol = protocol
        self.running = True
        self.interval = 5  # seconds
    
    def run(self):
        while self.running:
            try:
                url = f"{self.protocol}://{self.host}:{self.port}/api/assistant/status"
                response = requests.get(url, timeout=5)
                
                if response.status_code == 200:
                    self.assistant_update.emit(response.json())
                else:
                    self.assistant_update.emit({"status": "error", "message": f"Server returned {response.status_code}"})
            except requests.exceptions.RequestException as e:
                self.assistant_update.emit({"status": "error", "message": str(e)})
            
            # Sleep for the interval
            time.sleep(self.interval)
    
    def stop(self):
        self.running = False


class AudioConversionThread(QThread):
    """Thread to handle audio conversion."""
    progress_update = pyqtSignal(int)
    conversion_complete = pyqtSignal(str, bool)
    
    def __init__(self, host, port, protocol, audio_path, target_accent):
        super().__init__()
        self.host = host
        self.port = port
        self.protocol = protocol
        self.audio_path = audio_path
        self.target_accent = target_accent
        self.output_path = None
    
    def run(self):
        try:
            # Prepare the output path
            input_path = Path(self.audio_path)
            self.output_path = str(input_path.parent / f"{input_path.stem}_converted_{self.target_accent}{input_path.suffix}")
            
            self.progress_update.emit(10)
            
            # Prepare request
            url = f"{self.protocol}://{self.host}:{self.port}/process_audio"
            files = {"audio": open(self.audio_path, "rb")}
            data = {"target_accent": self.target_accent}
            
            self.progress_update.emit(30)
            
            # Send request
            response = requests.post(url, files=files, data=data)
            
            self.progress_update.emit(70)
            
            if response.status_code == 200:
                # Save the converted audio
                with open(self.output_path, "wb") as f:
                    f.write(response.content)
                self.progress_update.emit(100)
                self.conversion_complete.emit(self.output_path, True)
            else:
                error_msg = f"Error: Server returned {response.status_code}"
                if response.headers.get("Content-Type") == "application/json":
                    error_msg += f" - {response.json().get('error', '')}"
                self.conversion_complete.emit(error_msg, False)
        except Exception as e:
            logger.error(f"Conversion error: {e}")
            self.conversion_complete.emit(f"Error: {str(e)}", False)


class MainWindow(QMainWindow):
    """Main window for the Dexent.ai Controller application."""
    
    def __init__(self):
        super().__init__()
        self.initUI()
        self.loadSettings()
        self.startMonitoring()
    
    def initUI(self):
        """Initialize the user interface."""
        self.setWindowTitle("Dexent.ai Controller")
        self.setGeometry(100, 100, 1000, 700)
        
        # Create the central widget and main layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        
        # Create the tab widget
        tab_widget = QTabWidget()
        main_layout.addWidget(tab_widget)
        
        # Create tabs
        dashboard_tab = QWidget()
        conversion_tab = QWidget()
        ai_assistant_tab = QWidget()
        settings_tab = QWidget()
        
        tab_widget.addTab(dashboard_tab, "Dashboard")
        tab_widget.addTab(conversion_tab, "Audio Conversion")
        tab_widget.addTab(ai_assistant_tab, "AI Assistant")
        tab_widget.addTab(settings_tab, "Settings")
        
        # Initialize all tabs
        self.initDashboardTab(dashboard_tab)
        self.initConversionTab(conversion_tab)
        self.initAIAssistantTab(ai_assistant_tab)
        self.initSettingsTab(settings_tab)
        
        # Status bar
        self.statusBar().showMessage("Ready")
        
        # Initialize server connection info
        self.server_host = DEFAULT_HOST
        self.server_port = DEFAULT_PORT
        self.server_protocol = DEFAULT_PROTOCOL
        
        # Initialize threads
        self.server_monitor = None
        self.ai_assistant_monitor = None
        self.conversion_thread = None
    
    def initDashboardTab(self, tab):
        """Initialize the Dashboard tab."""
        layout = QVBoxLayout(tab)
        
        # Server connection status
        connection_group = QGroupBox("Server Connection")
        connection_layout = QVBoxLayout(connection_group)
        
        self.connection_status_label = QLabel("Status: Not Connected")
        connection_layout.addWidget(self.connection_status_label)
        
        # Connect button
        connect_btn = QPushButton("Connect to Server")
        connect_btn.clicked.connect(self.connectToServer)
        connection_layout.addWidget(connect_btn)
        
        layout.addWidget(connection_group)
        
        # Model status
        models_group = QGroupBox("Model Status")
        models_layout = QFormLayout(models_group)
        
        self.vad_status_label = QLabel("Not loaded")
        self.speaker_embedding_status_label = QLabel("Not loaded")
        self.accent_converter_status_label = QLabel("Not loaded")
        
        models_layout.addRow("Voice Activity Detection (VAD):", self.vad_status_label)
        models_layout.addRow("Speaker Embedding:", self.speaker_embedding_status_label)
        models_layout.addRow("Accent Converter:", self.accent_converter_status_label)
        
        layout.addWidget(models_group)
        
        # System metrics
        metrics_group = QGroupBox("System Metrics")
        metrics_layout = QFormLayout(metrics_group)
        
        self.cpu_usage_label = QLabel("N/A")
        self.memory_usage_label = QLabel("N/A")
        self.api_latency_label = QLabel("N/A")
        self.active_connections_label = QLabel("N/A")
        
        metrics_layout.addRow("CPU Usage:", self.cpu_usage_label)
        metrics_layout.addRow("Memory Usage:", self.memory_usage_label)
        metrics_layout.addRow("API Latency:", self.api_latency_label)
        metrics_layout.addRow("Active Connections:", self.active_connections_label)
        
        layout.addWidget(metrics_group)
        
        # Server control
        control_group = QGroupBox("Server Control")
        control_layout = QHBoxLayout(control_group)
        
        restart_btn = QPushButton("Restart Server")
        restart_btn.clicked.connect(self.restartServer)
        
        backup_btn = QPushButton("Create Backup")
        backup_btn.clicked.connect(self.createBackup)
        
        restore_btn = QPushButton("Restore Backup")
        restore_btn.clicked.connect(self.showRestoreDialog)
        
        control_layout.addWidget(restart_btn)
        control_layout.addWidget(backup_btn)
        control_layout.addWidget(restore_btn)
        
        layout.addWidget(control_group)
        
        # Add spacer to push everything to the top
        layout.addStretch()
    
    def initConversionTab(self, tab):
        """Initialize the Audio Conversion tab."""
        layout = QVBoxLayout(tab)
        
        # Audio file selection
        file_group = QGroupBox("Audio File")
        file_layout = QHBoxLayout(file_group)
        
        self.audio_path_input = QLineEdit()
        self.audio_path_input.setPlaceholderText("Select an audio file...")
        self.audio_path_input.setReadOnly(True)
        
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self.browseAudioFile)
        
        file_layout.addWidget(self.audio_path_input)
        file_layout.addWidget(browse_btn)
        
        layout.addWidget(file_group)
        
        # Accent selection
        accent_group = QGroupBox("Target Accent")
        accent_layout = QVBoxLayout(accent_group)
        
        self.accent_combo = QComboBox()
        self.accent_combo.addItems(["american", "british", "australian"])
        
        accent_layout.addWidget(self.accent_combo)
        
        layout.addWidget(accent_group)
        
        # Conversion options
        options_group = QGroupBox("Conversion Options")
        options_layout = QFormLayout(options_group)
        
        self.preserve_identity_check = QCheckBox()
        self.preserve_identity_check.setChecked(True)
        
        self.conversion_quality_combo = QComboBox()
        self.conversion_quality_combo.addItems(["Low", "Medium", "High"])
        self.conversion_quality_combo.setCurrentIndex(1)  # Medium by default
        
        options_layout.addRow("Preserve Speaker Identity:", self.preserve_identity_check)
        options_layout.addRow("Conversion Quality:", self.conversion_quality_combo)
        
        layout.addWidget(options_group)
        
        # Conversion control
        control_group = QGroupBox("Conversion Control")
        control_layout = QVBoxLayout(control_group)
        
        self.conversion_progress = QProgressBar()
        self.conversion_progress.setValue(0)
        
        control_layout.addWidget(self.conversion_progress)
        
        convert_btn = QPushButton("Convert Audio")
        convert_btn.clicked.connect(self.convertAudio)
        convert_btn.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; padding: 10px;")
        
        control_layout.addWidget(convert_btn)
        
        layout.addWidget(control_group)
        
        # Conversion history
        history_group = QGroupBox("Conversion History")
        history_layout = QVBoxLayout(history_group)
        
        self.history_table = QTableWidget(0, 4)
        self.history_table.setHorizontalHeaderLabels(["Time", "Source", "Target Accent", "Output File"])
        self.history_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        history_layout.addWidget(self.history_table)
        
        layout.addWidget(history_group)
    
    def initAIAssistantTab(self, tab):
        """Initialize the AI Assistant tab."""
        layout = QVBoxLayout(tab)
        
        # AI Assistant status
        status_group = QGroupBox("AI Assistant Status")
        status_layout = QFormLayout(status_group)
        
        self.ai_status_label = QLabel("Not connected")
        self.ai_monitoring_label = QLabel("Not running")
        
        status_layout.addRow("Status:", self.ai_status_label)
        status_layout.addRow("Monitoring:", self.ai_monitoring_label)
        
        layout.addWidget(status_group)
        
        # Diagnostics
        diagnostics_group = QGroupBox("System Diagnostics")
        diagnostics_layout = QVBoxLayout(diagnostics_group)
        
        diagnose_layout = QHBoxLayout()
        self.diagnose_combo = QComboBox()
        self.diagnose_combo.addItems(["vad", "speaker_embedding", "accent_model", "server", "audio_processing"])
        
        diagnose_btn = QPushButton("Run Diagnostics")
        diagnose_btn.clicked.connect(self.runDiagnostics)
        
        fix_btn = QPushButton("Fix Issues")
        fix_btn.clicked.connect(self.fixIssues)
        
        diagnose_layout.addWidget(self.diagnose_combo)
        diagnose_layout.addWidget(diagnose_btn)
        diagnose_layout.addWidget(fix_btn)
        
        self.diagnostics_output = QTextEdit()
        self.diagnostics_output.setReadOnly(True)
        
        diagnostics_layout.addLayout(diagnose_layout)
        diagnostics_layout.addWidget(self.diagnostics_output)
        
        layout.addWidget(diagnostics_group)
        
        # Suggestions
        suggestions_group = QGroupBox("Improvement Suggestions")
        suggestions_layout = QVBoxLayout(suggestions_group)
        
        refresh_suggestions_btn = QPushButton("Refresh Suggestions")
        refresh_suggestions_btn.clicked.connect(self.refreshSuggestions)
        
        self.suggestions_list = QTextEdit()
        self.suggestions_list.setReadOnly(True)
        
        suggestions_layout.addWidget(refresh_suggestions_btn)
        suggestions_layout.addWidget(self.suggestions_list)
        
        layout.addWidget(suggestions_group)
        
        # Performance metrics
        metrics_group = QGroupBox("Performance Metrics")
        metrics_layout = QVBoxLayout(metrics_group)
        
        refresh_metrics_btn = QPushButton("Refresh Metrics")
        refresh_metrics_btn.clicked.connect(self.refreshMetrics)
        
        self.metrics_output = QTextEdit()
        self.metrics_output.setReadOnly(True)
        
        metrics_layout.addWidget(refresh_metrics_btn)
        metrics_layout.addWidget(self.metrics_output)
        
        layout.addWidget(metrics_group)
    
    def initSettingsTab(self, tab):
        """Initialize the Settings tab."""
        layout = QVBoxLayout(tab)
        
        # Server connection settings
        connection_group = QGroupBox("Server Connection")
        connection_layout = QFormLayout(connection_group)
        
        self.host_input = QLineEdit(DEFAULT_HOST)
        self.port_input = QSpinBox()
        self.port_input.setRange(1, 65535)
        self.port_input.setValue(DEFAULT_PORT)
        self.protocol_combo = QComboBox()
        self.protocol_combo.addItems(["http", "https"])
        
        connection_layout.addRow("Host:", self.host_input)
        connection_layout.addRow("Port:", self.port_input)
        connection_layout.addRow("Protocol:", self.protocol_combo)
        
        save_connection_btn = QPushButton("Save Connection Settings")
        save_connection_btn.clicked.connect(self.saveConnectionSettings)
        
        connection_layout.addRow("", save_connection_btn)
        
        layout.addWidget(connection_group)
        
        # Application settings
        app_settings_group = QGroupBox("Application Settings")
        app_settings_layout = QFormLayout(app_settings_group)
        
        self.auto_connect_check = QCheckBox()
        self.check_updates_check = QCheckBox()
        self.log_level_combo = QComboBox()
        self.log_level_combo.addItems(["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"])
        self.log_level_combo.setCurrentIndex(1)  # INFO by default
        
        app_settings_layout.addRow("Auto-connect on startup:", self.auto_connect_check)
        app_settings_layout.addRow("Check for updates:", self.check_updates_check)
        app_settings_layout.addRow("Log level:", self.log_level_combo)
        
        save_app_settings_btn = QPushButton("Save Application Settings")
        save_app_settings_btn.clicked.connect(self.saveAppSettings)
        
        app_settings_layout.addRow("", save_app_settings_btn)
        
        layout.addWidget(app_settings_group)
        
        # Add spacer to push everything to the top
        layout.addStretch()
    
    def loadSettings(self):
        """Load saved settings."""
        settings = QSettings("Dexent", "Controller")
        
        # Server connection settings
        self.host_input.setText(settings.value("server/host", DEFAULT_HOST))
        self.port_input.setValue(int(settings.value("server/port", DEFAULT_PORT)))
        protocol_index = self.protocol_combo.findText(settings.value("server/protocol", DEFAULT_PROTOCOL))
        self.protocol_combo.setCurrentIndex(protocol_index if protocol_index >= 0 else 0)
        
        # Application settings
        self.auto_connect_check.setChecked(settings.value("app/auto_connect", False, type=bool))
        self.check_updates_check.setChecked(settings.value("app/check_updates", True, type=bool))
        log_level_index = self.log_level_combo.findText(settings.value("app/log_level", "INFO"))
        self.log_level_combo.setCurrentIndex(log_level_index if log_level_index >= 0 else 1)
        
        # Apply connection settings
        self.server_host = self.host_input.text()
        self.server_port = self.port_input.value()
        self.server_protocol = self.protocol_combo.currentText()
        
        # Auto-connect if enabled
        if self.auto_connect_check.isChecked():
            self.connectToServer()
    
    def saveConnectionSettings(self):
        """Save server connection settings."""
        settings = QSettings("Dexent", "Controller")
        
        settings.setValue("server/host", self.host_input.text())
        settings.setValue("server/port", self.port_input.value())
        settings.setValue("server/protocol", self.protocol_combo.currentText())
        
        # Apply connection settings
        self.server_host = self.host_input.text()
        self.server_port = self.port_input.value()
        self.server_protocol = self.protocol_combo.currentText()
        
        QMessageBox.information(self, "Settings Saved", "Connection settings have been saved.")
        
        # Restart monitoring with new settings
        self.stopMonitoring()
        self.startMonitoring()
    
    def saveAppSettings(self):
        """Save application settings."""
        settings = QSettings("Dexent", "Controller")
        
        settings.setValue("app/auto_connect", self.auto_connect_check.isChecked())
        settings.setValue("app/check_updates", self.check_updates_check.isChecked())
        settings.setValue("app/log_level", self.log_level_combo.currentText())
        
        # Apply log level settings
        log_level = getattr(logging, self.log_level_combo.currentText())
        logger.setLevel(log_level)
        
        QMessageBox.information(self, "Settings Saved", "Application settings have been saved.")
    
    def startMonitoring(self):
        """Start monitoring threads."""
        # Server monitor
        self.server_monitor = ServerMonitorThread(
            self.server_host, self.server_port, self.server_protocol
        )
        self.server_monitor.status_update.connect(self.updateServerStatus)
        self.server_monitor.start()
        
        # AI Assistant monitor
        self.ai_assistant_monitor = AIAssistantMonitorThread(
            self.server_host, self.server_port, self.server_protocol
        )
        self.ai_assistant_monitor.assistant_update.connect(self.updateAIAssistantStatus)
        self.ai_assistant_monitor.start()
    
    def stopMonitoring(self):
        """Stop monitoring threads."""
        if self.server_monitor and self.server_monitor.isRunning():
            self.server_monitor.stop()
            self.server_monitor.wait()
        
        if self.ai_assistant_monitor and self.ai_assistant_monitor.isRunning():
            self.ai_assistant_monitor.stop()
            self.ai_assistant_monitor.wait()
    
    def connectToServer(self):
        """Connect to the server."""
        self.statusBar().showMessage("Connecting to server...")
        
        try:
            url = f"{self.server_protocol}://{self.server_host}:{self.server_port}/check_system"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                self.connection_status_label.setText(f"Status: Connected to {self.server_protocol}://{self.server_host}:{self.server_port}")
                self.statusBar().showMessage("Connected to server")
                
                # Update the model status
                self.updateServerStatus(response.json())
                
                # Get available accents
                self.getAvailableAccents()
            else:
                self.connection_status_label.setText(f"Status: Error - Server returned {response.status_code}")
                self.statusBar().showMessage(f"Error connecting to server: {response.status_code}")
        except requests.exceptions.RequestException as e:
            self.connection_status_label.setText(f"Status: Error - {str(e)}")
            self.statusBar().showMessage(f"Error connecting to server: {str(e)}")
    
    def updateServerStatus(self, status_data):
        """Update the server status display."""
        if status_data.get("status") == "error":
            self.connection_status_label.setText(f"Status: Error - {status_data.get('message', 'Unknown error')}")
            return
        
        # Update model status
        models = status_data.get("models", {})
        
        self.vad_status_label.setText("Loaded" if models.get("vad", False) else "Not loaded")
        self.speaker_embedding_status_label.setText("Loaded" if models.get("speaker_embedding", False) else "Not loaded")
        self.accent_converter_status_label.setText("Loaded" if models.get("accent_converter", False) else "Not loaded")
        
        # Update status text
        status = status_data.get("status", "unknown")
        if status == "ready":
            self.connection_status_label.setText(f"Status: Connected - System Ready")
            self.connection_status_label.setStyleSheet("color: green;")
        elif status == "initializing":
            self.connection_status_label.setText(f"Status: Connected - System Initializing")
            self.connection_status_label.setStyleSheet("color: orange;")
        else:
            self.connection_status_label.setText(f"Status: Connected - System Status: {status}")
            self.connection_status_label.setStyleSheet("")
    
    def updateAIAssistantStatus(self, status_data):
        """Update the AI Assistant status display."""
        if status_data.get("status") == "error":
            self.ai_status_label.setText(f"Error: {status_data.get('message', 'Unknown error')}")
            return
        
        # Update AI status
        system_status = status_data.get("system_status", {})
        
        self.ai_status_label.setText(system_status.get("status", "Unknown"))
        self.ai_monitoring_label.setText("Running" if system_status.get("monitoring_active", False) else "Not running")
        
        # Update system metrics if available
        metrics = status_data.get("metrics", {})
        
        if metrics:
            self.cpu_usage_label.setText(f"{metrics.get('cpu_usage_percent', 'N/A')}%")
            self.memory_usage_label.setText(f"{metrics.get('memory_usage_mb', 'N/A')} MB")
            self.api_latency_label.setText(f"{metrics.get('api_latency_ms', 'N/A')} ms")
            self.active_connections_label.setText(f"{metrics.get('active_connections', 'N/A')}")
    
    def getAvailableAccents(self):
        """Get available accents from the server."""
        try:
            url = f"{self.server_protocol}://{self.server_host}:{self.server_port}/available_accents"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                accents = response.json()
                
                # Clear existing items
                self.accent_combo.clear()
                
                # Add available accents
                for accent_code, accent_name in accents.items():
                    self.accent_combo.addItem(accent_name, accent_code)
            else:
                logger.error(f"Failed to get available accents: {response.status_code}")
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting available accents: {e}")
    
    def browseAudioFile(self):
        """Open file dialog to browse for audio files."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Audio File", "", "Audio Files (*.wav *.mp3 *.aac *.ogg *.flac);;All Files (*)"
        )
        
        if file_path:
            self.audio_path_input.setText(file_path)
    
    def convertAudio(self):
        """Convert audio with selected settings."""
        audio_path = self.audio_path_input.text()
        
        if not audio_path:
            QMessageBox.warning(self, "No File Selected", "Please select an audio file to convert.")
            return
        
        # Get selected accent
        accent_index = self.accent_combo.currentIndex()
        if accent_index < 0:
            QMessageBox.warning(self, "No Accent Selected", "Please select a target accent.")
            return
        
        target_accent = self.accent_combo.itemData(accent_index) or self.accent_combo.currentText()
        
        # Reset progress bar
        self.conversion_progress.setValue(0)
        
        # Start conversion thread
        self.conversion_thread = AudioConversionThread(
            self.server_host, self.server_port, self.server_protocol, audio_path, target_accent
        )
        self.conversion_thread.progress_update.connect(self.conversion_progress.setValue)
        self.conversion_thread.conversion_complete.connect(self.conversionComplete)
        self.conversion_thread.start()
        
        self.statusBar().showMessage("Converting audio...")
    
    def conversionComplete(self, result, success):
        """Handle completion of audio conversion."""
        if success:
            QMessageBox.information(self, "Conversion Complete", f"Audio has been converted and saved to:\n{result}")
            self.statusBar().showMessage("Conversion complete")
            
            # Add to conversion history
            self.addConversionToHistory(self.audio_path_input.text(), self.accent_combo.currentText(), result)
        else:
            QMessageBox.critical(self, "Conversion Failed", f"Audio conversion failed:\n{result}")
            self.statusBar().showMessage("Conversion failed")
    
    def addConversionToHistory(self, source_path, target_accent, output_path):
        """Add conversion to history table."""
        row_position = self.history_table.rowCount()
        self.history_table.insertRow(row_position)
        
        # Add time
        time_item = QTableWidgetItem(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        self.history_table.setItem(row_position, 0, time_item)
        
        # Add source file
        source_item = QTableWidgetItem(os.path.basename(source_path))
        self.history_table.setItem(row_position, 1, source_item)
        
        # Add target accent
        accent_item = QTableWidgetItem(target_accent)
        self.history_table.setItem(row_position, 2, accent_item)
        
        # Add output file
        output_item = QTableWidgetItem(os.path.basename(output_path))
        self.history_table.setItem(row_position, 3, output_item)
    
    def runDiagnostics(self):
        """Run diagnostics on selected component."""
        component = self.diagnose_combo.currentText()
        
        self.diagnostics_output.setText(f"Running diagnostics on {component}...")
        
        try:
            url = f"{self.server_protocol}://{self.server_host}:{self.server_port}/api/assistant/diagnose/{component}"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                diagnostics = response.json()
                
                # Format the diagnostics output
                output = f"Diagnostics for {component}:\n\n"
                output += f"Status: {diagnostics.get('status', 'Unknown')}\n"
                
                if "details" in diagnostics:
                    output += "\nDetails:\n"
                    for key, value in diagnostics["details"].items():
                        output += f"  {key}: {value}\n"
                
                if "issues" in diagnostics:
                    output += "\nIssues:\n"
                    for issue in diagnostics["issues"]:
                        output += f"  - {issue}\n"
                
                if "suggestions" in diagnostics:
                    output += "\nSuggestions:\n"
                    for suggestion in diagnostics["suggestions"]:
                        output += f"  - {suggestion}\n"
                
                self.diagnostics_output.setText(output)
            else:
                self.diagnostics_output.setText(f"Error running diagnostics: Server returned {response.status_code}")
        except requests.exceptions.RequestException as e:
            self.diagnostics_output.setText(f"Error running diagnostics: {str(e)}")
    
    def fixIssues(self):
        """Fix issues with selected component."""
        component = self.diagnose_combo.currentText()
        
        reply = QMessageBox.question(
            self, "Confirm Fix", 
            f"Do you want to attempt to fix issues with the {component} component?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        
        if reply == QMessageBox.No:
            return
        
        self.diagnostics_output.setText(f"Attempting to fix issues with {component}...")
        
        try:
            url = f"{self.server_protocol}://{self.server_host}:{self.server_port}/api/assistant/fix/{component}"
            response = requests.get(url, timeout=20)
            
            if response.status_code == 200:
                result = response.json()
                
                # Format the result output
                output = f"Fix attempt for {component}:\n\n"
                output += f"Success: {result.get('success', False)}\n"
                
                if "message" in result:
                    output += f"\nMessage: {result['message']}\n"
                
                if "actions_taken" in result:
                    output += "\nActions Taken:\n"
                    for action in result["actions_taken"]:
                        output += f"  - {action}\n"
                
                if "next_steps" in result:
                    output += "\nNext Steps:\n"
                    for step in result["next_steps"]:
                        output += f"  - {step}\n"
                
                self.diagnostics_output.setText(output)
            else:
                self.diagnostics_output.setText(f"Error fixing issues: Server returned {response.status_code}")
        except requests.exceptions.RequestException as e:
            self.diagnostics_output.setText(f"Error fixing issues: {str(e)}")
    
    def refreshSuggestions(self):
        """Refresh improvement suggestions."""
        self.suggestions_list.setText("Loading suggestions...")
        
        try:
            url = f"{self.server_protocol}://{self.server_host}:{self.server_port}/api/assistant/suggestions"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                suggestions = response.json()
                
                if not suggestions:
                    self.suggestions_list.setText("No improvement suggestions available.")
                    return
                
                # Format the suggestions output
                output = "Improvement Suggestions:\n\n"
                for i, suggestion in enumerate(suggestions, 1):
                    output += f"{i}. {suggestion.get('title', 'Untitled')}\n"
                    output += f"   Priority: {suggestion.get('priority', 'Unknown')}\n"
                    output += f"   {suggestion.get('description', 'No description')}\n\n"
                
                self.suggestions_list.setText(output)
            else:
                self.suggestions_list.setText(f"Error getting suggestions: Server returned {response.status_code}")
        except requests.exceptions.RequestException as e:
            self.suggestions_list.setText(f"Error getting suggestions: {str(e)}")
    
    def refreshMetrics(self):
        """Refresh performance metrics."""
        self.metrics_output.setText("Loading metrics...")
        
        try:
            url = f"{self.server_protocol}://{self.server_host}:{self.server_port}/api/assistant/metrics"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                metrics = response.json()
                
                # Format the metrics output
                output = "Performance Metrics:\n\n"
                
                # System metrics
                if "system" in metrics:
                    output += "System Metrics:\n"
                    for key, value in metrics["system"].items():
                        output += f"  {key}: {value}\n"
                    output += "\n"
                
                # Model metrics
                if "models" in metrics:
                    output += "Model Metrics:\n"
                    for model, model_metrics in metrics["models"].items():
                        output += f"  {model}:\n"
                        for key, value in model_metrics.items():
                            output += f"    {key}: {value}\n"
                    output += "\n"
                
                # API metrics
                if "api" in metrics:
                    output += "API Metrics:\n"
                    for key, value in metrics["api"].items():
                        output += f"  {key}: {value}\n"
                    output += "\n"
                
                self.metrics_output.setText(output)
            else:
                self.metrics_output.setText(f"Error getting metrics: Server returned {response.status_code}")
        except requests.exceptions.RequestException as e:
            self.metrics_output.setText(f"Error getting metrics: {str(e)}")
    
    def restartServer(self):
        """Restart the server."""
        reply = QMessageBox.question(
            self, "Confirm Restart", 
            "Do you want to restart the server?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        
        if reply == QMessageBox.No:
            return
        
        try:
            url = f"{self.server_protocol}://{self.server_host}:{self.server_port}/api/assistant/restart"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                QMessageBox.information(self, "Restart Initiated", "Server restart has been initiated. Please wait a moment for the server to restart.")
                self.statusBar().showMessage("Server restarting...")
                
                # Wait a bit for the server to restart
                QTimer.singleShot(5000, self.connectToServer)
            else:
                QMessageBox.critical(self, "Restart Failed", f"Failed to restart server: {response.status_code}")
        except requests.exceptions.RequestException as e:
            QMessageBox.critical(self, "Restart Failed", f"Failed to restart server: {str(e)}")
    
    def createBackup(self):
        """Create a system backup."""
        try:
            url = f"{self.server_protocol}://{self.server_host}:{self.server_port}/api/assistant/backup"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                
                if result.get("success", False):
                    QMessageBox.information(
                        self, "Backup Created", 
                        f"System backup has been created:\nPath: {result.get('backup_path', 'Unknown')}"
                    )
                else:
                    QMessageBox.critical(
                        self, "Backup Failed", 
                        f"Failed to create backup: {result.get('error', 'Unknown error')}"
                    )
            else:
                QMessageBox.critical(self, "Backup Failed", f"Failed to create backup: {response.status_code}")
        except requests.exceptions.RequestException as e:
            QMessageBox.critical(self, "Backup Failed", f"Failed to create backup: {str(e)}")
    
    def showRestoreDialog(self):
        """Show dialog to restore from backup."""
        try:
            url = f"{self.server_protocol}://{self.server_host}:{self.server_port}/api/assistant/backups"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                backups = response.json()
                
                if not backups:
                    QMessageBox.information(self, "No Backups", "No backups are available to restore from.")
                    return
                
                # Create a dialog to select backup
                dialog = QDialog(self)
                dialog.setWindowTitle("Restore from Backup")
                dialog.setMinimumWidth(400)
                
                layout = QVBoxLayout(dialog)
                
                label = QLabel("Select a backup to restore from:")
                layout.addWidget(label)
                
                combo = QComboBox()
                for backup in backups:
                    combo.addItem(f"{backup.get('name')} - {backup.get('date')}", backup.get('path'))
                
                layout.addWidget(combo)
                
                buttons = QHBoxLayout()
                cancel_btn = QPushButton("Cancel")
                cancel_btn.clicked.connect(dialog.reject)
                
                restore_btn = QPushButton("Restore")
                restore_btn.clicked.connect(dialog.accept)
                
                buttons.addWidget(cancel_btn)
                buttons.addWidget(restore_btn)
                
                layout.addLayout(buttons)
                
                if dialog.exec_() == QDialog.Accepted:
                    backup_path = combo.currentData()
                    self.restoreFromBackup(backup_path)
            else:
                QMessageBox.critical(self, "Error", f"Failed to get backups: {response.status_code}")
        except requests.exceptions.RequestException as e:
            QMessageBox.critical(self, "Error", f"Failed to get backups: {str(e)}")
    
    def restoreFromBackup(self, backup_path):
        """Restore system from backup."""
        try:
            url = f"{self.server_protocol}://{self.server_host}:{self.server_port}/api/assistant/restore"
            response = requests.post(url, json={"backup_path": backup_path}, timeout=20)
            
            if response.status_code == 200:
                result = response.json()
                
                if result.get("success", False):
                    QMessageBox.information(
                        self, "Restore Complete", 
                        f"System has been restored from backup:\n{result.get('message', '')}"
                    )
                    
                    # Reconnect to server
                    self.connectToServer()
                else:
                    QMessageBox.critical(
                        self, "Restore Failed", 
                        f"Failed to restore from backup: {result.get('error', 'Unknown error')}"
                    )
            else:
                QMessageBox.critical(self, "Restore Failed", f"Failed to restore from backup: {response.status_code}")
        except requests.exceptions.RequestException as e:
            QMessageBox.critical(self, "Restore Failed", f"Failed to restore from backup: {str(e)}")
    
    def closeEvent(self, event):
        """Handle application close event."""
        self.stopMonitoring()
        event.accept()


def main():
    """Main application entry point."""
    app = QApplication(sys.argv)
    app.setStyle("Fusion")  # Use Fusion style for a modern look
    
    # Set application info for QSettings
    app.setOrganizationName("Dexent")
    app.setApplicationName("Controller")
    
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()