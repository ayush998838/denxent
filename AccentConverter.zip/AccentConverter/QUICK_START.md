# dexent.ai Clone Quick Start Guide

This document provides a quick guide to get started with the dexent.ai Clone application.

## 1. Getting Started

### Running the Application

The application is already set up and ready to use. To start:

```bash
python main.py
```

This will launch the web server on port 5000. You can access the application by opening your browser and navigating to:

```
http://localhost:5000
```

### Authentication

1. **Sign Up**: Create a new account by clicking "Sign Up" in the navigation bar.
   - You can use email/password or Google Sign-In
   - Your account information will be stored securely with Firebase

2. **Login**: If you already have an account, click "Login" to access your dashboard.

## 2. Using the Features

### Noise Cancellation

1. Navigate to the **Noise Cancellation** tab in your dashboard
2. Adjust settings as needed:
   - Noise Reduction Level (Low, Medium, High)
   - Echo Cancellation
   - Voice Enhancement
3. Test the feature by clicking the microphone icon
4. Use during any meeting by keeping the application running

### Meeting Assistant

1. Navigate to the **Meeting Assistant** tab in your dashboard
2. Configure settings:
   - Meeting Title
   - Platform (Zoom, Teams, etc.)
   - Recording options
   - Transcription options
3. Click "Start New Meeting" before your actual meeting begins
4. The assistant will automatically:
   - Record audio
   - Generate transcripts
   - Create summaries
   - Extract action items

### Accent Conversion

1. Navigate to the **Accent Conversion** tab in your dashboard
2. Select your desired target accent:
   - American English
   - British English
   - Australian English
   - Canadian English
   - Neutral English
3. Test the feature with the microphone button
4. Enable for all calls using the toggle switch

### Live Interpreter

1. Navigate to the **Live Interpreter** tab in your dashboard
2. Configure settings:
   - Source Language (or Auto-detect)
   - Target Language
   - Auto-Translation toggle
3. Test the feature by recording a sample
4. Enable for multilingual meetings

## 3. Viewing Analytics

The dashboard provides usage analytics:

- Total time using each feature
- Meeting count and statistics
- Daily usage patterns
- Feature usage breakdown

Access detailed statistics by clicking the **Stats** tab in the sidebar.

## 4. Managing Meetings

1. View all your meetings in the **Meetings** section
2. For each meeting, you can access:
   - Audio recordings
   - Transcripts
   - Summaries
   - Action items

## 5. Troubleshooting

If you encounter issues:

1. Check that your microphone is properly connected and has necessary permissions
2. Ensure you have a stable internet connection
3. Verify that all models are initialized (status shown in the dashboard)
4. Try refreshing the page or restarting the application

## 6. Privacy and Data

- All processing happens locally on the server
- Audio data is not stored permanently unless you explicitly save recordings
- Your preferences and settings are saved to your user profile
- Meeting transcripts and summaries are only accessible to you

## 7. Mobile Access

While the application is primarily designed for desktop use, the web interface is responsive and can be accessed on mobile devices.

For the best experience, we recommend using a desktop or laptop computer.

## 8. Support and Feedback

For support or to provide feedback, please open an issue in the GitHub repository or contact the development team directly.

---

Thank you for using dexent.ai Clone!