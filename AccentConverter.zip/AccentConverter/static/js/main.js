/**
 * Main JavaScript for dexent.ai Clone
 */

// Record audio for testing features
class AudioRecorder {
    constructor(options = {}) {
        this.options = {
            mimeType: 'audio/webm',
            audioBitsPerSecond: 128000,
            ...options
        };
        
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.isRecording = false;
        this.stream = null;
        
        // Callbacks
        this.onStart = null;
        this.onStop = null;
        this.onDataAvailable = null;
        this.onError = null;
    }
    
    async start() {
        try {
            if (this.isRecording) {
                return;
            }
            
            this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            this.mediaRecorder = new MediaRecorder(this.stream, this.options);
            this.audioChunks = [];
            
            this.mediaRecorder.addEventListener('dataavailable', (event) => {
                if (event.data.size > 0) {
                    this.audioChunks.push(event.data);
                }
                
                if (this.onDataAvailable) {
                    this.onDataAvailable(event.data);
                }
            });
            
            this.mediaRecorder.addEventListener('start', () => {
                this.isRecording = true;
                
                if (this.onStart) {
                    this.onStart();
                }
            });
            
            this.mediaRecorder.addEventListener('stop', () => {
                this.isRecording = false;
                
                const audioBlob = new Blob(this.audioChunks, { type: this.options.mimeType });
                
                if (this.onStop) {
                    this.onStop(audioBlob);
                }
                
                // Stop all tracks
                this.stream.getTracks().forEach(track => track.stop());
                this.stream = null;
            });
            
            this.mediaRecorder.start();
            
        } catch (error) {
            console.error('Error starting recording:', error);
            
            if (this.onError) {
                this.onError(error);
            }
        }
    }
    
    stop() {
        if (!this.isRecording || !this.mediaRecorder) {
            return;
        }
        
        this.mediaRecorder.stop();
    }
    
    cancel() {
        if (this.isRecording && this.mediaRecorder) {
            this.mediaRecorder.stop();
        }
        
        this.audioChunks = [];
        
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }
    }
}

// Feature testing functions
document.addEventListener('DOMContentLoaded', function() {
    // Initialize audio recording buttons
    initializeNoiseTestButton();
    initializeAccentTestButton();
    initializeTranslationTestButton();
    
    // Initialize audio visualizers
    initializeVisualizers();
});

function initializeNoiseTestButton() {
    const button = document.getElementById('noise-test-button');
    if (!button) return;
    
    let recorder = new AudioRecorder();
    
    button.addEventListener('click', function() {
        if (recorder.isRecording) {
            // Stop recording
            button.classList.remove('recording');
            recorder.stop();
        } else {
            // Start recording
            button.classList.add('recording');
            
            // Set recorder callbacks
            recorder.onStop = (audioBlob) => {
                // Create original audio player
                const originalAudio = document.getElementById('original-audio');
                const originalAudioURL = URL.createObjectURL(audioBlob);
                originalAudio.src = originalAudioURL;
                
                // Process audio with noise reduction
                processNoiseReduction(audioBlob);
            };
            
            recorder.onError = (error) => {
                alert('Error recording audio: ' + error.message);
                button.classList.remove('recording');
            };
            
            // Start recording
            recorder.start();
        }
    });
}

function initializeAccentTestButton() {
    const button = document.getElementById('accent-test-button');
    if (!button) return;
    
    let recorder = new AudioRecorder();
    
    button.addEventListener('click', function() {
        if (recorder.isRecording) {
            // Stop recording
            button.classList.remove('recording');
            recorder.stop();
        } else {
            // Start recording
            button.classList.add('recording');
            
            // Set recorder callbacks
            recorder.onStop = (audioBlob) => {
                // Create original audio player
                const originalAudio = document.getElementById('original-accent-audio');
                const originalAudioURL = URL.createObjectURL(audioBlob);
                originalAudio.src = originalAudioURL;
                
                // Process audio with accent conversion
                processAccentConversion(audioBlob);
            };
            
            recorder.onError = (error) => {
                alert('Error recording audio: ' + error.message);
                button.classList.remove('recording');
            };
            
            // Start recording
            recorder.start();
        }
    });
}

function initializeTranslationTestButton() {
    const button = document.getElementById('translation-test-button');
    if (!button) return;
    
    let recorder = new AudioRecorder();
    
    button.addEventListener('click', function() {
        if (recorder.isRecording) {
            // Stop recording
            button.classList.remove('recording');
            recorder.stop();
        } else {
            // Start recording
            button.classList.add('recording');
            
            // Set recorder callbacks
            recorder.onStop = (audioBlob) => {
                // Create original audio player
                const originalAudio = document.getElementById('original-translation-audio');
                const originalAudioURL = URL.createObjectURL(audioBlob);
                originalAudio.src = originalAudioURL;
                
                // Process audio with translation
                processTranslation(audioBlob);
            };
            
            recorder.onError = (error) => {
                alert('Error recording audio: ' + error.message);
                button.classList.remove('recording');
            };
            
            // Start recording
            recorder.start();
        }
    });
}

function initializeVisualizers() {
    // Find all visualizers
    const visualizers = document.querySelectorAll('.audio-visualizer');
    
    // Make all visualizers active when a recording button is clicked
    const recordButtons = document.querySelectorAll('.record-button');
    
    recordButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Find the adjacent visualizers
            const parentDiv = this.parentElement;
            const adjacentVisualizers = parentDiv.querySelectorAll('.audio-visualizer');
            
            if (this.classList.contains('recording')) {
                // Activate visualizers
                adjacentVisualizers.forEach(vis => vis.classList.add('active-visualizer'));
            } else {
                // Deactivate visualizers
                adjacentVisualizers.forEach(vis => vis.classList.remove('active-visualizer'));
            }
        });
    });
}

// API Functions
function processNoiseReduction(audioBlob) {
    // Show loading state
    showLoadingState('noise-test-results');
    
    // Create FormData
    const formData = new FormData();
    formData.append('audio', audioBlob);
    
    // Send to server
    fetch('/api/noise/process', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Server error');
        }
        return response.blob();
    })
    .then(processedAudioBlob => {
        // Create processed audio player
        const processedAudio = document.getElementById('processed-audio');
        const processedAudioURL = URL.createObjectURL(processedAudioBlob);
        processedAudio.src = processedAudioURL;
        
        // Show results
        document.getElementById('noise-test-results').classList.remove('d-none');
    })
    .catch(error => {
        console.error('Error processing audio:', error);
        alert('Error processing audio: ' + error.message);
    })
    .finally(() => {
        hideLoadingState('noise-test-results');
    });
}

function processAccentConversion(audioBlob) {
    // Show loading state
    showLoadingState('accent-test-results');
    
    // Get target accent
    const targetAccent = document.getElementById('target-accent').value;
    
    // Create FormData
    const formData = new FormData();
    formData.append('audio', audioBlob);
    formData.append('target_accent', targetAccent);
    
    // Send to server
    fetch('/api/accent/convert', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Server error');
        }
        return response.blob();
    })
    .then(processedAudioBlob => {
        // Create processed audio player
        const processedAudio = document.getElementById('converted-accent-audio');
        const processedAudioURL = URL.createObjectURL(processedAudioBlob);
        processedAudio.src = processedAudioURL;
        
        // Show results
        document.getElementById('accent-test-results').classList.remove('d-none');
    })
    .catch(error => {
        console.error('Error processing audio:', error);
        alert('Error processing audio: ' + error.message);
    })
    .finally(() => {
        hideLoadingState('accent-test-results');
    });
}

function processTranslation(audioBlob) {
    // Show loading state
    showLoadingState('translation-test-results');
    
    // Get source and target languages
    const sourceLanguage = document.getElementById('source-language').value;
    const targetLanguage = document.getElementById('target-language').value;
    
    // Create FormData
    const formData = new FormData();
    formData.append('audio', audioBlob);
    formData.append('source_language', sourceLanguage);
    formData.append('target_language', targetLanguage);
    
    // Send to server
    fetch('/api/translate', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Server error');
        }
        
        // Get detected language from header
        const detectedLanguage = response.headers.get('X-Source-Language') || 'unknown';
        
        // Update detected language display
        const detectedElement = document.querySelector('#detected-language span');
        if (detectedElement) {
            detectedElement.textContent = detectedLanguage;
        }
        
        return response.blob();
    })
    .then(processedAudioBlob => {
        // Create processed audio player
        const processedAudio = document.getElementById('translated-audio');
        const processedAudioURL = URL.createObjectURL(processedAudioBlob);
        processedAudio.src = processedAudioURL;
        
        // Show results
        document.getElementById('translation-test-results').classList.remove('d-none');
    })
    .catch(error => {
        console.error('Error processing audio:', error);
        alert('Error processing audio: ' + error.message);
    })
    .finally(() => {
        hideLoadingState('translation-test-results');
    });
}

// Utility functions
function showLoadingState(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    container.classList.remove('d-none');
    
    // Add loading spinner
    const loadingSpinner = document.createElement('div');
    loadingSpinner.className = 'loading-spinner text-center my-4';
    loadingSpinner.innerHTML = '<span class="loader"></span><p class="mt-2">Processing audio...</p>';
    
    container.prepend(loadingSpinner);
}

function hideLoadingState(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    // Remove loading spinner
    const loadingSpinner = container.querySelector('.loading-spinner');
    if (loadingSpinner) {
        loadingSpinner.remove();
    }
}