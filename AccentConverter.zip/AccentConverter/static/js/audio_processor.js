/**
 * AudioProcessor class for Dexent.ai
 * Handles WebRTC audio processing tasks
 */
class AudioProcessor {
    constructor(audioContext) {
        this.audioContext = audioContext || new (window.AudioContext || window.webkitAudioContext)({
            sampleRate: 16000
        });
        this.processorNode = null;
        this.analyzerNode = null;
        this.gainNode = null;
        this.stream = null;
        this.isInitialized = false;
    }

    /**
     * Initialize the audio processing pipeline
     * @param {MediaStream} stream - MediaStream from getUserMedia
     * @returns {Promise<boolean>} - Success status
     */
    async initialize(stream) {
        try {
            this.stream = stream;
            
            // Create audio nodes
            const source = this.audioContext.createMediaStreamSource(stream);
            this.analyzerNode = this.audioContext.createAnalyser();
            this.analyzerNode.fftSize = 2048;
            
            this.gainNode = this.audioContext.createGain();
            this.gainNode.gain.value = 1.0;
            
            // Connect nodes
            source.connect(this.analyzerNode);
            this.analyzerNode.connect(this.gainNode);
            
            // Do not connect to destination to avoid feedback
            // this.gainNode.connect(this.audioContext.destination);
            
            this.isInitialized = true;
            return true;
        } catch (error) {
            console.error('Error initializing audio processor:', error);
            return false;
        }
    }
    
    /**
     * Get frequency data for visualization
     * @returns {Uint8Array} - Frequency data
     */
    getFrequencyData() {
        if (!this.isInitialized || !this.analyzerNode) {
            return new Uint8Array(0);
        }
        
        const bufferLength = this.analyzerNode.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        this.analyzerNode.getByteFrequencyData(dataArray);
        
        return dataArray;
    }
    
    /**
     * Convert audio buffer to proper format for server processing
     * @param {AudioBuffer} buffer - Audio buffer to convert
     * @returns {ArrayBuffer} - Formatted audio data
     */
    formatAudioData(buffer) {
        // Ensure we have mono 16kHz audio
        const sampleRate = 16000;
        const numChannels = 1;
        const lengthInSamples = buffer.length;
        
        // Create buffer at correct sample rate if needed
        let audioBuffer = buffer;
        if (buffer.sampleRate !== sampleRate) {
            audioBuffer = this.resampleAudio(buffer, sampleRate);
        }
        
        // Convert to 16-bit PCM WAV
        const wavBuffer = this.audioBufferToWav(audioBuffer, {
            sampleRate: sampleRate,
            numChannels: numChannels
        });
        
        return wavBuffer;
    }
    
    /**
     * Resample audio to target sample rate
     * @param {AudioBuffer} audioBuffer - Source audio buffer
     * @param {number} targetSampleRate - Target sample rate
     * @returns {AudioBuffer} - Resampled audio buffer
     */
    resampleAudio(audioBuffer, targetSampleRate) {
        const sourceSampleRate = audioBuffer.sampleRate;
        const sourceLength = audioBuffer.length;
        
        // Calculate new length
        const targetLength = Math.round(sourceLength * targetSampleRate / sourceSampleRate);
        
        // Create new buffer
        const offlineContext = new OfflineAudioContext(
            audioBuffer.numberOfChannels,
            targetLength,
            targetSampleRate
        );
        
        // Create buffer source
        const source = offlineContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(offlineContext.destination);
        source.start(0);
        
        // Render buffer
        return offlineContext.startRendering();
    }
    
    /**
     * Convert AudioBuffer to WAV format
     * @param {AudioBuffer} audioBuffer - Audio buffer to convert
     * @param {Object} options - Conversion options
     * @returns {ArrayBuffer} - WAV file as ArrayBuffer
     */
    audioBufferToWav(audioBuffer, options = {}) {
        const numChannels = options.numChannels || audioBuffer.numberOfChannels;
        const sampleRate = options.sampleRate || audioBuffer.sampleRate;
        const format = options.format || 1; // PCM
        const bitDepth = options.bitDepth || 16; // 16-bit
        
        const bytesPerSample = bitDepth / 8;
        const blockAlign = numChannels * bytesPerSample;
        
        // Get channel data
        const channelData = [];
        for (let channel = 0; channel < numChannels; channel++) {
            channelData.push(audioBuffer.getChannelData(channel));
        }
        
        // Interleave channels
        const interleaved = this.interleaveChannels(channelData, audioBuffer.length);
        
        // Convert to 16-bit PCM
        const samples = new Int16Array(interleaved.length);
        for (let i = 0; i < interleaved.length; i++) {
            // Scale float32 to int16 range
            const s = Math.max(-1, Math.min(1, interleaved[i]));
            samples[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
        }
        
        // Create WAV header
        const dataSize = samples.length * bytesPerSample;
        const buffer = new ArrayBuffer(44 + dataSize);
        const view = new DataView(buffer);
        
        // RIFF chunk descriptor
        writeString(view, 0, 'RIFF');
        view.setUint32(4, 36 + dataSize, true);
        writeString(view, 8, 'WAVE');
        
        // FMT sub-chunk
        writeString(view, 12, 'fmt ');
        view.setUint32(16, 16, true); // Subchunk size
        view.setUint16(20, format, true); // Format (PCM)
        view.setUint16(22, numChannels, true); // Channels
        view.setUint32(24, sampleRate, true); // Sample rate
        view.setUint32(28, sampleRate * blockAlign, true); // Byte rate
        view.setUint16(32, blockAlign, true); // Block align
        view.setUint16(34, bitDepth, true); // Bits per sample
        
        // Data sub-chunk
        writeString(view, 36, 'data');
        view.setUint32(40, dataSize, true);
        
        // Write PCM samples
        const samplesData = new Int16Array(buffer, 44, samples.length);
        samplesData.set(samples);
        
        return buffer;
        
        // Helper function to write strings to DataView
        function writeString(view, offset, string) {
            for (let i = 0; i < string.length; i++) {
                view.setUint8(offset + i, string.charCodeAt(i));
            }
        }
    }
    
    /**
     * Interleave multiple audio channels
     * @param {Array<Float32Array>} channelData - Array of channel data
     * @param {number} frameCount - Number of samples per channel
     * @returns {Float32Array} - Interleaved audio data
     */
    interleaveChannels(channelData, frameCount) {
        const numChannels = channelData.length;
        const result = new Float32Array(frameCount * numChannels);
        
        for (let i = 0; i < frameCount; i++) {
            for (let channel = 0; channel < numChannels; channel++) {
                result[i * numChannels + channel] = channelData[channel][i];
            }
        }
        
        return result;
    }
    
    /**
     * Clean up resources
     */
    dispose() {
        if (this.gainNode) {
            this.gainNode.disconnect();
        }
        
        if (this.analyzerNode) {
            this.analyzerNode.disconnect();
        }
        
        this.isInitialized = false;
    }
}
