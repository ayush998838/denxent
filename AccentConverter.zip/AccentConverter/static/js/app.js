// Main application JavaScript for Dexent.ai

// Global variables
let isRecording = false;
let audioContext = null;
let mediaRecorder = null;
let audioProcessor = null;
let recordedChunks = [];
let processingInterval = null;
let targetAccent = 'british'; // Default accent
let audioQueue = [];
let isProcessingAudio = false;
let recordingStartTime = 0;
let currentStream = null;

// DOM elements
const startButton = document.getElementById('startButton');
const statusIndicator = document.getElementById('statusIndicator');
const systemStatus = document.getElementById('systemStatus');
const accentSelector = document.getElementById('accentSelector');
const visualizer = document.getElementById('visualizer');
const visualizerContext = visualizer.getContext('2d');
const latencyDisplay = document.getElementById('latencyDisplay');

// Initialize the application
document.addEventListener('DOMContentLoaded', async () => {
    console.log('Initializing Dexent.ai...');
    
    // Check browser compatibility
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        showError('Your browser does not support audio recording. Please use Chrome, Firefox, or Edge.');
        return;
    }
    
    // Check system status
    checkSystemStatus();
    
    // Load available accents
    await loadAccents();
    
    // Initialize audio context
    try {
        audioContext = new (window.AudioContext || window.webkitAudioContext)({
            sampleRate: 16000
        });
    } catch (e) {
        showError('Could not initialize audio system: ' + e.message);
        return;
    }
    
    // Setup event listeners
    setupEventListeners();
    
    // Initialize visualizer
    initializeVisualizer();
    
    // Set up audio processor
    audioProcessor = new AudioProcessor(audioContext);
});

// Check if the backend system is ready
async function checkSystemStatus() {
    try {
        const response = await fetch('/check_system');
        const data = await response.json();
        
        if (data.status === 'ready') {
            systemStatus.innerHTML = '<span class="badge bg-success">System Ready</span>';
        } else {
            systemStatus.innerHTML = '<span class="badge bg-warning">Initializing Models...</span>';
            // Check again in 5 seconds
            setTimeout(checkSystemStatus, 5000);
        }
        
        // Update individual model status
        updateModelStatus('VAD', data.models.vad);
        updateModelStatus('Speaker Embedding', data.models.speaker_embedding);
        updateModelStatus('Accent Converter', data.models.accent_converter);
        
    } catch (e) {
        systemStatus.innerHTML = '<span class="badge bg-danger">System Error</span>';
        console.error('Error checking system status:', e);
    }
}

// Update status of individual models
function updateModelStatus(modelName, isReady) {
    const statusElement = document.getElementById(`${modelName.toLowerCase().replace(' ', '_')}_status`);
    if (statusElement) {
        statusElement.innerHTML = isReady ? 
            '<span class="badge bg-success">Ready</span>' : 
            '<span class="badge bg-warning">Loading...</span>';
    }
}

// Load available accents from the server
async function loadAccents() {
    try {
        const response = await fetch('/available_accents');
        const accents = await response.json();
        
        // Clear existing options
        accentSelector.innerHTML = '';
        
        // Add accent options
        Object.entries(accents).forEach(([value, label]) => {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = label;
            accentSelector.appendChild(option);
        });
        
        // Set default accent
        accentSelector.value = targetAccent;
        
    } catch (e) {
        console.error('Error loading accents:', e);
        showError('Could not load available accents');
    }
}

// Set up event listeners
function setupEventListeners() {
    // Start/Stop button
    startButton.addEventListener('click', toggleRecording);
    
    // Accent selector
    accentSelector.addEventListener('change', (e) => {
        targetAccent = e.target.value;
        console.log('Target accent changed to:', targetAccent);
    });
    
    // Window unload - clean up resources
    window.addEventListener('beforeunload', () => {
        if (isRecording) {
            stopRecording();
        }
        if (currentStream) {
            currentStream.getTracks().forEach(track => track.stop());
        }
    });
}

// Toggle recording state
async function toggleRecording() {
    if (isRecording) {
        stopRecording();
    } else {
        await startRecording();
    }
}

// Start recording audio
async function startRecording() {
    try {
        // Request microphone access
        currentStream = await navigator.mediaDevices.getUserMedia({
            audio: {
                sampleRate: 16000,
                channelCount: 1,
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true
            }
        });
        
        // Create media recorder
        mediaRecorder = new MediaRecorder(currentStream);
        
        // Set up audio processing
        const source = audioContext.createMediaStreamSource(currentStream);
        const analyzer = audioContext.createAnalyser();
        analyzer.fftSize = 2048;
        source.connect(analyzer);
        
        // Update visualizer
        updateVisualizer(analyzer);
        
        // Handle data available event
        mediaRecorder.ondataavailable = (e) => {
            if (e.data.size > 0) {
                recordedChunks.push(e.data);
            }
        };
        
        // Start recording
        mediaRecorder.start(250); // Collect in 250ms chunks
        recordingStartTime = Date.now();
        
        // Start processing audio chunks
        processingInterval = setInterval(processAudioChunk, 250);
        
        // Update UI
        isRecording = true;
        startButton.textContent = 'Stop';
        startButton.classList.remove('btn-primary');
        startButton.classList.add('btn-danger');
        statusIndicator.classList.remove('bg-secondary');
        statusIndicator.classList.add('bg-danger');
        
    } catch (e) {
        showError('Could not access microphone: ' + e.message);
        console.error('Microphone access error:', e);
    }
}

// Stop recording
function stopRecording() {
    if (!mediaRecorder) return;
    
    // Stop media recorder
    mediaRecorder.stop();
    
    // Stop all tracks
    if (currentStream) {
        currentStream.getTracks().forEach(track => track.stop());
    }
    
    // Clear processing interval
    if (processingInterval) {
        clearInterval(processingInterval);
    }
    
    // Update UI
    isRecording = false;
    startButton.textContent = 'Start';
    startButton.classList.remove('btn-danger');
    startButton.classList.add('btn-primary');
    statusIndicator.classList.remove('bg-danger');
    statusIndicator.classList.add('bg-secondary');
    
    // Clear visualizer
    visualizerContext.clearRect(0, 0, visualizer.width, visualizer.height);
    
    // Reset variables
    recordedChunks = [];
    mediaRecorder = null;
    currentStream = null;
}

// Process recorded audio chunks
async function processAudioChunk() {
    if (recordedChunks.length === 0) return;
    
    // Take chunks and reset the array
    const chunksToProcess = [...recordedChunks];
    recordedChunks = [];
    
    // Create blob from chunks
    const audioBlob = new Blob(chunksToProcess, { type: 'audio/wav' });
    
    // Add to processing queue
    audioQueue.push({
        blob: audioBlob,
        timestamp: Date.now()
    });
    
    // Process queue if not already processing
    if (!isProcessingAudio) {
        processAudioQueue();
    }
}

// Process audio queue
async function processAudioQueue() {
    if (audioQueue.length === 0) {
        isProcessingAudio = false;
        return;
    }
    
    isProcessingAudio = true;
    const audioItem = audioQueue.shift();
    
    try {
        // Create form data
        const formData = new FormData();
        formData.append('audio', audioItem.blob);
        formData.append('target_accent', targetAccent);
        
        // Send to server
        const response = await fetch('/process_audio', {
            method: 'POST',
            body: formData
        });
        
        if (response.ok) {
            const contentType = response.headers.get('content-type');
            
            if (contentType && contentType.includes('audio')) {
                // Get audio data and play it
                const audioData = await response.arrayBuffer();
                playProcessedAudio(audioData);
                
                // Calculate and display latency
                const processingLatency = Date.now() - audioItem.timestamp;
                updateLatencyDisplay(processingLatency);
            } else {
                // Handle JSON response (e.g., no speech detected)
                const jsonResponse = await response.json();
                console.log('Server response:', jsonResponse);
            }
        } else {
            console.error('Server error:', response.status);
        }
    } catch (e) {
        console.error('Error processing audio:', e);
    }
    
    // Process next item in queue
    processAudioQueue();
}

// Play processed audio
function playProcessedAudio(audioData) {
    audioContext.decodeAudioData(audioData, (buffer) => {
        const source = audioContext.createBufferSource();
        source.buffer = buffer;
        source.connect(audioContext.destination);
        source.start(0);
    }, (error) => {
        console.error('Error decoding audio data:', error);
    });
}

// Initialize audio visualizer
function initializeVisualizer() {
    visualizer.width = visualizer.offsetWidth;
    visualizer.height = visualizer.offsetHeight;
    
    // Set initial blank state
    visualizerContext.fillStyle = '#1a1a1a';
    visualizerContext.fillRect(0, 0, visualizer.width, visualizer.height);
}

// Update visualizer with audio data
function updateVisualizer(analyzer) {
    if (!isRecording) return;
    
    const bufferLength = analyzer.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    
    function draw() {
        if (!isRecording) return;
        
        requestAnimationFrame(draw);
        
        analyzer.getByteFrequencyData(dataArray);
        
        visualizerContext.fillStyle = '#1a1a1a';
        visualizerContext.fillRect(0, 0, visualizer.width, visualizer.height);
        
        const barWidth = (visualizer.width / bufferLength) * 2.5;
        let x = 0;
        
        for (let i = 0; i < bufferLength; i++) {
            const barHeight = dataArray[i] / 2;
            
            // Gradient based on frequency
            const hue = i / bufferLength * 360;
            visualizerContext.fillStyle = `hsl(${hue}, 100%, 50%)`;
            
            visualizerContext.fillRect(
                x, 
                visualizer.height - barHeight, 
                barWidth, 
                barHeight
            );
            
            x += barWidth + 1;
        }
    }
    
    draw();
}

// Update latency display
function updateLatencyDisplay(latency) {
    latencyDisplay.textContent = `${latency} ms`;
    
    // Change color based on latency
    if (latency < 300) {
        latencyDisplay.className = 'badge bg-success';
    } else if (latency < 500) {
        latencyDisplay.className = 'badge bg-warning';
    } else {
        latencyDisplay.className = 'badge bg-danger';
    }
}

// Show error message
function showError(message) {
    const errorAlert = document.getElementById('errorAlert');
    const errorMessage = document.getElementById('errorMessage');
    
    if (errorAlert && errorMessage) {
        errorMessage.textContent = message;
        errorAlert.classList.remove('d-none');
        
        // Hide start button if error is critical
        if (message.includes('browser') || message.includes('microphone')) {
            startButton.disabled = true;
        }
    }
}

// Hide error message
function hideError() {
    const errorAlert = document.getElementById('errorAlert');
    if (errorAlert) {
        errorAlert.classList.add('d-none');
    }
}
