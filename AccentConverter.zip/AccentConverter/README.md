# dexent.ai Clone

A comprehensive AI-powered communication platform inspired by dexent.ai. This application enhances your virtual communications with various AI-driven features to improve clarity, understanding, and productivity.

## Features

### 🔇 AI Noise Cancellation
- Eliminates background noises in real-time
- Supports echo cancellation
- Voice enhancement technology
- Works across all meeting platforms

### 🎙️ AI Meeting Assistant
- Records meeting audio automatically
- Transcribes conversations with high accuracy
- Summarizes meeting content
- Extracts action items and assigns responsibilities

### 🗣️ AI Accent Conversion
- Converts speaker accents to American English in real-time
- Preserves speaker identity and voice characteristics
- Improves comprehension during international calls
- Multiple accent options available

### 🌐 AI Live Interpreter
- Real-time speech translation in 29+ languages
- Auto-detects source language
- Maintains natural-sounding voice
- Seamless integration with other features

## Architecture

The system is built with a modern, scalable architecture:

- **Backend**: Flask-based Python application
- **Frontend**: Responsive design with Bootstrap
- **Database**: PostgreSQL for data persistence
- **Authentication**: Firebase Authentication
- **AI Models**: Custom-trained noise cancellation, accent conversion, transcription, and translation models

## Installation

### Prerequisites
- Python 3.11 or higher
- PostgreSQL database
- Firebase project (for authentication)

### Setup

1. Clone the repository:
```
git clone https://github.com/yourusername/krisp-ai-clone.git
cd krisp-ai-clone
```

2. Install dependencies:
```
pip install -r requirements.txt
```

3. Set up environment variables:
```
export DATABASE_URL=postgresql://username:password@localhost:5432/krisp_clone
export FIREBASE_API_KEY=your_firebase_api_key
export FIREBASE_PROJECT_ID=your_firebase_project_id
export FIREBASE_APP_ID=your_firebase_app_id
export SESSION_SECRET=your_secret_key
```

4. Initialize the database:
```
flask db init
flask db migrate
flask db upgrade
```

5. Run the application:
```
python main.py
```

## Usage

1. **Create an Account**: Sign up using email or Google authentication
2. **Configure Settings**: Adjust noise cancellation, meeting recording, accent conversion, and translation preferences
3. **Start a Meeting**: Use the meeting assistant to record, transcribe, and generate summaries
4. **Test Features**: Try each feature individually with the test interface

## Development

### Project Structure

```
krisp-ai-clone/
├── app.py            # Main application file
├── database.py       # Database models
├── models/           # AI model implementations
├── static/           # Static files (CSS, JS, images)
├── templates/        # HTML templates
└── utils/            # Utility functions
```

### Running Tests

```
python -m pytest tests/
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

Distributed under the MIT License. See `LICENSE` for more information.

## Acknowledgments

- Inspired by [dexent.ai](https://dexent.ai/)
- Built with Flask, PostgreSQL, and Firebase
- AI models based on open research