import os
import logging
import time
import threading
import signal
from datetime import datetime, timedelta
from flask import Flask, render_template, request, jsonify, Response, redirect, url_for, session, make_response
import json
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import generate_password_hash, check_password_hash
import firebase_admin
from firebase_admin import credentials, auth as firebase_auth
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate  # Add this import

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql://postgres:1234@localhost:5432/postgres"
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "postgresql://postgres:1234@localhost:5432/postgres")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False  # Add this to suppress warnings

# Set a secret key for session management
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-key")  # Add this for session management

# Initialize database
db = SQLAlchemy(app)  # Move this here before importing models

# Import database models after initializing db
from database import User, UserPreference, NoiseHistory, MeetingSession, ActionItem, AccentConversionHistory, TranslationHistory, SystemMetric

# Initialize Flask-Migrate
migrate = Migrate(app, db)  # Add this line to enable 'flask db' commands

# Create database tables when needed
with app.app_context():
    db.create_all()
    logger.info("Database tables created (if they didn't exist already)")

from firebase_admin import credentials

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

# Firebase project ID (either from env or hardcoded)
FIREBASE_PROJECT_ID = os.environ.get("FIREBASE_PROJECT_ID", "dexent-29865")

# Path to service account key
cred_path = os.path.join(os.getcwd(), "firebase-adminsdk.json")

try:
    if not firebase_admin._apps:
        cred = credentials.Certificate(cred_path)
        firebase_admin.initialize_app(cred, {
            "projectId": FIREBASE_PROJECT_ID
        })
        print(f"✅ Firebase Admin initialized with project ID: {FIREBASE_PROJECT_ID}")
    else:
        print("✅ Firebase Admin already initialized")
except Exception as e:
    print(f"❌ Firebase Admin initialization error: {e}")
# Configure Firebase
firebase_config = {
    "apiKey": os.environ.get("FIREBASE_API_KEY"),
    "projectId": os.environ.get("FIREBASE_PROJECT_ID"),
    "appId": os.environ.get("FIREBASE_APP_ID"),
    "authDomain": f"{os.environ.get('FIREBASE_PROJECT_ID')}.firebaseapp.com",
    "storageBucket": f"{os.environ.get('FIREBASE_PROJECT_ID')}.firebasestorage.app",
    "messagingSenderId": os.environ.get("FIREBASE_MESSAGING_SENDER_ID", "207232960829"),
}

# Initialize Firebase Admin SDK if credentials are available
try:
    firebase_app = None
    if os.environ.get("FIREBASE_PROJECT_ID"):
        # For simplicity, creating a temporary credential file
        cred_dict = {
            "type": "service_account",
            "project_id": os.environ.get("FIREBASE_PROJECT_ID"),
            "private_key_id": "dummy-key-id",
            "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC7VJTUt9Us8cKj\nMzEfYyjiWA4R4/M2bS1GB4t7NXp98C3SC6dVMvDuictGeurT8jNbvJZHtCSuYEvu\nNMoSfm76oqFvAp8Gy0iz5sxjZmSnXyCdPEovGhLa0VzMaQ8s+CLOyS56YyCFGeJZ\n-----END PRIVATE KEY-----\n",
            "client_email": f"firebase-adminsdk@{os.environ.get('FIREBASE_PROJECT_ID')}.iam.gserviceaccount.com",
            "client_id": "dummy-client-id",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_x509_cert_url": f"https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk%40{os.environ.get('FIREBASE_PROJECT_ID')}.iam.gserviceaccount.com"
        }
        
        # Note: In a real app, you would use a proper credential file
        # This is just for demonstration
        try:
            cred = credentials.Certificate(cred_dict)
            firebase_app = firebase_admin.initialize_app(cred)
            logger.info("Firebase Admin SDK initialized with project ID")
        except Exception as e:
            logger.warning(f"Could not initialize Firebase Admin SDK with credentials: {e}")
    
    if firebase_app is None:
        firebase_app = firebase_admin.initialize_app()
        logger.info("Firebase Admin SDK initialized with default credentials")
        
except Exception as e:
    logger.warning(f"Could not initialize Firebase Admin SDK: {e}")
    logger.info("Using Firebase Web SDK only")

# Import model modules - just stubs for now
from models.noise_cancellation import NoiseReducer
from models.accent_converter import AccentConverter
from models.transcript_generator import TranscriptGenerator
from models.translation import Translator

# Initialize models
noise_model = None
accent_model = None
transcript_model = None
translator_model = None

def initialize_models():
    """Initialize all AI models."""
    global noise_model, accent_model, transcript_model, translator_model
    
    try:
        logger.info("Initializing Noise Reduction model...")
        noise_model = NoiseReducer()
        
        logger.info("Initializing Accent Converter model...")
        accent_model = AccentConverter()
        
        logger.info("Initializing Transcript Generator model...")
        transcript_model = TranscriptGenerator()
        
        logger.info("Initializing Translator model...")
        translator_model = Translator()
        
        logger.info("All models initialized successfully")
    except Exception as e:
        logger.error(f"Error initializing models: {e}")
        # Continue without models, frontend will show error

@app.before_request
def ensure_models_initialized():
    """Initialize models before first request."""
    global noise_model, accent_model, transcript_model, translator_model
    
    if noise_model is None or accent_model is None or transcript_model is None or translator_model is None:
        initialize_models()

# Authentication middleware
def login_required(f):
    """Decorator to require login for certain routes."""
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

# Routes
@app.route('/')
def index():
    """Home page route."""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html', firebase_config=firebase_config)

@app.route('/login')
def login():
    """Login page."""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html', firebase_config=firebase_config)

@app.route('/signup')
def signup():
    """Signup page."""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('signup.html', firebase_config=firebase_config)

@app.route('/dashboard')
@login_required
def dashboard():
    """Main application dashboard."""
    return render_template('dashboard.html')

@app.route('/settings')
@login_required
def settings():
    """User settings page."""
    return render_template('settings.html')

@app.route('/meetings')
@login_required
def meetings():
    """Meeting history and management page."""
    return render_template('meetings.html')

@app.route('/logout')
def logout():
    """Logout and clear session."""
    session.clear()
    return redirect(url_for('index'))

# Authentication API
@app.route('/api/auth/verify-token', methods=['POST'])
def verify_token():
    """Verify Firebase ID token and create a session."""
    try:
        # Get the ID token from the request
        data = request.json
        id_token = data.get('idToken')
        if not id_token:
            return jsonify({"error": "No ID token provided"}), 400
        
        # Try to verify the token with Firebase Admin SDK
        try:
            decoded_token = firebase_auth.verify_id_token(id_token)
            uid = decoded_token['uid']
            email = decoded_token.get('email', '')
            display_name = decoded_token.get('name', '')
            
            # Check if user exists in our database
            user = User.query.filter_by(firebase_uid=uid).first()
            
            if not user:
                # Create a new user
                user = User(
                    firebase_uid=uid,
                    email=email,
                    display_name=display_name,
                    last_login=datetime.utcnow()
                )
                db.session.add(user)
                
                # Create default preferences
                preferences = UserPreference(
                    user=user,
                    noise_reduction_level='medium',
                    echo_cancellation=True,
                    voice_enhancement=True
                )
                db.session.add(preferences)
                
                db.session.commit()
                logger.info(f"Created new user: {email}")
            else:
                # Update last login time
                user.last_login = datetime.utcnow()
                db.session.commit()
                logger.info(f"User logged in: {email}")
            
            # Set session
            session['user_id'] = user.id
            session['email'] = email
            session['display_name'] = user.display_name
            
            return jsonify({
                "success": True,
                "user": {
                    "id": user.id,
                    "email": user.email,
                    "displayName": user.display_name,
                    "subscription": user.subscription_type
                }
            })
            
        except Exception as e:
            logger.error(f"Error verifying token: {e}")
            return jsonify({"error": "Invalid token"}), 401
    
    except Exception as e:
        logger.error(f"Error in verify_token: {e}")
        return jsonify({"error": str(e)}), 500

# User API
@app.route('/api/user/preferences', methods=['GET'])
@login_required
def get_user_preferences():
    """Get user preferences."""
    try:
        user_id = session['user_id']
        preferences = UserPreference.query.filter_by(user_id=user_id).first()
        
        if not preferences:
            return jsonify({"error": "Preferences not found"}), 404
        
        return jsonify({
            # Noise Cancellation
            "noise_reduction_level": preferences.noise_reduction_level,
            "echo_cancellation": preferences.echo_cancellation,
            "voice_enhancement": preferences.voice_enhancement,
            
            # Meeting Assistant
            "auto_recording": preferences.auto_recording,
            "auto_transcription": preferences.auto_transcription,
            "auto_summarization": preferences.auto_summarization,
            
            # Accent Conversion
            "default_target_accent": preferences.default_target_accent,
            "accent_conversion_enabled": preferences.accent_conversion_enabled,
            
            # Translation
            "default_language": preferences.default_language,
            "auto_translation": preferences.auto_translation,
            
            # Interface
            "dark_mode": preferences.dark_mode,
            "notification_enabled": preferences.notification_enabled
        })
    
    except Exception as e:
        logger.error(f"Error getting preferences: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/user/preferences', methods=['POST'])
@login_required
def update_user_preferences():
    """Update user preferences."""
    try:
        user_id = session['user_id']
        preferences = UserPreference.query.filter_by(user_id=user_id).first()
        
        if not preferences:
            return jsonify({"error": "Preferences not found"}), 404
        
        data = request.json
        
        # Update preferences with any provided values
        if 'noise_reduction_level' in data:
            preferences.noise_reduction_level = data['noise_reduction_level']
        
        if 'echo_cancellation' in data:
            preferences.echo_cancellation = data['echo_cancellation']
        
        if 'voice_enhancement' in data:
            preferences.voice_enhancement = data['voice_enhancement']
            
        if 'auto_recording' in data:
            preferences.auto_recording = data['auto_recording']
            
        if 'auto_transcription' in data:
            preferences.auto_transcription = data['auto_transcription']
            
        if 'auto_summarization' in data:
            preferences.auto_summarization = data['auto_summarization']
            
        if 'default_target_accent' in data:
            preferences.default_target_accent = data['default_target_accent']
            
        if 'accent_conversion_enabled' in data:
            preferences.accent_conversion_enabled = data['accent_conversion_enabled']
            
        if 'default_language' in data:
            preferences.default_language = data['default_language']
            
        if 'auto_translation' in data:
            preferences.auto_translation = data['auto_translation']
            
        if 'dark_mode' in data:
            preferences.dark_mode = data['dark_mode']
            
        if 'notification_enabled' in data:
            preferences.notification_enabled = data['notification_enabled']
        
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Preferences updated successfully"
        })
    
    except Exception as e:
        logger.error(f"Error updating preferences: {e}")
        return jsonify({"error": str(e)}), 500

# Feature APIs

# 1. Noise Cancellation API
@app.route('/api/noise/process', methods=['POST'])
@login_required
def process_noise():
    """Process audio to remove noise."""
    try:
        start_time = time.time()
        
        # Get audio data and parameters
        audio_data = request.files.get('audio')
        
        if not audio_data:
            return jsonify({"error": "No audio data provided"}), 400
        
        # Get user preferences
        user_id = session['user_id']
        preferences = UserPreference.query.filter_by(user_id=user_id).first()
        
        if not preferences:
            noise_reduction_level = 'medium'
            echo_cancellation = True
            voice_enhancement = True
        else:
            noise_reduction_level = preferences.noise_reduction_level
            echo_cancellation = preferences.echo_cancellation
            voice_enhancement = preferences.voice_enhancement
        
        # Process the audio
        audio_bytes = audio_data.read()
        
        if noise_model:
            # Apply noise reduction
            processed_audio = noise_model.process_audio(
                audio_bytes,
                noise_reduction_level=noise_reduction_level,
                echo_cancellation=echo_cancellation,
                voice_enhancement=voice_enhancement
            )
        else:
            # Fallback: return original audio if model is not loaded
            processed_audio = audio_bytes
        
        # Log the processing
        processing_duration = time.time() - start_time
        try:
            history = NoiseHistory(
                user_id=user_id,
                start_time=datetime.utcnow() - timedelta(seconds=processing_duration),
                end_time=datetime.utcnow(),
                duration_seconds=float(processing_duration),
                noise_reduction_level=noise_reduction_level,
                application=request.headers.get('User-Agent', '')[:64],
                echo_cancellation=echo_cancellation,
                voice_enhancement=voice_enhancement
            )
            db.session.add(history)
            db.session.commit()
        except Exception as e:
            logger.error(f"Error logging noise history: {e}")
        
        # Return the processed audio
        return Response(processed_audio, mimetype="audio/wav")
    
    except Exception as e:
        logger.error(f"Error processing audio for noise reduction: {e}")
        return jsonify({"error": str(e)}), 500

# 2. Accent Conversion API
@app.route('/api/accent/convert', methods=['POST'])
@login_required
def convert_accent():
    """Convert audio from one accent to another."""
    try:
        start_time = time.time()
        
        # Get audio data and parameters
        audio_data = request.files.get('audio')
        target_accent = request.form.get('target_accent')
        
        if not audio_data:
            return jsonify({"error": "No audio data provided"}), 400
            
        if not target_accent:
            # Get user's default accent preference
            user_id = session['user_id']
            preferences = UserPreference.query.filter_by(user_id=user_id).first()
            
            if preferences:
                target_accent = preferences.default_target_accent
            else:
                target_accent = 'american'  # Default to American accent
        
        # Process the audio
        audio_bytes = audio_data.read()
        
        if accent_model:
            # Apply accent conversion
            converted_audio = accent_model.convert_accent(
                audio_bytes,
                target_accent=target_accent
            )
        else:
            # Fallback: return original audio if model is not loaded
            converted_audio = audio_bytes
        
        # Log the processing
        processing_duration = time.time() - start_time
        try:
            user_id = session['user_id']
            history = AccentConversionHistory(
                user_id=user_id,
                target_accent=target_accent,
                duration_seconds=float(processing_duration),
                created_at=datetime.utcnow(),
                application=request.headers.get('User-Agent', '')[:64]
            )
            db.session.add(history)
            db.session.commit()
        except Exception as e:
            logger.error(f"Error logging accent conversion history: {e}")
        
        # Return the processed audio
        return Response(converted_audio, mimetype="audio/wav")
    
    except Exception as e:
        logger.error(f"Error processing audio for accent conversion: {e}")
        return jsonify({"error": str(e)}), 500

# 3. Meeting Assistant API
@app.route('/api/meeting/start', methods=['POST'])
@login_required
def start_meeting():
    """Start a new meeting recording session."""
    try:
        user_id = session['user_id']
        data = request.json or {}
        
        # Create a new meeting session
        meeting = MeetingSession(
            user_id=user_id,
            title=data.get('title', f"Meeting {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}"),
            start_time=datetime.utcnow(),
            platform=data.get('platform', 'Unknown')
        )
        db.session.add(meeting)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "meeting_id": meeting.id,
            "title": meeting.title,
            "start_time": meeting.start_time.isoformat()
        })
    
    except Exception as e:
        logger.error(f"Error starting meeting: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/meeting/<int:meeting_id>/stop', methods=['POST'])
@login_required
def stop_meeting(meeting_id):
    """Stop a meeting recording session."""
    try:
        user_id = session['user_id']
        meeting = MeetingSession.query.filter_by(id=meeting_id, user_id=user_id).first()
        
        if not meeting:
            return jsonify({"error": "Meeting not found"}), 404
            
        if meeting.end_time:
            return jsonify({"error": "Meeting already ended"}), 400
        
        # End the meeting
        meeting.end_time = datetime.utcnow()
        
        if meeting.start_time:
            duration = (meeting.end_time - meeting.start_time).total_seconds()
            meeting.duration_seconds = duration
        
        db.session.commit()
        
        return jsonify({
            "success": True,
            "meeting_id": meeting.id,
            "title": meeting.title,
            "duration_seconds": meeting.duration_seconds
        })
    
    except Exception as e:
        logger.error(f"Error stopping meeting: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/meeting/<int:meeting_id>/record', methods=['POST'])
@login_required
def add_meeting_audio(meeting_id):
    """Add audio recording chunk to a meeting session."""
    try:
        user_id = session['user_id']
        meeting = MeetingSession.query.filter_by(id=meeting_id, user_id=user_id).first()
        
        if not meeting:
            return jsonify({"error": "Meeting not found"}), 404
            
        if meeting.end_time:
            return jsonify({"error": "Meeting already ended"}), 400
        
        # Get audio data
        audio_data = request.files.get('audio')
        
        if not audio_data:
            return jsonify({"error": "No audio data provided"}), 400
        
        # Save audio to file (simplified)
        audio_bytes = audio_data.read()
        
        # In a real system, we would manage storage more carefully
        os.makedirs('meeting_recordings', exist_ok=True)
        
        recording_path = f"meeting_recordings/meeting_{meeting_id}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.wav"
        
        with open(recording_path, 'wb') as f:
            f.write(audio_bytes)
        
        # Update the meeting record
        if not meeting.recording_path:
            meeting.recording_path = recording_path
        
        db.session.commit()
        
        return jsonify({
            "success": True,
            "meeting_id": meeting.id,
            "chunk_saved": True
        })
    
    except Exception as e:
        logger.error(f"Error adding meeting audio: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/meeting/<int:meeting_id>/transcribe', methods=['POST'])
@login_required
def transcribe_meeting(meeting_id):
    """Generate transcript for a meeting recording."""
    try:
        user_id = session['user_id']
        meeting = MeetingSession.query.filter_by(id=meeting_id, user_id=user_id).first()
        
        if not meeting:
            return jsonify({"error": "Meeting not found"}), 404
            
        if not meeting.recording_path:
            return jsonify({"error": "No recording available for this meeting"}), 400
        
        # Generate transcript (simplified)
        if transcript_model:
            # In a real system, we'd handle large files more carefully
            with open(meeting.recording_path, 'rb') as f:
                audio_bytes = f.read()
                
            transcript = transcript_model.transcribe(audio_bytes)
            
            # Save transcript to file
            os.makedirs('meeting_transcripts', exist_ok=True)
            transcript_path = f"meeting_transcripts/transcript_{meeting_id}.txt"
            
            with open(transcript_path, 'w') as f:
                f.write(transcript)
                
            # Update meeting record
            meeting.transcription_path = transcript_path
            db.session.commit()
            
            # Generate action items from transcript
            action_items = transcript_model.extract_action_items(transcript)
            
            # Save action items
            for item in action_items:
                action = ActionItem(
                    meeting_id=meeting.id,
                    description=item.get('description', ''),
                    assigned_to=item.get('assigned_to', ''),
                    due_date=item.get('due_date')
                )
                db.session.add(action)
            
            db.session.commit()
            
            return jsonify({
                "success": True,
                "meeting_id": meeting.id,
                "transcript_available": True,
                "action_items": len(action_items)
            })
        else:
            return jsonify({
                "success": False,
                "error": "Transcript model not available"
            }), 500
    
    except Exception as e:
        logger.error(f"Error transcribing meeting: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/meeting/<int:meeting_id>/summarize', methods=['POST'])
@login_required
def summarize_meeting(meeting_id):
    """Generate a summary for a meeting transcript."""
    try:
        user_id = session['user_id']
        meeting = MeetingSession.query.filter_by(id=meeting_id, user_id=user_id).first()
        
        if not meeting:
            return jsonify({"error": "Meeting not found"}), 404
            
        if not meeting.transcription_path:
            return jsonify({"error": "No transcript available for this meeting"}), 400
        
        # Generate summary (simplified)
        if transcript_model:
            # Read transcript
            with open(meeting.transcription_path, 'r') as f:
                transcript = f.read()
                
            summary = transcript_model.summarize(transcript)
            
            # Save summary to file
            os.makedirs('meeting_summaries', exist_ok=True)
            summary_path = f"meeting_summaries/summary_{meeting_id}.txt"
            
            with open(summary_path, 'w') as f:
                f.write(summary)
                
            # Update meeting record
            meeting.summary_path = summary_path
            db.session.commit()
            
            return jsonify({
                "success": True,
                "meeting_id": meeting.id,
                "summary_available": True,
                "summary": summary[:200] + "..." if len(summary) > 200 else summary
            })
        else:
            return jsonify({
                "success": False,
                "error": "Transcript model not available"
            }), 500
    
    except Exception as e:
        logger.error(f"Error summarizing meeting: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/meeting/<int:meeting_id>', methods=['GET'])
@login_required
def get_meeting(meeting_id):
    """Get details for a specific meeting."""
    try:
        user_id = session['user_id']
        meeting = MeetingSession.query.filter_by(id=meeting_id, user_id=user_id).first()
        
        if not meeting:
            return jsonify({"error": "Meeting not found"}), 404
            
        # Get action items
        action_items = []
        for item in meeting.action_items:
            action_items.append({
                "id": item.id,
                "description": item.description,
                "assigned_to": item.assigned_to,
                "due_date": item.due_date.isoformat() if item.due_date else None,
                "completed": item.completed
            })
            
        # Check if files exist
        has_recording = meeting.recording_path and os.path.exists(meeting.recording_path)
        has_transcript = meeting.transcription_path and os.path.exists(meeting.transcription_path)
        has_summary = meeting.summary_path and os.path.exists(meeting.summary_path)
        
        # Get transcript and summary content if available
        transcript = ""
        if has_transcript:
            with open(meeting.transcription_path, 'r') as f:
                transcript = f.read()
                
        summary = ""
        if has_summary:
            with open(meeting.summary_path, 'r') as f:
                summary = f.read()
        
        return jsonify({
            "id": meeting.id,
            "title": meeting.title,
            "start_time": meeting.start_time.isoformat() if meeting.start_time else None,
            "end_time": meeting.end_time.isoformat() if meeting.end_time else None,
            "duration_seconds": meeting.duration_seconds,
            "platform": meeting.platform,
            "participants_count": meeting.participants_count,
            "has_recording": has_recording,
            "has_transcript": has_transcript,
            "has_summary": has_summary,
            "transcript": transcript,
            "summary": summary,
            "action_items": action_items
        })
    
    except Exception as e:
        logger.error(f"Error getting meeting details: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/meetings', methods=['GET'])
@login_required
def get_meetings():
    """Get list of user's meetings."""
    try:
        user_id = session['user_id']
        
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        limit = min(request.args.get('limit', 10, type=int), 50)  # Max 50 per page
        
        # Query meetings with pagination
        meetings_query = MeetingSession.query.filter_by(user_id=user_id)
        meetings_query = meetings_query.order_by(MeetingSession.start_time.desc())
        paginated = meetings_query.paginate(page=page, per_page=limit, error_out=False)
        
        # Format results
        meetings_list = []
        for meeting in paginated.items:
            meetings_list.append({
                "id": meeting.id,
                "title": meeting.title,
                "start_time": meeting.start_time.isoformat() if meeting.start_time else None,
                "end_time": meeting.end_time.isoformat() if meeting.end_time else None,
                "duration_seconds": meeting.duration_seconds,
                "platform": meeting.platform,
                "has_transcript": bool(meeting.transcription_path),
                "has_summary": bool(meeting.summary_path),
                "action_items_count": len(meeting.action_items)
            })
        
        return jsonify({
            "meetings": meetings_list,
            "total": paginated.total,
            "pages": paginated.pages,
            "current_page": page
        })
    
    except Exception as e:
        logger.error(f"Error getting meetings: {e}")
        return jsonify({"error": str(e)}), 500

# 4. Translation API
@app.route('/api/translate', methods=['POST'])
@login_required
def translate_audio():
    """Translate audio from one language to another."""
    try:
        start_time = time.time()
        
        # Get audio data and parameters
        audio_data = request.files.get('audio')
        target_language = request.form.get('target_language')
        source_language = request.form.get('source_language', 'auto')
        
        if not audio_data:
            return jsonify({"error": "No audio data provided"}), 400
            
        if not target_language:
            # Get user's default language preference
            user_id = session['user_id']
            preferences = UserPreference.query.filter_by(user_id=user_id).first()
            
            if preferences:
                target_language = preferences.default_language
            else:
                target_language = 'english'  # Default to English
        
        # Process the audio
        audio_bytes = audio_data.read()
        
        if translator_model:
            # Apply translation
            translated_audio, detected_source = translator_model.translate(
                audio_bytes,
                target_language=target_language,
                source_language=source_language
            )
            
            # If source was auto-detected, update the variable
            if source_language == 'auto' and detected_source:
                source_language = detected_source
        else:
            # Fallback: return original audio if model is not loaded
            translated_audio = audio_bytes
            detected_source = source_language
        
        # Log the processing
        processing_duration = time.time() - start_time
        try:
            user_id = session['user_id']
            history = TranslationHistory(
                user_id=user_id,
                source_language=source_language,
                target_language=target_language,
                duration_seconds=float(processing_duration),
                created_at=datetime.utcnow(),
                application=request.headers.get('User-Agent', '')[:64]
            )
            db.session.add(history)
            db.session.commit()
        except Exception as e:
            logger.error(f"Error logging translation history: {e}")
        
        # Return the processed audio and metadata
        response = make_response(Response(translated_audio, mimetype="audio/wav"))
        response.headers['X-Source-Language'] = source_language
        response.headers['X-Target-Language'] = target_language
        
        return response
    
    except Exception as e:
        logger.error(f"Error translating audio: {e}")
        return jsonify({"error": str(e)}), 500

# System status and info APIs
@app.route('/api/system/status', methods=['GET'])
def system_status():
    """Get system status information."""
    status = {
        "noise_reduction": noise_model is not None,
        "accent_conversion": accent_model is not None,
        "transcript_generation": transcript_model is not None,
        "translation": translator_model is not None,
        "server_time": datetime.utcnow().isoformat(),
        "status": "operational"
    }
    
    # Consider system operational if at least noise reduction is working
    if not noise_model:
        status["status"] = "degraded"
    
    return jsonify(status)

@app.route('/api/system/languages', methods=['GET'])
def available_languages():
    """Get list of available languages for translation."""
    languages = {
        "english": "English",
        "spanish": "Spanish",
        "french": "French",
        "german": "German",
        "italian": "Italian",
        "portuguese": "Portuguese",
        "russian": "Russian",
        "japanese": "Japanese",
        "chinese": "Chinese (Mandarin)",
        "korean": "Korean",
        "arabic": "Arabic",
        "hindi": "Hindi",
        "bengali": "Bengali",
        "dutch": "Dutch",
        "greek": "Greek",
        "swedish": "Swedish",
        "finnish": "Finnish",
        "danish": "Danish",
        "norwegian": "Norwegian",
        "polish": "Polish",
        "turkish": "Turkish",
        "czech": "Czech",
        "hungarian": "Hungarian",
        "romanian": "Romanian",
        "thai": "Thai",
        "vietnamese": "Vietnamese",
        "indonesian": "Indonesian",
        "malay": "Malay",
        "filipino": "Filipino"
    }
    return jsonify(languages)

@app.route('/api/system/accents', methods=['GET'])
def available_accents():
    """Get list of available accents for conversion."""
    accents = {
        "american": "American English",
        "british": "British English",
        "australian": "Australian English",
        "canadian": "Canadian English",
        "irish": "Irish English",
        "scottish": "Scottish English",
        "indian": "Indian English",
        "neutral": "Neutral English"
    }
    return jsonify(accents)

@app.route('/api/user/stats', methods=['GET'])
@login_required
def get_user_stats():
    """Get user's usage statistics."""
    try:
        user_id = session['user_id']
        
        # Get total noise reduction time
        noise_time_result = db.session.query(db.func.sum(NoiseHistory.duration_seconds)) \
            .filter_by(user_id=user_id).first()
        noise_time = noise_time_result[0] if noise_time_result[0] else 0
        
        # Get total accent conversion time
        accent_time_result = db.session.query(db.func.sum(AccentConversionHistory.duration_seconds)) \
            .filter_by(user_id=user_id).first()
        accent_time = accent_time_result[0] if accent_time_result[0] else 0
        
        # Get total translation time
        translation_time_result = db.session.query(db.func.sum(TranslationHistory.duration_seconds)) \
            .filter_by(user_id=user_id).first()
        translation_time = translation_time_result[0] if translation_time_result[0] else 0
        
        # Get total meetings time
        meeting_time_result = db.session.query(db.func.sum(MeetingSession.duration_seconds)) \
            .filter_by(user_id=user_id).first()
        meeting_time = meeting_time_result[0] if meeting_time_result[0] else 0
        
        # Get counts
        noise_count = NoiseHistory.query.filter_by(user_id=user_id).count()
        accent_count = AccentConversionHistory.query.filter_by(user_id=user_id).count()
        translation_count = TranslationHistory.query.filter_by(user_id=user_id).count()
        meeting_count = MeetingSession.query.filter_by(user_id=user_id).count()
        
        # Get usage by day (last 7 days)
        seven_days_ago = datetime.utcnow() - timedelta(days=7)
        
        # Noise usage by day
        noise_usage = db.session.query(
            db.func.date(NoiseHistory.start_time).label('date'),
            db.func.count().label('count'),
            db.func.sum(NoiseHistory.duration_seconds).label('duration')
        ).filter(
            NoiseHistory.user_id == user_id,
            NoiseHistory.start_time >= seven_days_ago
        ).group_by(
            db.func.date(NoiseHistory.start_time)
        ).order_by(
            db.func.date(NoiseHistory.start_time)
        ).all()
        
        # Format the daily usage data
        daily_usage = {}
        
        for date, count, duration in noise_usage:
            date_str = date.isoformat()
            if date_str not in daily_usage:
                daily_usage[date_str] = {
                    "date": date_str,
                    "noise": {"count": 0, "duration": 0},
                    "accent": {"count": 0, "duration": 0},
                    "translation": {"count": 0, "duration": 0},
                    "meeting": {"count": 0, "duration": 0}
                }
            
            daily_usage[date_str]["noise"]["count"] = count
            daily_usage[date_str]["noise"]["duration"] = float(duration) if duration else 0
        
        # Fill in empty days
        for i in range(7):
            date = (datetime.utcnow() - timedelta(days=i)).date().isoformat()
            if date not in daily_usage:
                daily_usage[date] = {
                    "date": date,
                    "noise": {"count": 0, "duration": 0},
                    "accent": {"count": 0, "duration": 0},
                    "translation": {"count": 0, "duration": 0},
                    "meeting": {"count": 0, "duration": 0}
                }
        
        # Convert dict to sorted list
        daily_usage_list = sorted(daily_usage.values(), key=lambda x: x["date"])
        
        return jsonify({
            "total_time_seconds": {
                "noise": float(noise_time) if noise_time else 0,
                "accent": float(accent_time) if accent_time else 0,
                "translation": float(translation_time) if translation_time else 0,
                "meeting": float(meeting_time) if meeting_time else 0,
                "total": float(noise_time) + float(accent_time) + float(translation_time) + float(meeting_time)
            },
            "usage_count": {
                "noise": noise_count,
                "accent": accent_count,
                "translation": translation_count,
                "meeting": meeting_count,
                "total": noise_count + accent_count + translation_count + meeting_count
            },
            "daily_usage": daily_usage_list
        })
    
    except Exception as e:
        logger.error(f"Error getting stats: {e}")
        return jsonify({"error": str(e)}), 500

# Server health check
@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)