"""
AI Assistant for Dexent.ai

This module provides AI-based assistance for managing the Dexent.ai application,
including error handling, log monitoring, and suggestions for improvement.
"""
import os
import re
import sys
import time
import logging
import threading
import traceback
import subprocess
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('assistant_logs.txt')
    ]
)

logger = logging.getLogger("ai_assistant")

class DexentAIAssistant:
    """AI Assistant for monitoring and managing the Dexent.ai application."""
    
    def __init__(self):
        """Initialize the AI Assistant."""
        self.app_status = {
            "running": False,
            "errors": [],
            "models_status": {
                "vad": False,
                "speaker_embedding": False,
                "accent_converter": False
            },
            "last_check": None
        }
        self.monitor_thread = None
        self.log_thread = None
        self.keep_monitoring = False
        
        # Create directory for assistant logs and diagnostics
        os.makedirs('assistant_data', exist_ok=True)
        
        logger.info("AI Assistant initialized")
    
    def start_monitoring(self):
        """Start monitoring the application in a separate thread."""
        if self.monitor_thread and self.monitor_thread.is_alive():
            logger.info("Monitoring is already running")
            return
        
        self.keep_monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_app)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        
        self.log_thread = threading.Thread(target=self._monitor_logs)
        self.log_thread.daemon = True
        self.log_thread.start()
        
        logger.info("Started monitoring threads")
    
    def stop_monitoring(self):
        """Stop the monitoring threads."""
        self.keep_monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=2.0)
        if self.log_thread:
            self.log_thread.join(timeout=2.0)
        logger.info("Stopped monitoring")
    
    def check_app_status(self) -> Dict[str, Any]:
        """Check the current status of the application and its components."""
        self._update_app_status()
        return self.app_status
    
    def get_suggestions(self) -> List[Dict[str, str]]:
        """Get suggestions for improving the application based on its current state."""
        suggestions = []
        
        # Check if the app is running
        if not self.app_status["running"]:
            suggestions.append({
                "type": "critical",
                "title": "Application not running",
                "description": "The Dexent.ai application is not running. Try restarting the server.",
                "action": "restart_server"
            })
        
        # Check for model issues
        for model, status in self.app_status["models_status"].items():
            if not status:
                suggestions.append({
                    "type": "warning",
                    "title": f"{model.replace('_', ' ').title()} model not initialized",
                    "description": f"The {model} model failed to initialize. This might affect accent conversion quality.",
                    "action": f"fix_{model}"
                })
        
        # Check for recent errors
        recent_errors = [e for e in self.app_status["errors"] if 
                         (datetime.now() - e["timestamp"]).total_seconds() < 3600]
        if recent_errors:
            error_types = set(e["type"] for e in recent_errors)
            for error_type in error_types:
                count = sum(1 for e in recent_errors if e["type"] == error_type)
                suggestions.append({
                    "type": "error",
                    "title": f"Recent {error_type} errors detected",
                    "description": f"Detected {count} {error_type} errors in the last hour.",
                    "action": f"analyze_{error_type}_errors"
                })
        
        # Add general improvement suggestions
        suggestions.extend(self._get_improvement_suggestions())
        
        return suggestions
    
    def diagnose_issue(self, issue_type: str) -> Dict[str, Any]:
        """
        Diagnose a specific issue and provide detailed information.
        
        Args:
            issue_type: Type of issue to diagnose (e.g., 'vad', 'speaker_embedding', etc.)
            
        Returns:
            Dict containing diagnosis results
        """
        diagnosis = {
            "issue_type": issue_type,
            "timestamp": datetime.now(),
            "details": {},
            "potential_fixes": []
        }
        
        if issue_type == "vad":
            diagnosis["details"] = self._diagnose_vad_model()
        elif issue_type == "speaker_embedding":
            diagnosis["details"] = self._diagnose_speaker_model()
        elif issue_type == "accent_converter":
            diagnosis["details"] = self._diagnose_accent_model()
        elif issue_type == "server":
            diagnosis["details"] = self._diagnose_server()
        elif issue_type == "audio_processing":
            diagnosis["details"] = self._diagnose_audio_processing()
        else:
            diagnosis["details"] = {"error": f"Unknown issue type: {issue_type}"}
        
        # Save diagnosis to file for reference
        self._save_diagnosis(diagnosis)
        
        return diagnosis
    
    def fix_issue(self, issue_type: str) -> Dict[str, Any]:
        """
        Attempt to fix a specific issue automatically.
        
        Args:
            issue_type: Type of issue to fix
            
        Returns:
            Dict containing results of the fix attempt
        """
        result = {
            "issue_type": issue_type,
            "timestamp": datetime.now(),
            "success": False,
            "actions_taken": [],
            "message": ""
        }
        
        # First diagnose the issue
        diagnosis = self.diagnose_issue(issue_type)
        
        # Then attempt fixes based on the diagnosis
        if issue_type == "vad":
            result = self._fix_vad_model(diagnosis)
        elif issue_type == "speaker_embedding":
            result = self._fix_speaker_model(diagnosis)
        elif issue_type == "accent_converter":
            result = self._fix_accent_model(diagnosis)
        elif issue_type == "server":
            result = self._fix_server(diagnosis)
        elif issue_type == "audio_processing":
            result = self._fix_audio_processing(diagnosis)
        else:
            result["message"] = f"No automatic fix available for {issue_type}"
        
        # Log the result
        if result["success"]:
            logger.info(f"Successfully fixed {issue_type} issue")
        else:
            logger.warning(f"Failed to fix {issue_type} issue: {result['message']}")
        
        return result
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get performance metrics for the application."""
        metrics = {
            "timestamp": datetime.now(),
            "latency": self._measure_latency(),
            "cpu_usage": self._get_cpu_usage(),
            "memory_usage": self._get_memory_usage(),
            "active_connections": self._get_active_connections(),
            "model_performance": self._get_model_performance()
        }
        return metrics
    
    def backup_system(self) -> Dict[str, Any]:
        """Create a backup of the current system state."""
        backup_path = os.path.join("assistant_data", f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        os.makedirs(backup_path, exist_ok=True)
        
        result = {
            "timestamp": datetime.now(),
            "backup_path": backup_path,
            "files_backed_up": [],
            "success": False
        }
        
        try:
            # Back up important files
            important_paths = [
                "models", "templates", "static", "utils",
                "app.py", "main.py", "ai_assistant.py"
            ]
            
            for path in important_paths:
                if os.path.exists(path):
                    if os.path.isdir(path):
                        # Copy directory contents
                        dest_dir = os.path.join(backup_path, path)
                        os.makedirs(dest_dir, exist_ok=True)
                        for filename in os.listdir(path):
                            src_file = os.path.join(path, filename)
                            if os.path.isfile(src_file):
                                with open(src_file, 'r', encoding='utf-8', errors='ignore') as f_in:
                                    content = f_in.read()
                                dest_file = os.path.join(dest_dir, filename)
                                with open(dest_file, 'w', encoding='utf-8') as f_out:
                                    f_out.write(content)
                                result["files_backed_up"].append(src_file)
                    else:
                        # Copy single file
                        with open(path, 'r', encoding='utf-8', errors='ignore') as f_in:
                            content = f_in.read()
                        dest_file = os.path.join(backup_path, os.path.basename(path))
                        with open(dest_file, 'w', encoding='utf-8') as f_out:
                            f_out.write(content)
                        result["files_backed_up"].append(path)
            
            result["success"] = True
            logger.info(f"System backup created at {backup_path}")
        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Backup failed: {e}")
        
        return result
    
    def restore_system(self, backup_path: str) -> Dict[str, Any]:
        """
        Restore the system from a backup.
        
        Args:
            backup_path: Path to the backup directory
            
        Returns:
            Dict containing results of the restore operation
        """
        result = {
            "timestamp": datetime.now(),
            "backup_path": backup_path,
            "files_restored": [],
            "success": False
        }
        
        if not os.path.exists(backup_path):
            result["error"] = f"Backup path {backup_path} does not exist"
            return result
        
        try:
            # First create a backup of the current state
            self.backup_system()
            
            # Now restore from the specified backup
            for root, dirs, files in os.walk(backup_path):
                rel_path = os.path.relpath(root, backup_path)
                if rel_path == ".":
                    rel_path = ""
                
                # Create directories
                for directory in dirs:
                    target_dir = os.path.join(rel_path, directory)
                    if target_dir and target_dir != ".":
                        os.makedirs(target_dir, exist_ok=True)
                
                # Copy files
                for file in files:
                    source_file = os.path.join(root, file)
                    target_file = os.path.join(rel_path, file)
                    
                    if target_file and os.path.exists(source_file):
                        with open(source_file, 'r', encoding='utf-8', errors='ignore') as f_in:
                            content = f_in.read()
                        with open(target_file, 'w', encoding='utf-8') as f_out:
                            f_out.write(content)
                        result["files_restored"].append(target_file)
            
            result["success"] = True
            logger.info(f"System restored from backup at {backup_path}")
        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Restore failed: {e}")
        
        return result
    
    # Private helper methods
    
    def _monitor_app(self):
        """Continuously monitor the application status."""
        while self.keep_monitoring:
            try:
                self._update_app_status()
                time.sleep(30)  # Check every 30 seconds
            except Exception as e:
                logger.error(f"Error in monitoring thread: {e}")
                time.sleep(60)  # Wait longer after error
    
    def _monitor_logs(self):
        """Monitor application logs for errors and warnings."""
        log_file = "assistant_logs.txt"
        
        # Create log file if it doesn't exist
        if not os.path.exists(log_file):
            open(log_file, 'a').close()
        
        last_position = os.path.getsize(log_file)
        
        while self.keep_monitoring:
            try:
                current_size = os.path.getsize(log_file)
                if current_size > last_position:
                    with open(log_file, 'r') as f:
                        f.seek(last_position)
                        new_logs = f.read()
                        self._analyze_logs(new_logs)
                    last_position = current_size
                
                time.sleep(10)  # Check logs every 10 seconds
            except Exception as e:
                logger.error(f"Error monitoring logs: {e}")
                time.sleep(30)  # Wait longer after error
    
    def _update_app_status(self):
        """Update the current status of the application."""
        # Check if the app is running
        self.app_status["running"] = self._is_app_running()
        
        # Check model status using the app's API
        if self.app_status["running"]:
            try:
                import requests
                response = requests.get("http://localhost:5000/check_system", timeout=5)
                if response.status_code == 200:
                    system_status = response.json()
                    self.app_status["models_status"] = system_status.get("models", {})
            except:
                # If API call fails, we'll use the previous status
                pass
        
        self.app_status["last_check"] = datetime.now()
    
    def _is_app_running(self) -> bool:
        """Check if the Flask application is running."""
        try:
            import requests
            response = requests.get("http://localhost:5000/", timeout=2)
            return response.status_code == 200
        except:
            return False
    
    def _analyze_logs(self, log_content: str):
        """Analyze log content to detect errors and issues."""
        # Look for errors
        error_patterns = [
            (r"Error.*?: (.*)", "general"),
            (r"Exception.*?: (.*)", "exception"),
            (r"Failed to (.*)", "initialization"),
            (r"WARNING.*?: (.*)", "warning")
        ]
        
        for pattern, error_type in error_patterns:
            for match in re.finditer(pattern, log_content, re.IGNORECASE):
                error_msg = match.group(1)
                self.app_status["errors"].append({
                    "type": error_type,
                    "message": error_msg,
                    "timestamp": datetime.now()
                })
                logger.info(f"Detected {error_type} issue: {error_msg}")
    
    def _get_improvement_suggestions(self) -> List[Dict[str, str]]:
        """Generate suggestions for improving the application."""
        suggestions = []
        
        # These are general improvement suggestions that are always relevant
        suggestions.append({
            "type": "improvement",
            "title": "Add user feedback system",
            "description": "Implement a feature to collect user feedback on accent conversion quality.",
            "action": "add_feedback_system"
        })
        
        suggestions.append({
            "type": "improvement",
            "title": "Optimize audio processing",
            "description": "Analyze and improve the audio processing pipeline for lower latency.",
            "action": "optimize_audio_processing"
        })
        
        suggestions.append({
            "type": "improvement",
            "title": "Add more accent options",
            "description": "Expand the available accent options to include more varieties.",
            "action": "add_accent_options"
        })
        
        return suggestions
    
    def _diagnose_vad_model(self) -> Dict[str, Any]:
        """Diagnose issues with the Voice Activity Detection model."""
        diagnosis = {
            "model_file_exists": os.path.exists("models/vad.py"),
            "import_errors": [],
            "configuration_issues": []
        }
        
        # Check for common issues
        with open("models/vad.py", 'r') as f:
            code = f.read()
            
            # Check for import errors
            import_patterns = [
                r"import\s+torch",
                r"import\s+torchaudio",
                r"from\s+resemblyzer",
                r"import\s+numpy"
            ]
            
            for pattern in import_patterns:
                if re.search(pattern, code):
                    try:
                        # Try to import and see if it works
                        module_name = re.search(r"import\s+(\w+)", pattern).group(1)
                        exec(f"import {module_name}")
                    except ImportError as e:
                        diagnosis["import_errors"].append(str(e))
        
        return diagnosis
    
    def _diagnose_speaker_model(self) -> Dict[str, Any]:
        """Diagnose issues with the Speaker Embedding model."""
        diagnosis = {
            "model_file_exists": os.path.exists("models/speaker_embedding.py"),
            "import_errors": [],
            "configuration_issues": []
        }
        
        # Similar checks as for VAD model
        if diagnosis["model_file_exists"]:
            with open("models/speaker_embedding.py", 'r') as f:
                code = f.read()
                
                # Check for import errors
                import_patterns = [
                    r"import\s+torch",
                    r"import\s+torchaudio",
                    r"from\s+resemblyzer",
                    r"import\s+numpy"
                ]
                
                for pattern in import_patterns:
                    if re.search(pattern, code):
                        try:
                            module_name = re.search(r"import\s+(\w+)", pattern).group(1)
                            exec(f"import {module_name}")
                        except ImportError as e:
                            diagnosis["import_errors"].append(str(e))
        
        return diagnosis
    
    def _diagnose_accent_model(self) -> Dict[str, Any]:
        """Diagnose issues with the Accent Conversion model."""
        diagnosis = {
            "model_file_exists": os.path.exists("models/accent_converter.py"),
            "import_errors": [],
            "configuration_issues": []
        }
        
        # Check file and imports similar to other models
        if diagnosis["model_file_exists"]:
            with open("models/accent_converter.py", 'r') as f:
                code = f.read()
                
                import_patterns = [
                    r"import\s+torch",
                    r"import\s+torchaudio",
                    r"import\s+numpy"
                ]
                
                for pattern in import_patterns:
                    if re.search(pattern, code):
                        try:
                            module_name = re.search(r"import\s+(\w+)", pattern).group(1)
                            exec(f"import {module_name}")
                        except ImportError as e:
                            diagnosis["import_errors"].append(str(e))
        
        return diagnosis
    
    def _diagnose_server(self) -> Dict[str, Any]:
        """Diagnose issues with the Flask server."""
        diagnosis = {
            "server_running": self._is_app_running(),
            "app_file_exists": os.path.exists("app.py"),
            "main_file_exists": os.path.exists("main.py"),
            "port_conflicts": [],
            "log_errors": []
        }
        
        # Check for port conflicts
        try:
            result = subprocess.run(["lsof", "-i", ":5000"], 
                                   stdout=subprocess.PIPE, 
                                   stderr=subprocess.PIPE,
                                   universal_newlines=True)
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:  # More than just the header line
                    diagnosis["port_conflicts"] = lines[1:]
        except:
            pass
        
        return diagnosis
    
    def _diagnose_audio_processing(self) -> Dict[str, Any]:
        """Diagnose issues with audio processing."""
        diagnosis = {
            "utils_exists": os.path.exists("utils/audio_utils.py"),
            "js_processor_exists": os.path.exists("static/js/audio_processor.js"),
            "js_app_exists": os.path.exists("static/js/app.js"),
            "import_errors": []
        }
        
        # Check for audio processing libraries
        try:
            import soundfile
        except ImportError as e:
            diagnosis["import_errors"].append(f"soundfile: {str(e)}")
        
        try:
            from pydub import AudioSegment
        except ImportError as e:
            diagnosis["import_errors"].append(f"pydub: {str(e)}")
        
        return diagnosis
    
    def _fix_vad_model(self, diagnosis: Dict[str, Any]) -> Dict[str, Any]:
        """
        Attempt to fix Voice Activity Detection model issues.
        
        Args:
            diagnosis: Diagnosis data from diagnose_issue
            
        Returns:
            Dict with results of the fix attempt
        """
        result = {
            "issue_type": "vad",
            "timestamp": datetime.now(),
            "success": False,
            "actions_taken": [],
            "message": ""
        }
        
        # 1. Check for missing modules and try to install them
        if diagnosis["import_errors"]:
            for error in diagnosis["import_errors"]:
                module = error.split("'")[1] if "'" in error else error.split()[0]
                try:
                    result["actions_taken"].append(f"Attempting to install {module}")
                    subprocess.run([sys.executable, "-m", "pip", "install", module], 
                                  check=True,
                                  stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE)
                except subprocess.CalledProcessError:
                    result["message"] = f"Failed to install {module}"
                    return result
        
        # 2. Check if fallback implementation is needed
        if not os.path.exists("models/vad.py"):
            result["message"] = "VAD model file not found"
            return result
        
        # 3. Implement fallback if needed
        with open("models/vad.py", 'r') as f:
            vad_code = f.read()
            
        if "class FallbackVAD" not in vad_code and "Failed to load Silero VAD model" in vad_code:
            # Add fallback implementation
            with open("models/vad.py", 'w') as f:
                # Insert fallback implementation before the class ends
                updated_code = vad_code.replace(
                    "            # Fallback behavior if model failed to load",
                    """            # Fallback behavior if model failed to load
            # Implement a simple energy-based VAD as fallback
            class FallbackVAD:
                def __init__(self, threshold=0.1):
                    self.threshold = threshold
                
                def is_speech(self, audio):
                    # Simple energy-based detection
                    if isinstance(audio, bytes):
                        # Convert to numpy array
                        try:
                            import numpy as np
                            from pydub import AudioSegment
                            import io
                            audio_segment = AudioSegment.from_file(io.BytesIO(audio), format="wav")
                            samples = np.array(audio_segment.get_array_of_samples())
                            energy = np.mean(np.abs(samples))
                            return energy > (self.threshold * 32768.0)  # 16-bit audio max value
                        except:
                            return True
                    else:
                        # Assume it's already a numpy array or tensor
                        import numpy as np
                        if hasattr(audio, 'numpy'):
                            audio = audio.numpy()
                        energy = np.mean(np.abs(audio))
                        return energy > self.threshold
            
            # Use fallback
            self.model = FallbackVAD()
            logger.warning("Using fallback energy-based VAD")"""
                )
                f.write(updated_code)
                result["actions_taken"].append("Added fallback VAD implementation")
        
        # 4. Check if fix was successful
        try:
            # Reload the module
            import importlib
            import sys
            if "models.vad" in sys.modules:
                importlib.reload(sys.modules["models.vad"])
            
            # Test basic functionality
            from models.vad import SileroVAD
            vad = SileroVAD()
            # Very basic test with random data
            import numpy as np
            test_audio = np.random.rand(16000)  # 1 second of random audio
            result_ok = vad.is_speech(test_audio)
            
            result["success"] = True
            result["message"] = "VAD model fixed successfully"
            result["actions_taken"].append("Verified VAD model functionality")
        except Exception as e:
            result["message"] = f"Failed to verify VAD fix: {str(e)}"
        
        return result
    
    def _fix_speaker_model(self, diagnosis: Dict[str, Any]) -> Dict[str, Any]:
        """
        Attempt to fix Speaker Embedding model issues.
        
        Args:
            diagnosis: Diagnosis data from diagnose_issue
            
        Returns:
            Dict with results of the fix attempt
        """
        # Similar structure to _fix_vad_model
        result = {
            "issue_type": "speaker_embedding",
            "timestamp": datetime.now(),
            "success": False,
            "actions_taken": [],
            "message": ""
        }
        
        # Fix import errors
        if diagnosis["import_errors"]:
            for error in diagnosis["import_errors"]:
                module = error.split("'")[1] if "'" in error else error.split()[0]
                try:
                    result["actions_taken"].append(f"Attempting to install {module}")
                    subprocess.run([sys.executable, "-m", "pip", "install", module], 
                                  check=True,
                                  stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE)
                except subprocess.CalledProcessError:
                    result["message"] = f"Failed to install {module}"
                    return result
        
        # Implement specific fixes for speaker model if needed
        
        # Verify the fix
        try:
            import importlib
            import sys
            if "models.speaker_embedding" in sys.modules:
                importlib.reload(sys.modules["models.speaker_embedding"])
            
            from models.speaker_embedding import SpeakerEmbedding
            speaker_model = SpeakerEmbedding()
            
            import numpy as np
            test_audio = np.random.rand(16000)  # 1 second of random audio
            embedding = speaker_model.extract_embedding(test_audio)
            
            result["success"] = True
            result["message"] = "Speaker embedding model fixed successfully"
            result["actions_taken"].append("Verified speaker model functionality")
        except Exception as e:
            result["message"] = f"Failed to verify speaker model fix: {str(e)}"
        
        return result
    
    def _fix_accent_model(self, diagnosis: Dict[str, Any]) -> Dict[str, Any]:
        """
        Attempt to fix Accent Conversion model issues.
        
        Args:
            diagnosis: Diagnosis data from diagnose_issue
            
        Returns:
            Dict with results of the fix attempt
        """
        # Similar to other model fixes
        result = {
            "issue_type": "accent_converter",
            "timestamp": datetime.now(),
            "success": False,
            "actions_taken": [],
            "message": ""
        }
        
        # Fix import errors and other issues
        # ...
        
        # Verification
        try:
            import importlib
            import sys
            if "models.accent_converter" in sys.modules:
                importlib.reload(sys.modules["models.accent_converter"])
            
            from models.accent_converter import AccentConverter
            accent_model = AccentConverter()
            
            result["success"] = True
            result["message"] = "Accent conversion model fixed successfully"
            result["actions_taken"].append("Verified accent model functionality")
        except Exception as e:
            result["message"] = f"Failed to verify accent model fix: {str(e)}"
        
        return result
    
    def _fix_server(self, diagnosis: Dict[str, Any]) -> Dict[str, Any]:
        """
        Attempt to fix server issues.
        
        Args:
            diagnosis: Diagnosis data from diagnose_issue
            
        Returns:
            Dict with results of the fix attempt
        """
        result = {
            "issue_type": "server",
            "timestamp": datetime.now(),
            "success": False,
            "actions_taken": [],
            "message": ""
        }
        
        # Check if the server is not running
        if not diagnosis["server_running"]:
            # Try to restart the server
            try:
                # Find the existing server process and terminate it
                subprocess.run(["pkill", "-f", "gunicorn.*app"], 
                              stdout=subprocess.PIPE, 
                              stderr=subprocess.PIPE)
                result["actions_taken"].append("Terminated existing server processes")
                
                # Start the server in a new process
                subprocess.Popen(["gunicorn", "--bind", "0.0.0.0:5000", "main:app"],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)
                result["actions_taken"].append("Started new server process")
                
                # Wait a bit for the server to start
                time.sleep(5)
                
                # Check if it's running now
                if self._is_app_running():
                    result["success"] = True
                    result["message"] = "Server restarted successfully"
                else:
                    result["message"] = "Failed to restart server"
            except Exception as e:
                result["message"] = f"Error restarting server: {str(e)}"
        else:
            result["success"] = True
            result["message"] = "Server is already running"
        
        return result
    
    def _fix_audio_processing(self, diagnosis: Dict[str, Any]) -> Dict[str, Any]:
        """
        Attempt to fix audio processing issues.
        
        Args:
            diagnosis: Diagnosis data from diagnose_issue
            
        Returns:
            Dict with results of the fix attempt
        """
        result = {
            "issue_type": "audio_processing",
            "timestamp": datetime.now(),
            "success": False,
            "actions_taken": [],
            "message": ""
        }
        
        # Install missing audio processing libraries
        if diagnosis["import_errors"]:
            for error in diagnosis["import_errors"]:
                module_name = error.split(":")[0].strip()
                try:
                    result["actions_taken"].append(f"Installing {module_name}")
                    subprocess.run([sys.executable, "-m", "pip", "install", module_name],
                                  check=True,
                                  stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE)
                except subprocess.CalledProcessError:
                    result["message"] = f"Failed to install {module_name}"
                    return result
        
        # Verify audio processing functionality
        try:
            from utils.audio_utils import wav_bytes_to_numpy, numpy_to_wav_bytes
            import numpy as np
            
            # Create a simple test audio
            test_audio = np.sin(2 * np.pi * 440 * np.arange(16000) / 16000).astype(np.float32)
            test_audio_bytes = numpy_to_wav_bytes(test_audio, 16000)
            
            # Try to convert it back
            audio_data, sample_rate = wav_bytes_to_numpy(test_audio_bytes)
            
            if audio_data is not None and sample_rate == 16000:
                result["success"] = True
                result["message"] = "Audio processing fixed successfully"
                result["actions_taken"].append("Verified audio processing functionality")
            else:
                result["message"] = "Audio processing verification failed"
        except Exception as e:
            result["message"] = f"Failed to verify audio processing fix: {str(e)}"
        
        return result
    
    def _measure_latency(self) -> float:
        """Measure the API latency of the application."""
        if not self._is_app_running():
            return -1
        
        try:
            import requests
            import time
            
            start_time = time.time()
            response = requests.get("http://localhost:5000/check_system", timeout=5)
            end_time = time.time()
            
            if response.status_code == 200:
                return (end_time - start_time) * 1000  # Convert to milliseconds
            return -1
        except:
            return -1
    
    def _get_cpu_usage(self) -> float:
        """Get CPU usage of the application."""
        try:
            import psutil
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                if any('python' in cmd for cmd in proc.info['cmdline'] if cmd) and \
                   any('app.py' in cmd for cmd in proc.info['cmdline'] if cmd):
                    return proc.cpu_percent(interval=0.5)
            return -1
        except:
            return -1
    
    def _get_memory_usage(self) -> Dict[str, float]:
        """Get memory usage of the application."""
        try:
            import psutil
            memory_info = {"rss": 0, "vms": 0}
            
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                if any('python' in cmd for cmd in proc.info['cmdline'] if cmd) and \
                   any('app.py' in cmd for cmd in proc.info['cmdline'] if cmd):
                    proc_memory = proc.memory_info()
                    memory_info["rss"] = proc_memory.rss / (1024 * 1024)  # MB
                    memory_info["vms"] = proc_memory.vms / (1024 * 1024)  # MB
                    break
            
            return memory_info
        except:
            return {"rss": -1, "vms": -1}
    
    def _get_active_connections(self) -> int:
        """Get the number of active connections to the application."""
        try:
            result = subprocess.run(["lsof", "-i", ":5000"], 
                                  stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE,
                                  universal_newlines=True)
            if result.returncode == 0:
                # Count unique connection entries (ESTABLISHED)
                connections = [line for line in result.stdout.split('\n') 
                             if 'ESTABLISHED' in line]
                return len(connections)
            return 0
        except:
            return -1
    
    def _get_model_performance(self) -> Dict[str, float]:
        """Get performance metrics for the AI models."""
        # This is a placeholder. In a real system you would collect actual metrics
        return {
            "vad_latency": -1,
            "speaker_embedding_latency": -1, 
            "accent_conversion_latency": -1
        }
    
    def _save_diagnosis(self, diagnosis: Dict[str, Any]):
        """Save diagnosis results to a file for reference."""
        filename = f"assistant_data/diagnosis_{diagnosis['issue_type']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        
        with open(filename, 'w') as f:
            f.write(f"Diagnosis for {diagnosis['issue_type']} at {diagnosis['timestamp']}\n")
            f.write("="*80 + "\n\n")
            
            # Format the details section
            f.write("Details:\n")
            for key, value in diagnosis['details'].items():
                f.write(f"  {key}: {value}\n")
            
            # Format potential fixes
            if diagnosis['potential_fixes']:
                f.write("\nPotential fixes:\n")
                for fix in diagnosis['potential_fixes']:
                    f.write(f"  - {fix}\n")

# Command line interface for the assistant

def main():
    """Main entry point for the AI Assistant CLI."""
    assistant = DexentAIAssistant()
    assistant.start_monitoring()
    
    print("Dexent AI Assistant")
    print("="*80)
    print("Type 'help' for available commands")
    
    while True:
        try:
            command = input("> ").strip().lower()
            
            if command == 'exit' or command == 'quit':
                break
            elif command == 'help':
                print("\nAvailable commands:")
                print("  status       - Show application status")
                print("  diagnose     - Diagnose a specific issue")
                print("  fix          - Attempt to fix a specific issue")
                print("  suggestions  - Show improvement suggestions")
                print("  metrics      - Show performance metrics")
                print("  backup       - Create a system backup")
                print("  restore      - Restore from a backup")
                print("  exit/quit    - Exit the assistant")
            elif command == 'status':
                status = assistant.check_app_status()
                print("\nApplication Status:")
                print(f"  Running: {status['running']}")
                print("  Models:")
                for model, ready in status["models_status"].items():
                    print(f"    - {model}: {'Ready' if ready else 'Not ready'}")
                
                if status["errors"]:
                    print("\nRecent Errors:")
                    for error in status["errors"][-5:]:  # Show last 5 errors
                        print(f"  - [{error['timestamp']}] {error['type']}: {error['message']}")
            elif command == 'diagnose':
                issue_type = input("Enter issue type to diagnose (vad, speaker_embedding, accent_converter, server, audio_processing): ").strip()
                diagnosis = assistant.diagnose_issue(issue_type)
                
                print(f"\nDiagnosis for {issue_type}:")
                for key, value in diagnosis["details"].items():
                    print(f"  {key}: {value}")
            elif command == 'fix':
                issue_type = input("Enter issue type to fix (vad, speaker_embedding, accent_converter, server, audio_processing): ").strip()
                result = assistant.fix_issue(issue_type)
                
                print(f"\nFix result for {issue_type}:")
                print(f"  Success: {result['success']}")
                print(f"  Message: {result['message']}")
                print("  Actions taken:")
                for action in result["actions_taken"]:
                    print(f"    - {action}")
            elif command == 'suggestions':
                suggestions = assistant.get_suggestions()
                
                print("\nImprovement Suggestions:")
                for suggestion in suggestions:
                    print(f"  [{suggestion['type']}] {suggestion['title']}")
                    print(f"    {suggestion['description']}")
                    print()
            elif command == 'metrics':
                metrics = assistant.get_performance_metrics()
                
                print("\nPerformance Metrics:")
                print(f"  API Latency: {metrics['latency']:.2f} ms")
                print(f"  CPU Usage: {metrics['cpu_usage']:.1f}%")
                print(f"  Memory Usage: {metrics['memory_usage']['rss']:.1f} MB")
                print(f"  Active Connections: {metrics['active_connections']}")
            elif command == 'backup':
                result = assistant.backup_system()
                
                if result["success"]:
                    print(f"Backup created successfully at: {result['backup_path']}")
                    print(f"Backed up {len(result['files_backed_up'])} files")
                else:
                    print(f"Backup failed: {result.get('error', 'Unknown error')}")
            elif command == 'restore':
                backup_path = input("Enter backup path to restore from: ").strip()
                if os.path.exists(backup_path):
                    confirm = input(f"Are you sure you want to restore from {backup_path}? (y/n): ").strip().lower()
                    if confirm == 'y':
                        result = assistant.restore_system(backup_path)
                        
                        if result["success"]:
                            print(f"System restored successfully from {backup_path}")
                            print(f"Restored {len(result['files_restored'])} files")
                        else:
                            print(f"Restore failed: {result.get('error', 'Unknown error')}")
                else:
                    print(f"Backup path {backup_path} does not exist")
            else:
                print("Unknown command. Type 'help' for available commands.")
        except KeyboardInterrupt:
            print("\nExiting...")
            break
        except Exception as e:
            print(f"Error: {e}")
    
    assistant.stop_monitoring()
    print("AI Assistant terminated")

if __name__ == "__main__":
    main()