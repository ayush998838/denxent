"""
Transcript Generator Model for dexent.ai.

This module provides a class for meeting recording transcription and summarization.
"""
import os
import logging
import numpy as np
import io
import json
import re
import datetime
from pydub import AudioSegment
import torch
import torch.nn as nn

logger = logging.getLogger(__name__)

class TranscriptGenerator:
    """
    Class to handle speech-to-text transcription, meeting summarization,
    and action item extraction.
    
    This is a simulated model for demonstration purposes. In a real application,
    this would implement Whisper, Wav2Vec2, or other speech recognition models.
    """
    
    def __init__(self):
        """Initialize the transcript generator model."""
        self.logger = logging.getLogger(__name__)
        self.logger.info("Initializing Transcript Generator model")
        
        try:
            # Try to initialize the model with GPU if available
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            self.logger.info(f"Using device: {self.device}")
            
            # In a real implementation, this would load pre-trained models
            self._init_models()
            self.logger.info("Transcript Generator model initialized successfully")
        except Exception as e:
            self.logger.error(f"Error initializing Transcript Generator model: {e}")
            self.transcription_model = None
            self.summarization_model = None
            self.action_item_model = None
            raise
    
    def _init_models(self):
        """Initialize the transcription, summarization and action item extraction models."""
        # In a real implementation, these would be deep neural networks
        # like Whisper for ASR and GPT/BERT models for summarization
        
        # For this demo, we'll create simple model structures
        self.transcription_model = SimpleTranscriber()
        self.summarization_model = SimpleSummarizer()
        self.action_item_model = SimpleActionItemExtractor()
        
        # Normally we would load weights here:
        # self.transcription_model.load_state_dict(torch.load("transcriber_weights.pth"))
        # self.summarization_model.load_state_dict(torch.load("summarizer_weights.pth"))
        # self.action_item_model.load_state_dict(torch.load("extractor_weights.pth"))
    
    def transcribe(self, audio_bytes):
        """
        Transcribe audio data to text.
        
        Args:
            audio_bytes (bytes): Raw audio data as bytes
            
        Returns:
            str: Transcribed text
        """
        try:
            if self.transcription_model is None:
                self.logger.warning("Transcription model not initialized")
                return "Error: Transcription model not initialized"
            
            # Process the audio bytes
            audio_segment = self._preprocess_audio(audio_bytes)
            
            # In a real implementation, we'd use a proper ASR model like Whisper
            # For this demo, we'll simulate a transcription for testing purposes
            # In a production system, this would be replaced with actual model inference
            
            # Simulate a meeting transcript with multiple speakers
            return self._simulate_transcript(audio_segment)
            
        except Exception as e:
            self.logger.error(f"Error transcribing audio: {e}")
            return f"Error transcribing audio: {str(e)}"
    
    def summarize(self, transcript):
        """
        Generate a summary from a meeting transcript.
        
        Args:
            transcript (str): Meeting transcript text
            
        Returns:
            str: Summary of the meeting
        """
        try:
            if self.summarization_model is None:
                self.logger.warning("Summarization model not initialized")
                return "Error: Summarization model not initialized"
            
            # In a real implementation, we'd use a proper NLP model like BART/T5/GPT
            # For this demo, we'll simulate a summary for testing purposes
            
            # Split transcript into chunks to simulate processing
            chunks = self._chunk_text(transcript, 500)  # Chunk size of 500 chars
            
            # Generate summary
            summary = self._simulate_summary(chunks, transcript)
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Error summarizing transcript: {e}")
            return f"Error summarizing transcript: {str(e)}"
    
    def extract_action_items(self, transcript):
        """
        Extract action items from a meeting transcript.
        
        Args:
            transcript (str): Meeting transcript text
            
        Returns:
            list: List of action items with assigned person and due date if available
        """
        try:
            if self.action_item_model is None:
                self.logger.warning("Action item extraction model not initialized")
                return []
            
            # In a real implementation, we'd use a proper NLU model
            # For this demo, we'll simulate action item extraction
            
            # Simple regex-based extraction (would be ML-based in real app)
            action_items = []
            
            # Extract anything that looks like a task assignment
            patterns = [
                r'(?i)(\w+) will (.*?)(?=\.|$)',
                r'(?i)(\w+) needs to (.*?)(?=\.|$)',
                r'(?i)(\w+) should (.*?)(?=\.|$)',
                r'(?i)action item for (\w+):(.*?)(?=\.|$)',
                r'(?i)task for (\w+):(.*?)(?=\.|$)'
            ]
            
            for pattern in patterns:
                matches = re.finditer(pattern, transcript)
                for match in matches:
                    person = match.group(1)
                    task = match.group(2).strip()
                    
                    # Try to extract due dates
                    due_date = None
                    date_patterns = [
                        r'(?i)by (tomorrow|next week|next month)',
                        r'(?i)by (Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)',
                        r'(?i)by (\d{1,2}(?:st|nd|rd|th)? (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec))',
                        r'(?i)by (\d{1,2}/\d{1,2}(?:/\d{2,4})?)'
                    ]
                    
                    for date_pattern in date_patterns:
                        date_match = re.search(date_pattern, task)
                        if date_match:
                            date_text = date_match.group(1)
                            # Convert to an actual date (simplified)
                            due_date = self._parse_date(date_text)
                            # Remove the date part from the task description
                            task = re.sub(f"by {re.escape(date_text)}", "", task).strip()
                    
                    action_items.append({
                        "description": task,
                        "assigned_to": person,
                        "due_date": due_date
                    })
            
            # If we didn't find any action items, simulate some
            if not action_items and len(transcript) > 100:
                action_items = self._simulate_action_items(transcript)
                
            return action_items
            
        except Exception as e:
            self.logger.error(f"Error extracting action items: {e}")
            return []
    
    def _preprocess_audio(self, audio_bytes):
        """Convert audio bytes to AudioSegment."""
        try:
            buffer = io.BytesIO(audio_bytes)
            return AudioSegment.from_file(buffer)
        except Exception as e:
            self.logger.error(f"Error preprocessing audio: {e}")
            # Try to determine the format from the first few bytes
            buffer = io.BytesIO(audio_bytes)
            return AudioSegment.from_wav(buffer)
    
    def _chunk_text(self, text, chunk_size):
        """Split text into chunks of approximately chunk_size characters."""
        chunks = []
        current_chunk = ""
        
        for sentence in re.split(r'(?<=[.!?])\s+', text):
            if len(current_chunk) + len(sentence) <= chunk_size:
                current_chunk += " " + sentence if current_chunk else sentence
            else:
                chunks.append(current_chunk)
                current_chunk = sentence
        
        if current_chunk:
            chunks.append(current_chunk)
            
        return chunks
    
    def _parse_date(self, date_text):
        """
        Parse date text to a datetime object.
        
        This is a simplified implementation. In a real app, we would use
        a more sophisticated date parser like dateutil.
        """
        today = datetime.datetime.now()
        
        # Handle relative dates
        if date_text.lower() == 'tomorrow':
            return (today + datetime.timedelta(days=1)).strftime("%Y-%m-%d")
        elif date_text.lower() == 'next week':
            return (today + datetime.timedelta(days=7)).strftime("%Y-%m-%d")
        elif date_text.lower() == 'next month':
            # Simple approximation - in reality would handle month boundaries better
            return (today + datetime.timedelta(days=30)).strftime("%Y-%m-%d")
        
        # Handle day of week
        days = {
            'monday': 0, 'tuesday': 1, 'wednesday': 2, 'thursday': 3,
            'friday': 4, 'saturday': 5, 'sunday': 6
        }
        
        day_text = date_text.lower()
        if day_text in days:
            today_day = today.weekday()
            days_until = (days[day_text] - today_day) % 7
            if days_until == 0:
                days_until = 7  # Next week if the day is today
            return (today + datetime.timedelta(days=days_until)).strftime("%Y-%m-%d")
        
        # For more complex dates, in a real app we would use a proper date parser
        # Here we'll just return the original text
        return date_text
    
    def _simulate_transcript(self, audio_segment):
        """
        Simulate a meeting transcript for demo purposes.
        
        In a real application, this would be replaced with actual ASR output.
        """
        # The length of audio will affect the simulated transcript length
        duration_seconds = len(audio_segment) / 1000.0
        
        # Create a realistic-looking meeting transcript
        speakers = ["John", "Sarah", "Mike", "Emily"]
        
        # Sample meeting topics and phrases
        topics = [
            "quarterly sales report",
            "new product launch",
            "marketing strategy",
            "client feedback",
            "team performance"
        ]
        
        # Select a random topic for the meeting
        import random
        meeting_topic = random.choice(topics)
        
        # Generate simulated transcript
        transcript_lines = []
        
        # Meeting introduction
        transcript_lines.append(f"[00:00] Sarah: Good morning everyone, let's start our meeting about the {meeting_topic}.")
        transcript_lines.append(f"[00:05] John: Thanks Sarah. I've prepared some points to discuss today.")
        
        # Generate more lines based on audio duration (rough approximation)
        # In a real transcript this would be the actual speech content
        line_count = max(5, int(duration_seconds / 5))  # Approx 1 line per 5 seconds
        
        # Sample phrases for the selected topic
        phrases = {
            "quarterly sales report": [
                "Our Q2 revenue increased by 15% compared to Q1.",
                "The new sales strategy is working well in the western region.",
                "We need to focus on improving conversion rates in online channels.",
                "Customer retention is up by 8% this quarter.",
                "The sales team will follow up with our top 20 customers next week."
            ],
            "new product launch": [
                "The beta testing has been completed with positive feedback.",
                "Marketing materials are ready for distribution next Monday.",
                "We should schedule the press release for the 15th.",
                "Initial inventory will arrive at warehouses by the end of the month.",
                "Emily will coordinate with the social media team on the launch campaign."
            ],
            "marketing strategy": [
                "Our social media engagement has increased by 25% since the last campaign.",
                "We need to allocate more budget to digital advertising.",
                "The content team is preparing new material for the blog.",
                "Mike will update the marketing plan by next Tuesday.",
                "We should consider hiring another content writer."
            ],
            "client feedback": [
                "Customer satisfaction scores have improved to 4.2 out of 5.",
                "The recent survey highlighted issues with our support response times.",
                "John will follow up with the dissatisfied clients this week.",
                "We need to implement the suggested UI improvements by next month.",
                "The product team should prioritize fixing the reported bugs."
            ],
            "team performance": [
                "Overall productivity increased by 12% this quarter.",
                "We need to address the communication issues between departments.",
                "Sarah will organize a team-building event next month.",
                "The new performance review system will be rolled out next quarter.",
                "We should consider providing additional training for the junior staff."
            ]
        }
        
        topic_phrases = phrases[meeting_topic]
        
        # Generate transcript content
        current_minute = 0
        for i in range(line_count):
            # Update timestamp every few lines
            if i % 3 == 0:
                current_minute += 1
            
            timestamp = f"[{current_minute:02d}:{random.randint(0, 59):02d}]"
            speaker = random.choice(speakers)
            
            if i < len(topic_phrases):
                content = topic_phrases[i]
            else:
                # If we run out of predefined phrases, generate some filler content
                content = f"I think we should consider {random.choice(['improving', 'reviewing', 'updating', 'discussing'])} our approach to {random.choice(['efficiency', 'quality', 'customer satisfaction', 'innovation'])}."
            
            transcript_lines.append(f"{timestamp} {speaker}: {content}")
        
        # Add a closing to the meeting
        transcript_lines.append(f"[{current_minute+1:02d}:00] Sarah: Thank you everyone for your input. Let's follow up on these action items next week.")
        
        return "\n".join(transcript_lines)
    
    def _simulate_summary(self, chunks, transcript):
        """
        Simulate a meeting summary for demo purposes.
        
        In a real application, this would be replaced with actual NLP model output.
        """
        # Extract key information from the transcript
        lines = transcript.split('\n')
        
        # Find the meeting topic (simplified)
        topic_match = re.search(r'meeting about the (.*?)\.', transcript)
        topic = topic_match.group(1) if topic_match else "discussion topics"
        
        # Extract speakers
        speakers = set()
        for line in lines:
            speaker_match = re.search(r'\[\d+:\d+\] (\w+):', line)
            if speaker_match:
                speakers.add(speaker_match.group(1))
        
        # Create a summary
        summary = f"Meeting Summary: {topic.title()}\n\n"
        summary += f"Participants: {', '.join(sorted(speakers))}\n\n"
        
        # Add key points section
        summary += "Key Points Discussed:\n"
        
        # Extract some sentences that might be important
        key_sentences = []
        important_patterns = [
            r'(?i)need to',
            r'(?i)should',
            r'(?i)will',
            r'(?i)increase',
            r'(?i)improve',
            r'(?i)issue',
            r'(?i)problem',
            r'(?i)solution'
        ]
        
        for line in lines:
            for pattern in important_patterns:
                if re.search(pattern, line):
                    # Extract just the content part
                    content_match = re.search(r'\[\d+:\d+\] \w+: (.*)', line)
                    if content_match:
                        key_sentences.append(content_match.group(1))
                    break
        
        # Limit to 5 key points
        key_sentences = key_sentences[:5]
        for i, sentence in enumerate(key_sentences, 1):
            summary += f"{i}. {sentence}\n"
        
        # Add action items section
        action_items = self.extract_action_items(transcript)
        if action_items:
            summary += "\nAction Items:\n"
            for i, item in enumerate(action_items, 1):
                due_date_text = f" (Due: {item['due_date']})" if item['due_date'] else ""
                summary += f"{i}. {item['assigned_to']} to {item['description']}{due_date_text}\n"
        
        # Add a conclusion
        summary += "\nNext Steps:\n"
        summary += "Follow up on action items and schedule next meeting.\n"
        
        return summary
    
    def _simulate_action_items(self, transcript):
        """
        Simulate action items for demo purposes.
        
        In a real application, this would be replaced with actual NLU model output.
        """
        # Extract speakers
        speakers = set()
        for line in transcript.split('\n'):
            speaker_match = re.search(r'\[\d+:\d+\] (\w+):', line)
            if speaker_match:
                speakers.add(speaker_match.group(1))
        
        speakers = list(speakers)
        if not speakers:
            speakers = ["John", "Sarah", "Mike", "Emily"]
        
        # Generate sample action items
        import random
        
        actions = [
            "prepare the presentation for next meeting",
            "follow up with the clients",
            "update the project timeline",
            "review the budget proposal",
            "coordinate with the marketing team",
            "draft the quarterly report",
            "schedule a follow-up discussion",
            "research the competitor's new product",
            "update the team on progress",
            "implement the suggested improvements"
        ]
        
        # Generate 2-4 action items
        num_items = random.randint(2, 4)
        action_items = []
        
        for _ in range(num_items):
            person = random.choice(speakers)
            task = random.choice(actions)
            
            # 50% chance of having a due date
            due_date = None
            if random.random() > 0.5:
                days_ahead = random.randint(1, 14)
                due_date = (datetime.datetime.now() + datetime.timedelta(days=days_ahead)).strftime("%Y-%m-%d")
            
            action_items.append({
                "description": task,
                "assigned_to": person,
                "due_date": due_date
            })
        
        return action_items


class SimpleTranscriber(nn.Module):
    """
    A simple neural network for speech-to-text.
    
    In a real implementation, this would be a more complex architecture like
    Whisper, Wav2Vec2, or another ASR model.
    """
    
    def __init__(self):
        """Initialize the transcriber model."""
        super(SimpleTranscriber, self).__init__()
        # In a real implementation, this would have the model architecture
        # For this demo, it's just a placeholder


class SimpleSummarizer(nn.Module):
    """
    A simple neural network for text summarization.
    
    In a real implementation, this would be a more complex architecture like
    BART, T5, or a GPT-based model.
    """
    
    def __init__(self):
        """Initialize the summarizer model."""
        super(SimpleSummarizer, self).__init__()
        # In a real implementation, this would have the model architecture
        # For this demo, it's just a placeholder


class SimpleActionItemExtractor(nn.Module):
    """
    A simple neural network for extracting action items.
    
    In a real implementation, this would be a more complex NLU model.
    """
    
    def __init__(self):
        """Initialize the action item extractor model."""
        super(SimpleActionItemExtractor, self).__init__()
        # In a real implementation, this would have the model architecture
        # For this demo, it's just a placeholder