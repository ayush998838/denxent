"""
Database models for Dexent.ai.

This module defines the database models used for user management and conversion history.
"""
import os
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

# This will be set from app.py to avoid circular imports
db = None

class User(object):  # Will be properly set up when db is assigned
    """User model for storing user details and authentication information."""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    firebase_uid = db.Column(db.String(128), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    display_name = db.Column(db.String(64), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship with conversion history
    conversions = db.relationship('ConversionHistory', backref='user', lazy=True)
    
    # Relationship with user preferences
    preferences = db.relationship('UserPreference', backref='user', lazy=True, uselist=False)
    
    def __repr__(self):
        return f'<User {self.email}>'


class UserPreference(db.Model):
    """User preferences for accent conversion settings."""
    __tablename__ = 'user_preferences'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    default_accent = db.Column(db.String(32), default='british')
    audio_quality = db.Column(db.String(16), default='medium')  # low, medium, high
    conversion_speed = db.Column(db.String(16), default='balanced')  # fast, balanced, accurate
    
    def __repr__(self):
        return f'<UserPreference for user_id={self.user_id}>'


class ConversionHistory(db.Model):
    """History of accent conversions performed by users."""
    __tablename__ = 'conversion_history'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    source_accent = db.Column(db.String(32), nullable=True)
    target_accent = db.Column(db.String(32), nullable=False)
    duration_seconds = db.Column(db.Float, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    audio_stored = db.Column(db.Boolean, default=False)
    audio_path = db.Column(db.String(256), nullable=True)
    
    def __repr__(self):
        return f'<ConversionHistory id={self.id}, user_id={self.user_id}>'


class SystemMetric(db.Model):
    """System performance metrics tracked over time."""
    __tablename__ = 'system_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    api_latency_ms = db.Column(db.Float, nullable=True)
    cpu_usage_percent = db.Column(db.Float, nullable=True)
    memory_usage_mb = db.Column(db.Float, nullable=True)
    active_connections = db.Column(db.Integer, nullable=True)
    
    def __repr__(self):
        return f'<SystemMetric id={self.id}, timestamp={self.timestamp}>'