import os
import io
import torch
import logging
import numpy as np
from pydub import AudioSegment

logger = logging.getLogger(__name__)

class EnergyVAD:
    """
    Simple energy-based Voice Activity Detection as fallback.
    Uses signal energy to detect speech segments.
    """
    
    def __init__(self, energy_threshold=0.015, min_speech_frames=10):
        """
        Initialize the energy-based VAD.
        
        Args:
            energy_threshold (float): Energy threshold for speech detection
            min_speech_frames (int): Minimum consecutive frames to be considered speech
        """
        self.energy_threshold = energy_threshold
        self.min_speech_frames = min_speech_frames
        logger.info(f"Energy-based VAD initialized with threshold {energy_threshold}")
    
    def __call__(self, audio, sampling_rate):
        """
        Run VAD on audio tensor.
        
        Args:
            audio (torch.Tensor): Audio tensor
            sampling_rate (int): Audio sampling rate
            
        Returns:
            torch.Tensor: Tensor with speech probability (0.0 or 1.0)
        """
        # Convert to numpy
        samples = audio.numpy()
        
        # Calculate frame energy
        frame_size = int(sampling_rate * 0.02)  # 20ms frames
        if len(samples) < frame_size:
            energy = np.sum(samples**2) / max(1, len(samples))
            return torch.tensor([1.0 if energy > self.energy_threshold else 0.0])
        
        # Split into frames and calculate energy
        frames = [samples[i:i+frame_size] for i in range(0, len(samples), frame_size)]
        energies = [np.sum(frame**2) / len(frame) for frame in frames]
        
        # Decision
        speech_frames = sum(1 for e in energies if e > self.energy_threshold)
        is_speech = speech_frames >= self.min_speech_frames
        
        return torch.tensor([1.0 if is_speech else 0.0])


class SileroVAD:
    """
    Voice Activity Detection using Silero VAD model.
    Detects speech segments in audio.
    """
    
    def __init__(self, threshold=0.5, sampling_rate=16000):
        """
        Initialize the VAD model.
        
        Args:
            threshold (float): Speech detection threshold (0.0 to 1.0)
            sampling_rate (int): Audio sampling rate (16000 recommended)
        """
        self.threshold = threshold
        self.sampling_rate = sampling_rate
        self.model = None
        self.utils = None
        
        # Try to load the model
        try:
            self.model, self.utils = torch.hub.load(
                repo_or_dir='snakers4/silero-vad',
                model='silero_vad',
                force_reload=False
            )
            
            # Unpack the utils
            (self.get_speech_timestamps, 
             self.save_audio, 
             self.read_audio, 
             self.VADIterator, 
             self.collect_chunks) = self.utils
            
            logger.info("Silero VAD model loaded successfully")
        except Exception as e:
            logger.warning(f"Failed to load Silero VAD model: {e}")
            logger.info("Switching to energy-based VAD fallback")
            # Use energy-based VAD as fallback
            self.model = EnergyVAD()
            
            # Mock timestamp function for compatibility
            def mock_timestamps(audio, model, threshold, sampling_rate):
                is_speech = model(audio, sampling_rate).item() > 0.5
                return [{"start": 0, "end": len(audio)}] if is_speech else []
            
            self.get_speech_timestamps = mock_timestamps
    
    def is_speech(self, audio_data, return_prob=False):
        """
        Detect if speech is present in the audio data.
        
        Args:
            audio_data (bytes or numpy.ndarray): Audio data as bytes or numpy array
            return_prob (bool): If True, return the speech probability
            
        Returns:
            bool or float: True if speech is detected, or speech probability if return_prob=True
        """
        if self.model is None:
            # Fallback behavior if model failed to load
            logger.warning("VAD model not loaded, returning default speech detection")
            return True
        
        try:
            # Convert audio bytes to tensor
            if isinstance(audio_data, bytes):
                audio = self._convert_bytes_to_tensor(audio_data)
            else:
                audio = torch.tensor(audio_data)
            
            # Run VAD on the audio
            speech_prob = self.model(audio, self.sampling_rate).item()
            
            if return_prob:
                return speech_prob
            else:
                return speech_prob >= self.threshold
                
        except Exception as e:
            logger.error(f"Error detecting speech: {e}")
            # Default to True on error (assume speech is present)
            return True if not return_prob else 0.5
    
    def get_speech_segments(self, audio_data):
        """
        Get timestamps of speech segments in the audio.
        
        Args:
            audio_data (bytes or numpy.ndarray): Audio data
            
        Returns:
            list: List of dictionaries with start and end times of speech segments
        """
        if self.model is None:
            return [{"start": 0, "end": len(audio_data)}]
        
        try:
            # Convert audio bytes to tensor
            if isinstance(audio_data, bytes):
                audio = self._convert_bytes_to_tensor(audio_data)
            else:
                audio = torch.tensor(audio_data)
            
            # Get speech timestamps
            speech_timestamps = self.get_speech_timestamps(
                audio, 
                self.model,
                threshold=self.threshold,
                sampling_rate=self.sampling_rate
            )
            
            return speech_timestamps
        except Exception as e:
            logger.error(f"Error getting speech segments: {e}")
            return [{"start": 0, "end": len(audio_data)}]
    
    def _convert_bytes_to_tensor(self, audio_bytes):
        """
        Convert audio bytes to a PyTorch tensor.
        
        Args:
            audio_bytes (bytes): Audio data as bytes
            
        Returns:
            torch.Tensor: Audio data as tensor
        """
        try:
            # Convert bytes to AudioSegment
            audio_segment = AudioSegment.from_file(
                io.BytesIO(audio_bytes),
                format="wav"
            )
            
            # Ensure mono audio
            audio_segment = audio_segment.set_channels(1)
            
            # Ensure correct sample rate
            if audio_segment.frame_rate != self.sampling_rate:
                audio_segment = audio_segment.set_frame_rate(self.sampling_rate)
            
            # Convert to numpy array of int16
            samples = np.array(audio_segment.get_array_of_samples())
            
            # Convert to float tensor (normalized to [-1, 1])
            tensor = torch.FloatTensor(samples) / 32768.0
            
            return tensor
        except Exception as e:
            logger.error(f"Error converting audio bytes to tensor: {e}")
            raise
