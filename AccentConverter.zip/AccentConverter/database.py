"""
Database configuration and models for dexent.ai clone.

This module defines the SQLAlchemy database instance and models used for user management,
processing history, and various feature tracking.
"""
import os
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

# Database setup
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Models
class User(db.Model):
    """User model for storing user details and authentication information."""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    firebase_uid = db.Column(db.String(128), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    display_name = db.Column(db.String(64), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, default=datetime.utcnow)
    subscription_type = db.Column(db.String(20), default='free')  # free, premium, enterprise
    subscription_expiry = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    preferences = db.relationship('UserPreference', backref='user', lazy=True, uselist=False)
    noise_cancellations = db.relationship('NoiseHistory', backref='user', lazy=True)
    meeting_sessions = db.relationship('MeetingSession', backref='user', lazy=True)
    accent_conversions = db.relationship('AccentConversionHistory', backref='user', lazy=True)
    translations = db.relationship('TranslationHistory', backref='user', lazy=True)
    
    def __repr__(self):
        return f'<User {self.email}>'


class UserPreference(db.Model):
    """User preferences for all dexent.ai features."""
    __tablename__ = 'user_preferences'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Noise Cancellation preferences
    noise_reduction_level = db.Column(db.String(16), default='medium')  # low, medium, high
    voice_enhancement = db.Column(db.Boolean, default=True)
    echo_cancellation = db.Column(db.Boolean, default=True)
    
    # Meeting Assistant preferences
    auto_recording = db.Column(db.Boolean, default=False)
    auto_transcription = db.Column(db.Boolean, default=True)
    auto_summarization = db.Column(db.Boolean, default=True)
    
    # Accent Conversion preferences
    default_target_accent = db.Column(db.String(32), default='american')
    accent_conversion_enabled = db.Column(db.Boolean, default=True)
    
    # Translation preferences
    default_language = db.Column(db.String(32), default='english')
    auto_translation = db.Column(db.Boolean, default=False)
    
    # Interface preferences
    dark_mode = db.Column(db.Boolean, default=False)
    notification_enabled = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<UserPreference for user_id={self.user_id}>'


class NoiseHistory(db.Model):
    """History of noise cancellation sessions."""
    __tablename__ = 'noise_history'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime, nullable=True)
    duration_seconds = db.Column(db.Float, nullable=True)
    noise_reduction_level = db.Column(db.String(16), default='medium')
    application = db.Column(db.String(64), nullable=True)  # Which app was using the mic
    voice_enhancement = db.Column(db.Boolean, default=True)
    echo_cancellation = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<NoiseHistory id={self.id}, user_id={self.user_id}>'


class MeetingSession(db.Model):
    """Meeting recording, transcription and note-taking session."""
    __tablename__ = 'meeting_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(128), nullable=True)
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime, nullable=True)
    duration_seconds = db.Column(db.Float, nullable=True)
    platform = db.Column(db.String(64), nullable=True)  # Zoom, Teams, etc.
    recording_path = db.Column(db.String(256), nullable=True)
    transcription_path = db.Column(db.String(256), nullable=True)
    summary_path = db.Column(db.String(256), nullable=True)
    participants_count = db.Column(db.Integer, default=0)
    
    # Relationships
    action_items = db.relationship('ActionItem', backref='meeting', lazy=True)
    
    def __repr__(self):
        return f'<MeetingSession id={self.id}, user_id={self.user_id}>'


class ActionItem(db.Model):
    """Action items extracted from meeting transcripts."""
    __tablename__ = 'action_items'
    
    id = db.Column(db.Integer, primary_key=True)
    meeting_id = db.Column(db.Integer, db.ForeignKey('meeting_sessions.id'), nullable=False)
    description = db.Column(db.Text, nullable=False)
    assigned_to = db.Column(db.String(128), nullable=True)
    due_date = db.Column(db.DateTime, nullable=True)
    completed = db.Column(db.Boolean, default=False)
    
    def __repr__(self):
        return f'<ActionItem id={self.id}, meeting_id={self.meeting_id}>'


class AccentConversionHistory(db.Model):
    """History of accent conversions performed by users."""
    __tablename__ = 'accent_conversion_history'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    source_accent = db.Column(db.String(32), nullable=True)
    target_accent = db.Column(db.String(32), nullable=False)
    duration_seconds = db.Column(db.Float, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    application = db.Column(db.String(64), nullable=True)  # Which app was using the feature
    
    def __repr__(self):
        return f'<AccentConversionHistory id={self.id}, user_id={self.user_id}>'


class TranslationHistory(db.Model):
    """History of language translations performed by users."""
    __tablename__ = 'translation_history'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    source_language = db.Column(db.String(32), nullable=True)
    target_language = db.Column(db.String(32), nullable=False)
    duration_seconds = db.Column(db.Float, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    application = db.Column(db.String(64), nullable=True)  # Which app was using the feature
    
    def __repr__(self):
        return f'<TranslationHistory id={self.id}, user_id={self.user_id}>'


class SystemMetric(db.Model):
    """System performance metrics tracked over time."""
    __tablename__ = 'system_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    api_latency_ms = db.Column(db.Float, nullable=True)
    cpu_usage_percent = db.Column(db.Float, nullable=True)
    memory_usage_mb = db.Column(db.Float, nullable=True)
    active_connections = db.Column(db.Integer, nullable=True)
    feature_in_use = db.Column(db.String(32), nullable=True)  # Which feature was being used
    
    def __repr__(self):
        return f'<SystemMetric id={self.id}, timestamp={self.timestamp}>'