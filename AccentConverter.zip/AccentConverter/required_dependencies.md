# Required Dependencies for dexent.ai Clone

This document lists all required dependencies for running the dexent.ai Clone application.

## Python Dependencies

### Core Framework
- `flask`: Web framework for building the application
- `flask-sqlalchemy`: ORM for database operations
- `gunicorn`: WSGI HTTP server for production
- `werkzeug`: WSGI utilities

### Database
- `psycopg2-binary`: PostgreSQL adapter
- `sqlalchemy`: SQL toolkit and ORM

### Authentication
- `firebase-admin`: Firebase Admin SDK for server-side operations
- `pyjwt`: JSON Web Token implementation for Python

### AI and Audio Processing
- `torch`: PyTorch for neural network models
- `numpy`: Numerical computing library
- `pydub`: Audio processing library
- `soundfile`: Audio file read/write
- `librosa`: Audio analysis for feature extraction
- `scipy`: Scientific computing
- `scikit-learn`: Machine learning utilities

### API and Communication
- `requests`: HTTP library
- `twilio`: (Optional) For SMS notifications
- `sendgrid`: (Optional) For email communications

### Security and Utilities
- `python-dotenv`: Environment variable management
- `email-validator`: Email validation
- `pytz`: Timezone utilities

## Frontend Dependencies (Already Included via CDN)

### CSS Frameworks
- Bootstrap (dark theme): `https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css`

### JavaScript Libraries
- Bootstrap JS: `https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js`
- Font Awesome: `https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css`
- Chart.js: `https://cdn.jsdelivr.net/npm/chart.js`
- Firebase JS SDK: `https://www.gstatic.com/firebasejs/9.6.0/firebase-app-compat.js`
- Firebase Auth: `https://www.gstatic.com/firebasejs/9.6.0/firebase-auth-compat.js`

## System Requirements

### Runtime
- Python 3.11 or higher
- Node.js and npm (for some development tools)

### Database
- PostgreSQL 12 or higher

### Hardware
- Minimum 4GB RAM (8GB recommended)
- 2+ CPU cores
- 10GB free disk space

### Network
- Outbound internet access for Firebase authentication
- Port 5000 available for the web server

## Installation Instructions

All Python dependencies can be installed at once using:

```bash
pip install -r requirements.txt
```

Or individually with:

```bash
pip install flask flask-sqlalchemy psycopg2-binary firebase-admin torch numpy pydub soundfile
```

## Environment Setup

The following environment variables are required:

```
DATABASE_URL=postgresql://username:password@localhost:5432/krisp_clone
FIREBASE_API_KEY=your_firebase_api_key
FIREBASE_PROJECT_ID=your_firebase_project_id
FIREBASE_APP_ID=your_firebase_app_id
SESSION_SECRET=your_secret_key
```

## Troubleshooting

If you encounter issues with PyTorch on your platform:
- Refer to https://pytorch.org/get-started/locally/ for specific installation commands based on your OS and environment
- Consider using a CPU-only build if no GPU is available

For Firebase authentication issues:
- Verify your Firebase project is properly configured
- Ensure web authentication is enabled in your Firebase project
- Add your application's domain to the authorized domains list