// Import the functions you need from the SDKs
import { initializeApp } from "firebase/app";
import { getAnalytics, isSupported as isAnalyticsSupported } from "firebase/analytics";
import { getAuth } from "firebase/auth";  // Firebase Authentication
import { getFirestore } from "firebase/firestore";  // Firebase Firestore
import { getDatabase } from "firebase/database";  // Firebase Realtime Database
import { getStorage } from "firebase/storage";  // Firebase Storage

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyALVavSDmZFaiD_1PPknEcPzfE5fpWLPNY",
  authDomain: "dexent-29865.firebaseapp.com",
  projectId: "dexent-29865",
  storageBucket: "dexent-29865.appspot.com",  // Corrected: should be .app**spot**.com
  messagingSenderId: "207232960829",
  appId: "1:207232960829:web:ea299dc6e01084e9db1d54",
  measurementId: "G-VEJSD2WKXP"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Analytics only if supported (avoids SSR errors)
let analytics;
if (typeof window !== "undefined") {
  isAnalyticsSupported().then((supported) => {
    if (supported) {
      analytics = getAnalytics(app);
    }
  });
}

// Initialize Firebase Auth, Firestore, Realtime DB, and Storage
const auth = getAuth(app);
const firestore = getFirestore(app);
const database = getDatabase(app);
const storage = getStorage(app);

// Exporting services for use in your app
export { app, auth, firestore, database, storage };
import { auth, firestore, database, storage } from './firebase/firebase-config';

// Use the Firebase services as needed
