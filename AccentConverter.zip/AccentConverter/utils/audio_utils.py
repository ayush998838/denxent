import io
import os
import wave
import logging
import numpy as np
from pydub import AudioSegment
import soundfile as sf

logger = logging.getLogger(__name__)

def process_audio_chunk(audio_bytes, vad_model, speaker_model, accent_model, target_accent='british'):
    """
    Process an audio chunk through the full pipeline:
    1. Voice Activity Detection
    2. Speaker Embedding Extraction
    3. Accent Conversion
    
    Args:
        audio_bytes (bytes): Audio data as WAV bytes
        vad_model: Voice Activity Detection model
        speaker_model: Speaker Embedding model
        accent_model: Accent Conversion model
        target_accent (str): Target accent name
        
    Returns:
        bytes: Processed audio data as WAV bytes, or original if no speech
    """
    try:
        # Check if audio contains speech
        if vad_model and not vad_model.is_speech(audio_bytes):
            logger.debug("No speech detected in audio chunk")
            return audio_bytes
        
        # Extract speaker embedding
        if speaker_model:
            embedding = speaker_model.extract_embedding(audio_bytes)
        else:
            embedding = None
            logger.warning("Speaker model not available, using default embedding")
        
        # Convert accent
        if accent_model:
            converted_audio = accent_model.convert(audio_bytes, embedding, target_accent)
            return converted_audio
        else:
            logger.warning("Accent model not available, returning original audio")
            return audio_bytes
            
    except Exception as e:
        logger.error(f"Error processing audio chunk: {e}")
        return audio_bytes  # Return original on error

def read_wav_file(file_path):
    """
    Read WAV file and return audio data.
    
    Args:
        file_path (str): Path to WAV file
        
    Returns:
        tuple: (numpy.ndarray, int) audio data and sample rate
    """
    try:
        return sf.read(file_path)
    except Exception as e:
        logger.error(f"Error reading WAV file: {e}")
        return None, None

def save_wav_file(audio_data, sample_rate, file_path):
    """
    Save audio data to WAV file.
    
    Args:
        audio_data (numpy.ndarray): Audio data
        sample_rate (int): Sample rate
        file_path (str): Output file path
        
    Returns:
        bool: Success status
    """
    try:
        sf.write(file_path, audio_data, sample_rate)
        return True
    except Exception as e:
        logger.error(f"Error saving WAV file: {e}")
        return False

def wav_bytes_to_numpy(wav_bytes):
    """
    Convert WAV bytes to numpy array.
    
    Args:
        wav_bytes (bytes): Audio data as WAV bytes
        
    Returns:
        tuple: (numpy.ndarray, int) audio data and sample rate
    """
    try:
        # Use BytesIO for in-memory file
        wav_io = io.BytesIO(wav_bytes)
        
        # Read WAV data
        with wave.open(wav_io, 'rb') as wav_file:
            # Get parameters
            sample_rate = wav_file.getframerate()
            n_channels = wav_file.getnchannels()
            sampwidth = wav_file.getsampwidth()
            n_frames = wav_file.getnframes()
            
            # Read frames
            frames = wav_file.readframes(n_frames)
            
            # Convert bytes to numpy array
            if sampwidth == 2:
                dtype = np.int16
            elif sampwidth == 4:
                dtype = np.int32
            else:
                raise ValueError(f"Unsupported sample width: {sampwidth}")
                
            audio_data = np.frombuffer(frames, dtype=dtype)
            
            # Reshape for multichannel audio
            if n_channels > 1:
                audio_data = audio_data.reshape(-1, n_channels)
            
            return audio_data, sample_rate
            
    except Exception as e:
        logger.error(f"Error converting WAV bytes to numpy: {e}")
        return None, None

def numpy_to_wav_bytes(audio_data, sample_rate, n_channels=1, sampwidth=2):
    """
    Convert numpy array to WAV bytes.
    
    Args:
        audio_data (numpy.ndarray): Audio data
        sample_rate (int): Sample rate
        n_channels (int): Number of channels
        sampwidth (int): Sample width in bytes
        
    Returns:
        bytes: Audio data as WAV bytes
    """
    try:
        # Use BytesIO for in-memory file
        wav_io = io.BytesIO()
        
        # Create WAV file
        with wave.open(wav_io, 'wb') as wav_file:
            wav_file.setnchannels(n_channels)
            wav_file.setsampwidth(sampwidth)
            wav_file.setframerate(sample_rate)
            
            # Ensure audio_data is the right shape
            if n_channels > 1 and len(audio_data.shape) == 1:
                audio_data = np.tile(audio_data.reshape(-1, 1), (1, n_channels))
            
            # Ensure audio_data is the right type
            if sampwidth == 2:
                audio_data = audio_data.astype(np.int16)
            elif sampwidth == 4:
                audio_data = audio_data.astype(np.int32)
            
            # Write frames
            wav_file.writeframes(audio_data.tobytes())
        
        # Get bytes
        wav_io.seek(0)
        return wav_io.read()
            
    except Exception as e:
        logger.error(f"Error converting numpy to WAV bytes: {e}")
        return None

def ensure_mono_audio(audio_bytes):
    """
    Ensure audio is mono (1 channel).
    
    Args:
        audio_bytes (bytes): Audio data as WAV bytes
        
    Returns:
        bytes: Mono audio data as WAV bytes
    """
    try:
        # Load audio with pydub
        audio_segment = AudioSegment.from_file(io.BytesIO(audio_bytes), format="wav")
        
        # Convert to mono if needed
        if audio_segment.channels > 1:
            audio_segment = audio_segment.set_channels(1)
            
            # Export to bytes
            buffer = io.BytesIO()
            audio_segment.export(buffer, format="wav")
            return buffer.getvalue()
        
        # Already mono
        return audio_bytes
        
    except Exception as e:
        logger.error(f"Error ensuring mono audio: {e}")
        return audio_bytes  # Return original on error

def ensure_sample_rate(audio_bytes, target_rate=16000):
    """
    Ensure audio has the target sample rate.
    
    Args:
        audio_bytes (bytes): Audio data as WAV bytes
        target_rate (int): Target sample rate
        
    Returns:
        bytes: Resampled audio data as WAV bytes
    """
    try:
        # Load audio with pydub
        audio_segment = AudioSegment.from_file(io.BytesIO(audio_bytes), format="wav")
        
        # Resample if needed
        if audio_segment.frame_rate != target_rate:
            audio_segment = audio_segment.set_frame_rate(target_rate)
            
            # Export to bytes
            buffer = io.BytesIO()
            audio_segment.export(buffer, format="wav")
            return buffer.getvalue()
        
        # Already correct sample rate
        return audio_bytes
        
    except Exception as e:
        logger.error(f"Error ensuring sample rate: {e}")
        return audio_bytes  # Return original on error
