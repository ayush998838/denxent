"""
Database management utilities for Dexent.ai.

This module provides helper functions for common database operations.
"""
import logging
from datetime import datetime
from typing import List, Dict, Any, Optional

from database import db, User, UserPreference, ConversionHistory, SystemMetric

logger = logging.getLogger(__name__)

# User Management
def create_user(firebase_uid: str, email: str, display_name: Optional[str] = None) -> User:
    """
    Create a new user with default preferences.
    
    Args:
        firebase_uid: Firebase user ID
        email: User email
        display_name: User display name (optional)
        
    Returns:
        Newly created user
    """
    try:
        user = User(
            firebase_uid=firebase_uid,
            email=email,
            display_name=display_name,
            created_at=datetime.utcnow(),
            last_login=datetime.utcnow()
        )
        db.session.add(user)
        db.session.commit()
        
        # Create default preferences
        preferences = UserPreference(
            user_id=user.id,
            default_accent='british',
            audio_quality='medium',
            conversion_speed='balanced'
        )
        db.session.add(preferences)
        db.session.commit()
        
        return user
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating user: {e}")
        raise

def get_user_by_firebase_uid(firebase_uid: str) -> Optional[User]:
    """
    Get a user by Firebase UID.
    
    Args:
        firebase_uid: Firebase user ID
        
    Returns:
        User object or None if not found
    """
    return User.query.filter_by(firebase_uid=firebase_uid).first()

def update_user_login(user: User) -> None:
    """
    Update user's last login timestamp.
    
    Args:
        user: User object
    """
    user.last_login = datetime.utcnow()
    db.session.commit()

def update_user_preferences(user_id: int, preferences: Dict[str, Any]) -> UserPreference:
    """
    Update user preferences.
    
    Args:
        user_id: User ID
        preferences: Dictionary of preferences to update
        
    Returns:
        Updated UserPreference object
    """
    user_prefs = UserPreference.query.filter_by(user_id=user_id).first()
    
    if not user_prefs:
        # Create preferences if they don't exist
        user_prefs = UserPreference(user_id=user_id)
        db.session.add(user_prefs)
    
    # Update fields
    for key, value in preferences.items():
        if hasattr(user_prefs, key):
            setattr(user_prefs, key, value)
    
    db.session.commit()
    return user_prefs

# Conversion History
def record_conversion(
    user_id: int, 
    target_accent: str, 
    source_accent: Optional[str] = None,
    duration_seconds: Optional[float] = None,
    audio_stored: bool = False,
    audio_path: Optional[str] = None
) -> ConversionHistory:
    """
    Record a conversion in the history.
    
    Args:
        user_id: User ID
        target_accent: Target accent
        source_accent: Source accent (optional)
        duration_seconds: Duration of audio in seconds (optional)
        audio_stored: Whether audio is stored (default False)
        audio_path: Path to stored audio (optional)
        
    Returns:
        Newly created ConversionHistory object
    """
    conversion = ConversionHistory(
        user_id=user_id,
        target_accent=target_accent,
        source_accent=source_accent,
        duration_seconds=duration_seconds,
        created_at=datetime.utcnow(),
        audio_stored=audio_stored,
        audio_path=audio_path
    )
    
    db.session.add(conversion)
    db.session.commit()
    return conversion

def get_user_conversions(user_id: int, limit: int = 10) -> List[ConversionHistory]:
    """
    Get conversion history for a user.
    
    Args:
        user_id: User ID
        limit: Maximum number of results (default 10)
        
    Returns:
        List of ConversionHistory objects
    """
    return ConversionHistory.query.filter_by(user_id=user_id)\
        .order_by(ConversionHistory.created_at.desc())\
        .limit(limit).all()

# System Metrics
def record_metrics(
    api_latency_ms: Optional[float] = None,
    cpu_usage_percent: Optional[float] = None,
    memory_usage_mb: Optional[float] = None,
    active_connections: Optional[int] = None
) -> SystemMetric:
    """
    Record system performance metrics.
    
    Args:
        api_latency_ms: API latency in milliseconds (optional)
        cpu_usage_percent: CPU usage percentage (optional)
        memory_usage_mb: Memory usage in MB (optional)
        active_connections: Number of active connections (optional)
        
    Returns:
        Newly created SystemMetric object
    """
    metric = SystemMetric(
        timestamp=datetime.utcnow(),
        api_latency_ms=api_latency_ms,
        cpu_usage_percent=cpu_usage_percent,
        memory_usage_mb=memory_usage_mb,
        active_connections=active_connections
    )
    
    db.session.add(metric)
    db.session.commit()
    return metric

def get_recent_metrics(hours: int = 24, limit: int = 100) -> List[SystemMetric]:
    """
    Get recent system metrics.
    
    Args:
        hours: Number of hours to look back (default 24)
        limit: Maximum number of results (default 100)
        
    Returns:
        List of SystemMetric objects
    """
    since = datetime.utcnow().timestamp() - (hours * 3600)
    since_dt = datetime.fromtimestamp(since)
    
    return SystemMetric.query.filter(SystemMetric.timestamp >= since_dt)\
        .order_by(SystemMetric.timestamp.desc())\
        .limit(limit).all()

# Database Maintenance
def cleanup_old_metrics(days: int = 30) -> int:
    """
    Delete metrics older than specified days.
    
    Args:
        days: Number of days to keep metrics (default 30)
        
    Returns:
        Number of deleted records
    """
    cutoff = datetime.utcnow().timestamp() - (days * 24 * 3600)
    cutoff_dt = datetime.fromtimestamp(cutoff)
    
    count = SystemMetric.query.filter(SystemMetric.timestamp < cutoff_dt).count()
    SystemMetric.query.filter(SystemMetric.timestamp < cutoff_dt).delete()
    db.session.commit()
    
    return count